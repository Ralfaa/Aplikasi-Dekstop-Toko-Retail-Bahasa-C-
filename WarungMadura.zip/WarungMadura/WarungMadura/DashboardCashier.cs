﻿using CustomMessageBox;
using Guna.UI2.WinForms;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using WarungMadura.Resources.Dashboard;

namespace WarungMadura {
    public partial class DashboardCashier : Form {
        private int max = 640;
        private const int min = 5;
        private bool D_Extend = false;
        string connectionString = Properties.Resources.ConnectionString;
        Login Login;
        private int IDEmployee = 0;
        public DashboardCashier(Login login, int id, string Name) {
            InitializeComponent();
            L_Name.Text = Name.Substring(0, 8) + "...";
            this.Login = login;
            IDEmployee = id;
        }
        public DashboardCashier() {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e) {
            loadCategory();
        }
        private Guna2Button CloneButton(Guna2Button original) {
            Guna2Button copy = new Guna2Button();
            copy.Size = new Size(original.Size.Width-40, copy.Size.Height);
            copy.Font = original.Font;
            copy.ForeColor = original.ForeColor;
            copy.FillColor = original.FillColor;
            copy.Font = original.Font;
            copy.TextAlign = original.TextAlign;
            copy.BackColor = original.BackColor;
            copy.BorderRadius = 6;

            return copy;
        }
        private void loadCategory() {
            try {
                using (SqlConnection myConnection = new SqlConnection(connectionString)) {
                    myConnection.Open();

                    SqlCommand myCommand = new SqlCommand("SELECT NamaKategori FROM FnSearchProductCategory(null,null)", myConnection);

                    using (SqlDataReader reader = myCommand.ExecuteReader()) {

                        while (reader.Read()) {
                            Guna2Button buffer = CloneButton(btn_Order);
                            string textbuffer = reader.GetString(reader.GetOrdinal("NamaKategori"));
                            buffer.Text = textbuffer.Length > 15 ? textbuffer.Substring(0, 15) + "..." : textbuffer;
                            buffer.CheckedChanged += btn_CheckedChanged_Padding;
                            buffer.Click += btn_Category_Click;
                            DataPanel.Controls.Add(buffer);
                        }

                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
            
            int MH = 40 * (DataPanel.Controls.Count + 1) + 20;
            if (MH < max) {
                max = MH;
            }
        }
        private void gbtn_Data_Click(object sender, EventArgs e) {
            time_EButton.Interval = 10;
            time_EButton.Start();
        }

        private void time_EButton_Tick(object sender, EventArgs e) {
            if (DataPanel.Height <= max && !D_Extend) {
                DataPanel.Height += 12;
            } else if (DataPanel.Height >= max && !D_Extend) {
                DataPanel.Height = max;
                time_EButton.Stop();
                D_Extend = true;
            } else if (DataPanel.Height > min && D_Extend) {
                DataPanel.Height -= 12;
            } else if (DataPanel.Height <= min && D_Extend) {
                DataPanel.Height = min;
                time_EButton.Stop();
                D_Extend = false;
            }
        }

        private void ShowFormInPanel(Form form, Guna2Button guna2Button) {
            foreach (Control control in DataPanel.Controls) {
                if (control is Guna2Button button) {
                    button.Checked = false;
                }
            }
            foreach (Control control in flp_Menu.Controls) {
                if (control is Guna2Button button) {
                    button.Checked = false;
                }
            }
            guna2Button.Checked = true;
            if(pnl_filForm.Tag != null) {
                if(form.ToString().Contains(pnl_filForm.Tag.ToString())) {
                    return;
                }
                if (D_Extend == true) {
                    time_EButton.Start();
                }
            }
            if (pnl_filForm.Tag is Form FormPanel) {
                Form form1 = (Form)pnl_filForm.Tag;
                form1.Close();
                pnl_filForm.Controls.Clear();
                pnl_filForm.Tag = null;
            }
            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            EnableDoubleBuffering(form);
            pnl_filForm.Controls.Add(form);
            pnl_filForm.Tag = form;
            form.Show();
            form.Enabled = true;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void EnableDoubleBuffering(Control control) {
            control.GetType().GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                   .SetValue(control, true, null);

            foreach (Control child in control.Controls) {
                EnableDoubleBuffering(child);
            }
        }

        private void btn_Logout_Click(object sender, EventArgs e) {
            Form frm = (Form)pnl_filForm.Tag;
            frm.Close();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            this.Close();
        }

        private void btn_Dashboard_Click(object sender, EventArgs e) {
            ShowFormInPanel(new CashierDasboard(IDEmployee), (Guna2Button)sender);
        }

        private void btn_Profile_Click(object sender, EventArgs e) {
            ShowFormInPanel(new Profile(IDEmployee), (Guna2Button)sender);
        }

        bool pcategoriesBC = false;
        private void btn_Order_Click(object sender, EventArgs e) {
            if(btn_Order.Checked == true && pcategoriesBC){
                Sell form1 = (Sell)pnl_filForm.Tag;
                form1.LoadData();
                pcategoriesBC = false;
                D_Extend = false;
            } else {
                time_EButton.Start();
            }
            ShowFormInPanel(new Sell(IDEmployee), (Guna2Button)sender);
        }
        private void btn_Category_Click(object sender, EventArgs e) {
            foreach (Control control in DataPanel.Controls) {
                if (control is Guna2Button button) {
                    button.Checked = false;
                }
            }
            Guna2Button guna2Button = (Guna2Button)sender;
            guna2Button.Checked = true;
            Sell form1 = (Sell)pnl_filForm.Tag;
            form1.ChosData(guna2Button.Text);
            pcategoriesBC = true;

        }

        private void DashboardAdmin_FormClosed(object sender, FormClosedEventArgs e) {
            Login.Show();
        }

        private void btn_CheckedChanged_Padding(object sender, EventArgs e) {
            Guna2Button guna2Button = (Guna2Button)sender;
            if (guna2Button.Checked) {
                guna2Button.ShadowDecoration.Enabled = true;
                guna2Button.ShadowDecoration.Depth = 100;
                guna2Button.ShadowDecoration.Shadow = new Padding(0,0,10,0);
                guna2Button.ShadowDecoration.Color = Color.FromArgb(100, 204, 197);
            } else {
                guna2Button.ShadowDecoration.Enabled = false;
            }
        }

        private void DataPanel_Paint(object sender, PaintEventArgs e) {

        }

        private void timerLoadDash_Tick(object sender, EventArgs e) {
            
        }

        private void DashboardCashier_EnabledChanged(object sender, EventArgs e) {
            btn_Dashboard.PerformClick();
        }

    }
}

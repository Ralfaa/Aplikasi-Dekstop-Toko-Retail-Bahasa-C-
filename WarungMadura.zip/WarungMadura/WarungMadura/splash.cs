﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura {
    public partial class splash : Form {

        public splash() {
            InitializeComponent();
            this.Opacity = 0;
            timerSplashIn.Interval = 5;
            timerSplashIn.Start();
        }

        private void timerSplash_Tick(object sender, EventArgs e) {
            if (this.Opacity < 1) {
                this.Opacity += 0.05;
            } else {
                timerSplashIn.Stop();
                Loading.Start();
            }
        }

        private void timerSplashOut_Tick(object sender, EventArgs e) {
            if (this.Opacity > 0) {
                this.Opacity -= 0.05;
            } else {
                timerSplashOut.Stop();
                Close();
            }
        }

        private void Loading_Tick(object sender, EventArgs e) {
            if(LoadingBar.Value < 100) {
                LoadingBar.Value += 1;
            } else {
                Loading.Stop();
                timerSplashOut.Interval = 5;
                timerSplashOut.Start();
            }
        }
    }
}

﻿namespace WarungMadura {
    partial class splash {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.timerSplashIn = new System.Windows.Forms.Timer(this.components);
            this.timerSplashOut = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LoadingBar = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.Loading = new System.Windows.Forms.Timer(this.components);
            this.guna2CustomGradientPanel3 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // timerSplashIn
            // 
            this.timerSplashIn.Tick += new System.EventHandler(this.timerSplash_Tick);
            // 
            // timerSplashOut
            // 
            this.timerSplashOut.Tick += new System.EventHandler(this.timerSplashOut_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::WarungMadura.Properties.Resources.Logo_WMXW;
            this.pictureBox1.Location = new System.Drawing.Point(238, 115);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(324, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LoadingBar
            // 
            this.LoadingBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LoadingBar.BorderColor = System.Drawing.Color.Azure;
            this.LoadingBar.BorderThickness = 2;
            this.LoadingBar.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.LoadingBar.Location = new System.Drawing.Point(89, 377);
            this.LoadingBar.Name = "LoadingBar";
            this.LoadingBar.ProgressColor = System.Drawing.Color.White;
            this.LoadingBar.ProgressColor2 = System.Drawing.Color.White;
            this.LoadingBar.Size = new System.Drawing.Size(622, 30);
            this.LoadingBar.TabIndex = 1;
            this.LoadingBar.Text = "guna2ProgressBar1";
            this.LoadingBar.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // Loading
            // 
            this.Loading.Interval = 10;
            this.Loading.Tick += new System.EventHandler(this.Loading_Tick);
            // 
            // guna2CustomGradientPanel3
            // 
            this.guna2CustomGradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel3.Location = new System.Drawing.Point(717, 377);
            this.guna2CustomGradientPanel3.Name = "guna2CustomGradientPanel3";
            this.guna2CustomGradientPanel3.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2CustomGradientPanel3.ShadowDecoration.Depth = 25;
            this.guna2CustomGradientPanel3.ShadowDecoration.Enabled = true;
            this.guna2CustomGradientPanel3.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(7);
            this.guna2CustomGradientPanel3.Size = new System.Drawing.Size(5, 30);
            this.guna2CustomGradientPanel3.TabIndex = 2;
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(78, 377);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2CustomGradientPanel1.ShadowDecoration.Depth = 25;
            this.guna2CustomGradientPanel1.ShadowDecoration.Enabled = true;
            this.guna2CustomGradientPanel1.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(7);
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(5, 30);
            this.guna2CustomGradientPanel1.TabIndex = 3;
            // 
            // splash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2CustomGradientPanel3);
            this.Controls.Add(this.LoadingBar);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "splash";
            this.ShowInTaskbar = false;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timerSplashIn;
        private System.Windows.Forms.Timer timerSplashOut;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2ProgressBar LoadingBar;
        private System.Windows.Forms.Timer Loading;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel3;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
    }
}
﻿namespace WarungMadura {
    partial class DashboardManager {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardManager));
            this.MenuDash = new System.Windows.Forms.Panel();
            this.flp_Menu = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Dashboard = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Profile = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Order = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Purchase = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.lb_Welcome = new System.Windows.Forms.Label();
            this.L_Name = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Logout = new Guna.UI2.WinForms.Guna2Button();
            this.time_EButton = new System.Windows.Forms.Timer(this.components);
            this.pnl_filForm = new System.Windows.Forms.Panel();
            this.MenuDash.SuspendLayout();
            this.flp_Menu.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuDash
            // 
            this.MenuDash.AutoSize = true;
            this.MenuDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.MenuDash.Controls.Add(this.flp_Menu);
            this.MenuDash.Controls.Add(this.guna2GradientPanel1);
            this.MenuDash.Controls.Add(this.pictureBox1);
            this.MenuDash.Controls.Add(this.btn_Logout);
            this.MenuDash.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuDash.Location = new System.Drawing.Point(0, 0);
            this.MenuDash.Name = "MenuDash";
            this.MenuDash.Size = new System.Drawing.Size(287, 620);
            this.MenuDash.TabIndex = 0;
            // 
            // flp_Menu
            // 
            this.flp_Menu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.flp_Menu.AutoScroll = true;
            this.flp_Menu.Controls.Add(this.btn_Dashboard);
            this.flp_Menu.Controls.Add(this.btn_Profile);
            this.flp_Menu.Controls.Add(this.btn_Order);
            this.flp_Menu.Controls.Add(this.btn_Purchase);
            this.flp_Menu.Location = new System.Drawing.Point(5, 166);
            this.flp_Menu.Name = "flp_Menu";
            this.flp_Menu.Size = new System.Drawing.Size(272, 394);
            this.flp_Menu.TabIndex = 4;
            // 
            // btn_Dashboard
            // 
            this.btn_Dashboard.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Dashboard.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Dashboard.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Dashboard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Dashboard.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Dashboard.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Dashboard.ForeColor = System.Drawing.Color.White;
            this.btn_Dashboard.Image = global::WarungMadura.Properties.Resources.dashboardw;
            this.btn_Dashboard.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Dashboard.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Dashboard.Location = new System.Drawing.Point(3, 3);
            this.btn_Dashboard.Name = "btn_Dashboard";
            this.btn_Dashboard.Size = new System.Drawing.Size(245, 45);
            this.btn_Dashboard.TabIndex = 1;
            this.btn_Dashboard.Text = "Dashboard";
            this.btn_Dashboard.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Dashboard.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Dashboard.Click += new System.EventHandler(this.btn_Dashboard_Click);
            // 
            // btn_Profile
            // 
            this.btn_Profile.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Profile.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Profile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Profile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Profile.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Profile.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Profile.ForeColor = System.Drawing.Color.White;
            this.btn_Profile.Image = global::WarungMadura.Properties.Resources.User;
            this.btn_Profile.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Profile.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Profile.Location = new System.Drawing.Point(3, 54);
            this.btn_Profile.Name = "btn_Profile";
            this.btn_Profile.ShadowDecoration.BorderRadius = 0;
            this.btn_Profile.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(204)))), ((int)(((byte)(197)))));
            this.btn_Profile.ShadowDecoration.Depth = 100;
            this.btn_Profile.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.btn_Profile.Size = new System.Drawing.Size(245, 45);
            this.btn_Profile.TabIndex = 2;
            this.btn_Profile.Text = "Profile";
            this.btn_Profile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Profile.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Profile.Click += new System.EventHandler(this.btn_Profile_Click);
            // 
            // btn_Order
            // 
            this.btn_Order.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Order.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Order.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Order.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Order.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Order.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Order.ForeColor = System.Drawing.Color.White;
            this.btn_Order.Image = global::WarungMadura.Properties.Resources.SalesReport;
            this.btn_Order.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Order.ImageSize = new System.Drawing.Size(35, 35);
            this.btn_Order.Location = new System.Drawing.Point(3, 105);
            this.btn_Order.Name = "btn_Order";
            this.btn_Order.Size = new System.Drawing.Size(245, 45);
            this.btn_Order.TabIndex = 3;
            this.btn_Order.Text = "Sales Report";
            this.btn_Order.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Order.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Order.Click += new System.EventHandler(this.btn_Order_Click);
            // 
            // btn_Purchase
            // 
            this.btn_Purchase.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Purchase.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Purchase.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Purchase.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Purchase.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Purchase.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase.ForeColor = System.Drawing.Color.White;
            this.btn_Purchase.Image = global::WarungMadura.Properties.Resources.PurchaseReport;
            this.btn_Purchase.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Purchase.ImageSize = new System.Drawing.Size(35, 35);
            this.btn_Purchase.Location = new System.Drawing.Point(3, 156);
            this.btn_Purchase.Name = "btn_Purchase";
            this.btn_Purchase.Size = new System.Drawing.Size(245, 45);
            this.btn_Purchase.TabIndex = 4;
            this.btn_Purchase.Text = "Purchase Report";
            this.btn_Purchase.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Purchase.Click += new System.EventHandler(this.btn_Purchase_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.BorderRadius = 3;
            this.guna2GradientPanel1.BorderThickness = 2;
            this.guna2GradientPanel1.Controls.Add(this.lb_Welcome);
            this.guna2GradientPanel1.Controls.Add(this.L_Name);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(7, 102);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(272, 46);
            this.guna2GradientPanel1.TabIndex = 3;
            // 
            // lb_Welcome
            // 
            this.lb_Welcome.AutoSize = true;
            this.lb_Welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Welcome.ForeColor = System.Drawing.Color.White;
            this.lb_Welcome.Location = new System.Drawing.Point(16, 9);
            this.lb_Welcome.Name = "lb_Welcome";
            this.lb_Welcome.Size = new System.Drawing.Size(121, 29);
            this.lb_Welcome.TabIndex = 1;
            this.lb_Welcome.Text = "Welcome,";
            // 
            // L_Name
            // 
            this.L_Name.AutoSize = true;
            this.L_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Name.ForeColor = System.Drawing.Color.White;
            this.L_Name.Location = new System.Drawing.Point(136, 9);
            this.L_Name.Name = "L_Name";
            this.L_Name.Size = new System.Drawing.Size(120, 29);
            this.L_Name.TabIndex = 2;
            this.L_Name.Text = "Admin123";
            this.L_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(272, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Logout
            // 
            this.btn_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Logout.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Logout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Logout.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Logout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Logout.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Logout.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Logout.ForeColor = System.Drawing.Color.White;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Logout.Location = new System.Drawing.Point(12, 568);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(245, 45);
            this.btn_Logout.TabIndex = 6;
            this.btn_Logout.Text = "Logout";
            this.btn_Logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // time_EButton
            // 
            this.time_EButton.Tick += new System.EventHandler(this.time_EButton_Tick);
            // 
            // pnl_filForm
            // 
            this.pnl_filForm.AutoSize = true;
            this.pnl_filForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_filForm.BackColor = System.Drawing.Color.Transparent;
            this.pnl_filForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_filForm.Location = new System.Drawing.Point(287, 0);
            this.pnl_filForm.Name = "pnl_filForm";
            this.pnl_filForm.Size = new System.Drawing.Size(1163, 620);
            this.pnl_filForm.TabIndex = 1;
            // 
            // DashboardManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1450, 620);
            this.Controls.Add(this.pnl_filForm);
            this.Controls.Add(this.MenuDash);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(1450, 620);
            this.Name = "DashboardManager";
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DashboardAdmin_FormClosed);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.EnabledChanged += new System.EventHandler(this.DashboardAdmin_EnabledChanged);
            this.MenuDash.ResumeLayout(false);
            this.flp_Menu.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel MenuDash;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label L_Name;
        private System.Windows.Forms.Label lb_Welcome;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private System.Windows.Forms.FlowLayoutPanel flp_Menu;
        private Guna.UI2.WinForms.Guna2Button btn_Dashboard;
        private Guna.UI2.WinForms.Guna2Button btn_Profile;
        private Guna.UI2.WinForms.Guna2Button btn_Purchase;
        private System.Windows.Forms.Timer time_EButton;
        private System.Windows.Forms.Panel pnl_filForm;
        private Guna.UI2.WinForms.Guna2Button btn_Logout;
        private Guna.UI2.WinForms.Guna2Button btn_Order;
    }
}
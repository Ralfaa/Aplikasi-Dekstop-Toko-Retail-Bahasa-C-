﻿using CustomMessageBox;
using Guna.UI2.WinForms;
using ReportPembelianWarung;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Order : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;
        private int IDEmployee = 0;
        public Order(int id) {
            InitializeComponent();
            IDEmployee = id;
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            Load_Supplier();
            autoId();
            btn_BUY.Enabled = false;
        }
        private void Produk_Load(object sender, EventArgs e) {
        }
        private void Load_Supplier() {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "SELECT id_supplier,NamaSupplier FROM Supplier where status = 1";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    cb_Supplier.DisplayMember = "NamaSupplier";
                    cb_Supplier.ValueMember = "id_supplier";
                    cb_Supplier.DataSource = dataTable;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_transaksi_pembelian FROM TransaksiPembelian ORDER BY id_transaksi_pembelian DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "POD00001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_transaksi_pembelian"]);
                            int newID = lastID + 1;

                            addID = "POD" + newID.ToString().PadLeft(5, '0');
                        }
                        l_ID.Text = l_ID.Text.Substring(0, 5) + addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }



        private void LoadData() {
            autoId();
            flp_Jabatan.Controls.Clear();
            string query = $"select * from FnSearchProduk(null,null,null,'{cb_Supplier.Text}') order by Stock ";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                    string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                    string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                    int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                    int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                    decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                    decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                    string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }
                                    UC_TProduk buffer = new UC_TProduk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.ADDButton += UserControl_ADD;
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Product Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void UserControl_InfoButton(object sender, ProductEventArgs e) {
            Form formBackground = new Form();
            using (ProductInfo productInfo = new ProductInfo(e.id_Product, e.NamaProduct, e.nama_CProduct, e.nama_Supplier, e.Stock, e.Unit, e.Discount, e.Sell, e.Buy, e.Picture)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                productInfo.StartPosition = FormStartPosition.CenterScreen;
                productInfo.FormBorderStyle = FormBorderStyle.None;
                productInfo.Owner = formBackground;
                productInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private void UserControl_ADD(object sender, ProductEventArgs e) {
            bool found = false;
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    if(userControl.id == e.id_Product) {
                        userControl.Transaction_Qty = userControl.Transaction_Qty + 1;
                        userControl.txt_QTY.Text = userControl.Transaction_Qty.ToString();
                        found = true;
                        refresh(null,null);
                    }
                }
            }
            if (!found) {
                UC_Transaction uC_Transaction = new UC_Transaction(e.id_Product, e.NamaProduct, e.Buy);
                uC_Transaction.ClickRefresh += refresh;
                flp_BUY.Controls.Add(uC_Transaction);
                refresh(null, null);
            }
        }

        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }

        private void KeypressNumber(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void txt_Search_Enter(object sender, EventArgs e) { 
        }

        private void cb_Supplier_SelectedIndexChanged(object sender, EventArgs e) {
            if(cb_Supplier.SelectedIndex >= 0) {
                LoadData();
            }
        }
        private void refresh(object sender, EventArgs e) {
            decimal total = 0;
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    total += userControl.StartPrice * userControl.Transaction_Qty;
                }
            }
            L_Total.Text = total.ToString("F0");
        }
        private void flp_Add_Remove_Items(object sender, ControlEventArgs e) {
            if (e.Control is UC_Transaction uc) {
                decimal total = 0;
                foreach (Control control in flp_BUY.Controls) {
                    if (control is UC_Transaction userControl) {
                        total += userControl.TotalPrice * userControl.Transaction_Qty;
                    }
                }
                L_Total.Text = total.ToString("F0");
            }
            if(flp_BUY.Controls.Count > 0) {
                btn_BUY.Enabled = true;
                cb_Supplier.Enabled = false;
            } else {
                btn_BUY.Enabled = false;
                cb_Supplier.Enabled = true;
            }
            refresh(null, null);
        }
        private void txt_Currency_TextChanged(object sender, EventArgs e) {
            Label guna2Text = (Label)sender;
            string buffer = guna2Text.Text.Replace("Rp", "").Trim();
            buffer = buffer.Replace(".", "");
            decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result);
            string formattedBuffer = result.ToString("#,##0", CultureInfo.InvariantCulture).Replace(",", ".");
            guna2Text.Text = "Rp " + formattedBuffer;        
        }

        private void filter() {
            if (cb_Supplier.SelectedItem != null) {
                autoId();
                flp_Jabatan.Controls.Clear();
                string query = $"select * from FnSearchProduk(null,'{txt_Search.Text}',null,'{cb_Supplier.Text}') order by Stock ";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    try {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            using (SqlDataReader reader = command.ExecuteReader()) {
                                if (reader.HasRows) {
                                    while (reader.Read()) {
                                        int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                        string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                        string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                        int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                        int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                        int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                        int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                        decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                        decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                        string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                        string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                        int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                        byte[] picture = null;
                                        if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                            picture = (byte[])reader["Picture"];
                                        }
                                        UC_TProduk buffer = new UC_TProduk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                        buffer.InfoButton += UserControl_InfoButton;
                                        buffer.ADDButton += UserControl_ADD;
                                        flp_Jabatan.Controls.Add(buffer);
                                    }
                                } else {
                                    toastNotification = new Notification("Info", "No Product Found");
                                    toastNotification.Show();
                                }
                            }
                        }
                    } catch (Exception ex) {
                        RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            filter();
        }

        private void btn_BUY_Click(object sender, EventArgs e) {
            DataTable detailPembelianTable = new DataTable();
            detailPembelianTable.Columns.Add("id_produk", typeof(int));
            detailPembelianTable.Columns.Add("Qty", typeof(int));
            detailPembelianTable.Columns.Add("Harga", typeof(SqlMoney));
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    detailPembelianTable.Rows.Add(userControl.id, userControl.Transaction_Qty,userControl.TotalPrice);
                }
            }
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    using (SqlCommand command = new SqlCommand("SpInsertTransaksiPembelian", connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        decimal buffer = Decimal.Parse(L_Total.Text.Replace("Rp", "").Replace(".", ""));
                        buffer = buffer + (buffer * 11 / 100);
                        command.Parameters.Add(new SqlParameter("@id_supplier", SqlDbType.Int)).Value = cb_Supplier.SelectedValue;
                        command.Parameters.Add(new SqlParameter("@id_karyawan", SqlDbType.Int)).Value = IDEmployee;
                        command.Parameters.Add(new SqlParameter("@TotalHarga", SqlDbType.Money)).Value = buffer;
                        command.Parameters.Add(new SqlParameter("@DetailPembelian", SqlDbType.Structured)).Value = detailPembelianTable;

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        if(result == 0) {
                            toastNotification = new Notification("Info", "Order Failed");
                        } else {
                            toastNotification = new Notification("Info", "Order Success");
                        }
                        toastNotification.Show();
                    }
                }
            } catch (Exception ex) {
                RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Form formBackground = new Form();
            using (TransaksiPembelian report = new TransaksiPembelian()) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                report.StartPosition = FormStartPosition.CenterScreen;
                report.FormBorderStyle = FormBorderStyle.None;
                report.Owner = formBackground;
                report.ShowDialog();

                formBackground.Dispose();
            }
            autoId();
            LoadData();
            flp_BUY.Controls.Clear();
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                filter();
            }
        }

        private void txt_Search_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

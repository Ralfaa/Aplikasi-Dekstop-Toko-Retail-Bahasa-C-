﻿using CustomMessageBox;
using CustomMessageBox.Private;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using static ToastNotifications.FormAnimator;

namespace WarungMadura.Resources.Dashboard {
    public partial class Profile : Form {
        string connectionString = Properties.Resources.ConnectionString;
        private int idUser;

        public Profile(int id) {
            idUser = id;
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {

        }

        private void LoadData() {
            string query = $"SELECT * FROM FnGetEmployeeById({idUser})";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        /*                        command.Parameters.AddWithValue("@employeeId", idUser);*/
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.Read()) {
                                txt_employeid.Text = "EMP" + reader["id_karyawan"].ToString().PadLeft(5, '0');
                                txt_employename.Text = reader["NamaKaryawan"].ToString();
                                txt_username.Text = reader["Username"].ToString();
                                txt_password.Text = reader["Password"].ToString();
                                txt_position.Text = reader["NamaJabatan"].ToString();
                                txt_email.Text = reader["Email"].ToString();
                                txt_telp.Text = reader["NoTelepon"].ToString();
                                string buffer = reader["JenisKelamin"].ToString().ToUpper();
                                txt_gender.Text = buffer;
                                txt_addrress.Text = reader["Alamat"].ToString();
                                if(txt_employename.Text.Length > 15) {
                                    L_NameEmp.Text = txt_employename.Text.Substring(0,15)+"...";
                                } else {
                                    L_NameEmp.Text = txt_employename.Text;
                                }
                                // Retrieve image from database if available
                                byte[] imageData = reader["Picture"] as byte[];

                                if (imageData != null && imageData.Length > 0) {
                                    using (var ms = new System.IO.MemoryStream(imageData)) {
                                        gp_Employee.Image = Image.FromStream(ms);
                                    }
                                }
                                if (buffer == "MALE") {
                                    Pb_Character.Image = Properties.Resources.Man;
                                } else if (buffer == "FEMALE") {
                                    Pb_Character.Image = Properties.Resources.Women;
                                } else {
                                    Pb_Character.Image = null;
                                }
                            } else {

                                txt_employeid.Text = "";
                                txt_employename.Text = "";
                                txt_username.Text = "";
                                txt_password.Text = "";
                                txt_position.Text = "";
                                txt_email.Text = "";
                                txt_telp.Text = "";
                                txt_gender.Text = "";
                                txt_addrress.Text = "";
                                gp_Employee.Image = null;
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void pnl_Pictureset_Paint(object sender, PaintEventArgs e) {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e) {

        }

        private void gbtn_InsertPicture_Click_1(object sender, EventArgs e) {

        }

        private void label8_Click(object sender, EventArgs e) {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e) {

        }

        private void txt_gender_TextChanged(object sender, EventArgs e) {
    
        }
    }
}

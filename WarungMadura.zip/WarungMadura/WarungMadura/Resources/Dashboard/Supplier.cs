﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Supplier : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public Supplier() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {

        }
        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_supplier FROM Supplier ORDER BY id_supplier DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "SPR001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_supplier"]);
                            int newID = lastID + 1;

                            addID = "SPR" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_SupplierID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }
        private void LoadData() {
            flp_Product.Controls.Clear();
            string query = "select * from FnSearchSupplier(null,null)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    string SName = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    string Alamat = reader.GetString(reader.GetOrdinal("Alamat"));
                                    string NoTelp = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                    string Email = reader.GetString(reader.GetOrdinal("Email"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));


                                    UC_Supplier buffer = new UC_Supplier(id, SName, Alamat, NoTelp, Email, status);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Product.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Supplier Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void UserControl_InfoButton(object sender, SupplierEventArgs e) {

            Form formBackground = new Form();
            using (SupplierInfo productInfo = new SupplierInfo(e.id_Supplier, e.NamaSupplier, e.Alamat, e.NoTelp, e.Email)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                productInfo.StartPosition = FormStartPosition.CenterScreen;
                productInfo.FormBorderStyle = FormBorderStyle.None;
                productInfo.Owner = formBackground;
                productInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private bool isUpdateSupplier = false;
        private void UserControl_EditButton(object sender, SupplierEventArgs e) {
            txt_SupplierID.Text = "SPR" + e.id_Supplier.ToString().PadLeft(3, '0');
            txt_Name.Text = e.NamaSupplier;
            txt_Alamat.Text = e.Alamat;
            txt_Email.Text = e.Email;
            txt_Telp.Text = e.NoTelp;
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdateSupplier = true;
        }
        private void UserControl_Restore(object sender, SupplierEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateSupplierById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Supplier id : " + e.id_Supplier + "\n With name Supplier : " + e.NamaSupplier, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_supplier", e.id_Supplier);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }
        private void UserControl_Delete(object sender, SupplierEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeleteSupplierById";
                DialogResult = RJMessageBox.Show("Are you sure to delete Supplier id : " + e.id_Supplier + "\n With name Supplier : " + e.NamaSupplier, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_supplier", e.id_Supplier);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Supplier Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdateSupplier) {
                doClear = UpdateSupplier();
            } else {
                doClear = InsertSupplier();
            }
            toastNotification.Show();
            if (doClear)
                clear(true);
        }
        public void clear(bool reset = false) {
            autoId();
            isUpdateSupplier = false;
            txt_Name.Clear();
            txt_Telp.Clear();
            txt_Alamat.Clear();
            txt_Email.Clear();
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if(reset) LoadData();
        }
        private int TrueName() {
            string query = "SELECT COUNT(*) FROM Supplier WHERE NamaSupplier = @Nama AND id_supplier <> @id_supplier AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                command.Parameters.AddWithValue("@id_supplier", int.Parse(txt_SupplierID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueTelp() {
            string query = "SELECT COUNT(*) FROM Supplier WHERE NoTelepon = @NoTelp AND id_supplier <> @id_supplier AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NoTelp", txt_Telp.Text);
                command.Parameters.AddWithValue("@id_supplier", int.Parse(txt_SupplierID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueEmail() {
            string query = "SELECT COUNT(*) FROM Supplier WHERE Email = @Email AND id_supplier <> @id_supplier AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", txt_Email.Text);
                command.Parameters.AddWithValue("@id_supplier", int.Parse(txt_SupplierID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private bool InsertSupplier() {
            if (txt_Name.Text == ""
                || txt_Name.Text == ""
                || txt_Alamat.Text == ""
                || txt_Telp.Text == ""
                || txt_Email.Text == ""
                ) {
                toastNotification = new Notification("Info", "Uncompleted Data");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Info", "Email not valid");
                return false;
            } else if (txt_Telp.Text.Length < 10) {
                toastNotification = new Notification("Info", "Phone length must more than 10");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Supplier Name Already Exists");
                return false;
            } else if (TrueEmail() == 1) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else if (TrueTelp() == 1) {
                toastNotification = new Notification("Warning", "Phone Number Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpInsertSupplier";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@NamaSupplier", txt_Name.Text);
                        command.Parameters.AddWithValue("@Alamat", txt_Alamat.Text);
                        command.Parameters.AddWithValue("@NoTelepon", txt_Telp.Text);
                        command.Parameters.AddWithValue("@Email", txt_Email.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Insert Failed");
                        } else {
                            toastNotification = new Notification("Successfully", " Supplier Inserted");
                        }
                    }
                    return true;
                }
            }
        }
        private bool UpdateSupplier() {
            if (txt_Name.Text == ""
                || txt_Name.Text == ""
                || txt_Alamat.Text == ""
                || txt_Telp.Text == ""
                || txt_Email.Text == "") 
                {
                toastNotification = new Notification("Info", "Uncompleted Data");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Info", "Email not valid");
                return false;
            } else if (txt_Telp.Text.Length < 10) {
                toastNotification = new Notification("Info", "Phone length must more than 10");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Supplier Name Already Exists");
                return false;
            } else if (TrueEmail() == 1) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else if (TrueTelp() == 1) {
                toastNotification = new Notification("Warning", "Phone Number Already Exists");
                return false;
            } else {

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpUpdateSupplier";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        string id_supplier = txt_SupplierID.Text.Substring(3);
                        int id_supplierint = int.Parse(id_supplier);
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_supplier", id_supplierint);
                        command.Parameters.AddWithValue("@NamaSupplier", txt_Name.Text);
                        command.Parameters.AddWithValue("@Alamat", txt_Alamat.Text);
                        command.Parameters.AddWithValue("@NoTelepon", txt_Telp.Text);
                        command.Parameters.AddWithValue("@Email", txt_Email.Text);
                        command.Parameters.AddWithValue("@Status", 1);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Supplier Updated");
                        }
                        return true;
                    }
                }
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 145) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 145;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }

        }

        private void guna2Button1_Click(object sender, EventArgs e) {
            clear();
        }
        private void txt_KeyPressTelp(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }

            // Memeriksa panjang no telp
            if (txt_Telp.Text.Length >= 13 && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }

        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private void txt_KeyPressAlamat(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) &&
                e.KeyChar != ',' && e.KeyChar != '.' && e.KeyChar != '/' && e.KeyChar != '\r' && e.KeyChar != '-') {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private bool EmailValidation() {
            Regex regex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
            if (!regex.IsMatch(txt_Email.Text)) {
                return false;
            } else {
                return true;
            }
        }
        private void filter() {
            flp_Product.Controls.Clear();
            string query = $"select * from FnSearchSupplier('{cb_SortType.Text}','{txt_Search.Text}')";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    string SName = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    string Alamat = reader.GetString(reader.GetOrdinal("Alamat"));
                                    string NoTelp = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                    string Email = reader.GetString(reader.GetOrdinal("Email"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));


                                    UC_Supplier buffer = new UC_Supplier(id, SName, Alamat, NoTelp, Email, status);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Product.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Supplier Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (p_filterExpand) {
                timer_filter.Start();
            }
        }
        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            filter();
        }

        private void btn_ClearF_Click(object sender, EventArgs e) {
            cb_SortType.SelectedIndex = -1;
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                filter();
            }
        }
    }
}

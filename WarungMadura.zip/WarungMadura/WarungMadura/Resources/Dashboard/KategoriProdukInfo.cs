﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class KategoriProdukInfo : Form {
        public KategoriProdukInfo() {
            InitializeComponent();
        }
        private void ProductInfo_Load(object sender, EventArgs e) {
        }

        public KategoriProdukInfo(int id, string KJName, string HakAkses) {
            InitializeComponent();

            txt_IdCategories.Text = "UNT" + id.ToString().PadLeft(3, '0');

            txt_CategoriesName.Text = KJName;
            txt_Unit.Text = HakAkses;
        }
        private void label7_Click(object sender, EventArgs e) {

        }

        private void guna2TextBox7_TextChanged(object sender, EventArgs e) {

        }

        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void bnt_Exit_Click(object sender, EventArgs e) {
            timer_Closing.Start();
        }
    }
}

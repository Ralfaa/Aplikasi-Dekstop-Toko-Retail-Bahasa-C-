﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class ManagerDashboard : Form {
        string connectionString = Properties.Resources.ConnectionString;

        public ManagerDashboard() {
            InitializeComponent();
        }
        private void AdminDashboard_Load(object sender, EventArgs e) {
            start_date.Value = new DateTime(DateTime.Now.Year, 1, 1, 0, 0, 0);
            end_date.Value = new DateTime(DateTime.Now.Year, 12, 31, 0, 0, 0);
            loadData();
            LoadChartData();
        }
        private void loadData() {

            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    int produkCount = GetCountFromFunction("dbo.CountProduk");
                    int customerCount = GetCountFromFunction("dbo.CountMember");
                    int distributorCount = GetCountFromFunction("dbo.CountSupplier");
                    int employeeCount = GetCountFromFunction("dbo.CountKaryawan");

                    // Display counts in respective textboxes
                    txt_product.Text = produkCount.ToString();
                    txt_member.Text = customerCount.ToString();
                    txt_distributor.Text = distributorCount.ToString();
                    txt_employee.Text = employeeCount.ToString();

                    DateTime startDate = new DateTime(start_date.Value.Year, start_date.Value.Month, start_date.Value.Day, 0, 0, 0);

                    // Set the end date time to 23:59:00
                    DateTime endDate = new DateTime(end_date.Value.Year, end_date.Value.Month, end_date.Value.Day, 23, 59, 0);
                    //endDate.AddDays(1);
                    object ostarDate = null;
                    object oendDate = null;
                    if (startDate == DateTime.Today && endDate == DateTime.Today) {
                        ostarDate = null;
                        oendDate = null;
                    } else {
                        ostarDate = startDate.Date;
                        oendDate = endDate.AddDays(1).Date;
                    }


                    string query = "sp_GetRevenueExpenditure";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@StartDate", (object)ostarDate ?? DBNull.Value);

                    command.Parameters.Add("@EndDate", (object)oendDate ?? DBNull.Value);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    PopulateChart(dataTable);
                    DisplayTotalHargaRevenue();
                    DisplayTotalHargaExpenditure();
                    DisplayTotalOrder();
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void PopulateChart(DataTable dataTable) {
            ChartTransaction.Series.Clear();

            // Series for Revenue
            Series revenueSeries = new Series {
                Name = "Revenue",
                Color = System.Drawing.ColorTranslator.FromHtml("#149F97"),
                ChartType = SeriesChartType.Column
            };

            // Series for Expenditure
            Series expenditureSeries = new Series {
                Name = "Expenditure",
                Color = System.Drawing.ColorTranslator.FromHtml("#016186"),
                ChartType = SeriesChartType.Column
            };

            ChartTransaction.Series.Add(revenueSeries);
            ChartTransaction.Series.Add(expenditureSeries);

            foreach (DataRow row in dataTable.Rows) {
                //DateTime period = Convert.ToDateTime();
                decimal revenue = Convert.ToDecimal(row[1]);
                decimal expenditure = Convert.ToDecimal(row[2]);

                revenueSeries.Points.AddXY(row[0].ToString(), revenue);
                expenditureSeries.Points.AddXY(row[0].ToString(), expenditure);
            }

            // Optionally adjust the chart to better display date values
            ChartTransaction.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd";
            ChartTransaction.ChartAreas[0].AxisX.Interval = 1;
            ChartTransaction.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Days;
        }
        private int GetCountFromFunction(string functionName) {
            int count = 0;

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(functionName, connection);
                command.CommandType = CommandType.StoredProcedure; // Assuming these are stored procedures

                try {
                    connection.Open();
                    SqlParameter returnParameter = command.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;

                    command.ExecuteNonQuery();
                    count = (int)returnParameter.Value;
                } catch (Exception ex) {
                    MessageBox.Show("Error retrieving count: " + ex.Message);
                }
            }

            return count;
        }

        private void DisplayTotalHargaRevenue() {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "SELECT dbo.GetTotalHargaTransaksi(@startDate, @endDate) AS TotalHarga";

                DateTime startDate = new DateTime(start_date.Value.Year, start_date.Value.Month, start_date.Value.Day, 0, 0, 0);
                DateTime endDate = new DateTime(end_date.Value.Year, end_date.Value.Month, end_date.Value.Day, 23, 59, 0);
                object ostarDate = null;
                object oendDate = null;
                // Mengatasi nilai DateTime.Today
                if (startDate == DateTime.Today && endDate == DateTime.Today) {
                    ostarDate = null;
                    oendDate = null;
                } else {
                    ostarDate = startDate.Date;
                    oendDate = endDate.AddDays(1).Date;
                }

                using (SqlCommand command = new SqlCommand(query, connection)) {
                    // Tambahkan parameter @startDate
                    SqlParameter paramStartDate = new SqlParameter("@startDate", SqlDbType.Date);
                    paramStartDate.Value = (object)ostarDate ?? DBNull.Value;
                    command.Parameters.Add(paramStartDate);

                    // Tambahkan parameter @endDate
                    SqlParameter paramEndDate = new SqlParameter("@endDate", SqlDbType.Date);
                    paramEndDate.Value = (object)oendDate ?? DBNull.Value;
                    command.Parameters.Add(paramEndDate);

                    try {
                        // Buka koneksi
                        connection.Open();

                        // Eksekusi perintah dan baca hasil
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read()) {
                            // Ambil nilai TotalHarga
                            decimal totalHarga = reader.GetDecimal(reader.GetOrdinal("TotalHarga"));

                            // Tampilkan nilai TotalHarga di TextBox (txt_totalrevenue)
                            txt_totalrevenue.Text = totalHarga.ToString("C");
                        }
                        reader.Close();
                    } catch (SqlException ex) {
                        MessageBox.Show("SQL Error: " + ex.Message);
                    } catch (Exception ex) {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
        private void LoadChartData() {
            string query = "GetTop5BestSellingProducts";
            DateTime startDate = new DateTime(start_date.Value.Year, start_date.Value.Month, start_date.Value.Day, 0, 0, 0);

            // Set the end date time to 23:59:00
            DateTime endDate = new DateTime(end_date.Value.Year, end_date.Value.Month, end_date.Value.Day, 23, 59, 0);
            object ostarDate = null;
            object oendDate = null;
            if (startDate == DateTime.Today && endDate == DateTime.Today) {
                ostarDate = null;
                oendDate = null;
            } else {
                ostarDate = startDate.Date;
                oendDate = endDate.AddDays(1).Date;
            }
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@StartDate", (object)ostarDate ?? DBNull.Value);

                command.Parameters.Add("@EndDate", (object)oendDate ?? DBNull.Value);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                try {
                    connection.Open();
                    adapter.Fill(dataTable);
                    PopulateChartPIE(dataTable);
                } catch (Exception ex) {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private void DisplayTotalHargaExpenditure() {

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                // Query SQL untuk memanggil fungsi dbo.GetTotalHargaTransaksi
                string query = "SELECT dbo.GetTotalHargaTransaksiExpenditure(@startDate, @endDate) AS TotalHarga";

                DateTime startDate = new DateTime(start_date.Value.Year, start_date.Value.Month, start_date.Value.Day, 0, 0, 0);
                DateTime endDate = new DateTime(end_date.Value.Year, end_date.Value.Month, end_date.Value.Day, 23, 59, 0);
                object ostarDate = null;
                object oendDate = null;
                // Mengatasi nilai DateTime.Today
                if (startDate == DateTime.Today && endDate == DateTime.Today) {
                    ostarDate = null;
                    oendDate = null;
                } else {
                    ostarDate = startDate.Date;
                    oendDate = endDate.AddDays(1).Date;
                }


                // Buat command SQL
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    // Tambahkan parameter @startDate
                    SqlParameter paramStartDate = new SqlParameter("@startDate", SqlDbType.Date);
                    paramStartDate.Value = (object)ostarDate ?? DBNull.Value;
                    command.Parameters.Add(paramStartDate);

                    // Tambahkan parameter @endDate
                    SqlParameter paramEndDate = new SqlParameter("@endDate", SqlDbType.Date);
                    paramEndDate.Value = (object)oendDate ?? DBNull.Value;
                    command.Parameters.Add(paramEndDate);

                    try {
                        // Buka koneksi
                        connection.Open();

                        // Eksekusi perintah dan baca hasil
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read()) {
                            // Ambil nilai TotalHarga
                            decimal totalHarga = reader.GetDecimal(reader.GetOrdinal("TotalHarga"));

                            // Tampilkan nilai TotalHarga di TextBox (txt_totalrevenue)
                            txt_expenditure.Text = totalHarga.ToString("C");
                        }
                        reader.Close();
                    } catch (Exception ex) {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void DisplayTotalOrder() {

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                // Query SQL untuk memanggil fungsi dbo.GetTotalHargaTransaksi
                string query = "SELECT dbo.GetJumlahTransaksiPenjualan(@startDate, @endDate) AS TotalOrder";

                DateTime startDate = new DateTime(start_date.Value.Year, start_date.Value.Month, start_date.Value.Day, 0, 0, 0);
                DateTime endDate = new DateTime(end_date.Value.Year, end_date.Value.Month, end_date.Value.Day, 23, 59, 0);
                object ostarDate = null;
                object oendDate = null;
                // Mengatasi nilai DateTime.Today
                if (startDate == DateTime.Today && endDate == DateTime.Today) {
                    ostarDate = null;
                    oendDate = null;
                } else {
                    ostarDate = startDate.Date;
                    oendDate = endDate.AddDays(1).Date;
                }


                // Buat command SQL
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    // Tambahkan parameter @startDate
                    SqlParameter paramStartDate = new SqlParameter("@startDate", SqlDbType.Date);
                    paramStartDate.Value = (object)ostarDate ?? DBNull.Value;
                    command.Parameters.Add(paramStartDate);

                    // Tambahkan parameter @endDate
                    SqlParameter paramEndDate = new SqlParameter("@endDate", SqlDbType.Date);
                    paramEndDate.Value = (object)oendDate ?? DBNull.Value;
                    command.Parameters.Add(paramEndDate);

                    try {
                        // Buka koneksi
                        connection.Open();

                        // Eksekusi perintah dan baca hasil
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read()) {
                            // Ambil nilai TotalHarga
                            int totalorder = reader.GetInt32(reader.GetOrdinal("TotalOrder"));

                            // Tampilkan nilai TotalHarga di TextBox (txt_totalrevenue)
                            txt_jumlahorder.Text = totalorder.ToString();
                        }
                        reader.Close();
                    } catch (Exception ex) {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void PopulateChartPIE(DataTable dataTable) {
            chart1.Series.Clear();
            Color[] bufferColors = new Color[]{
                ColorTranslator.FromHtml("#5DB3E0"),
                ColorTranslator.FromHtml("#004476"),
                ColorTranslator.FromHtml("#0F6896"),
                ColorTranslator.FromHtml("#167BAF"),
                ColorTranslator.FromHtml("#3E9FD1")

            };
            Series series = new Series("Total Sold") {
                ChartType = SeriesChartType.Pie
            };
            int TotalProductSold = 0;
            foreach (DataRow row in dataTable.Rows) {
                TotalProductSold += Convert.ToInt32(row["TotalTerjual"]);
            }
            int colorIndex = 0;
            foreach (DataRow row in dataTable.Rows) {
                string productName = row["NamaProduk"].ToString();
                int totalSold = Convert.ToInt32(row["TotalTerjual"]);
                float bufferfloatpercent = ((float)totalSold / (float)TotalProductSold) * 100;
                string bufferPercentage = bufferfloatpercent.ToString("F2");
                DataPoint point = new DataPoint();
                point.LabelForeColor = Color.White;
                point.SetValueXY(productName, totalSold);
                point.Label = bufferPercentage + "%"; // Display number on pie
                point.Font = new Font("Arial", 12);
                point.LegendText = productName;
                point.Color = bufferColors[colorIndex];
                series.Points.Add(point);
                colorIndex++;
            }

            chart1.Series.Add(series);

            ChartArea chartArea = chart1.ChartAreas[0];
            chartArea.AxisX.Title = "Product Name";
            chartArea.AxisY.Title = "Total Sold";

            chart1.Titles.Clear();
            Title chartTitle = chart1.Titles.Add("Top 5 Best Selling Products");
            chartTitle.Font = new System.Drawing.Font("Arial", 16, FontStyle.Bold);

            // Optional: Customize the pie chart appearance
            series["PieLabelStyle"] = "Inside";
            series.BorderWidth = 1;
            series.BorderColor = System.Drawing.Color.FromArgb(255, 255, 255);
            series.Font = new System.Drawing.Font("Arial", 12);
        }
        private void CustomizeColumn(string columnName) {

        }

        private void guna2CustomGradientPanel3_Paint(object sender, PaintEventArgs e) {

        }

        private void guna2DateTimePicker2_ValueChanged(object sender, EventArgs e) {

        }

        private void btn_Apply_Click(object sender, EventArgs e) {
            loadData();
            LoadChartData();
        }

        private void btn_ResetDay_Click(object sender, EventArgs e) {
            start_date.Value = DateTime.Now;
            end_date.Value = DateTime.Now;
            btn_Apply.PerformClick();
        }
    }
}

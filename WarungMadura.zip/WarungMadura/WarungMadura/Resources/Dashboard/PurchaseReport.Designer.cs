﻿using System.Threading;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    partial class PurchaseReport {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.Gpnl_Produk_Data = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.btn_ResetDay = new Guna.UI2.WinForms.Guna2Button();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2CustomGradientPanel3 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_Print = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Apply = new Guna.UI2.WinForms.Guna2Button();
            this.DTM_End = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.DTM_Start = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.dgv_SalesReport = new Guna.UI2.WinForms.Guna2DataGridView();
            this.gpnl_CreateData = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.btn_clear = new Guna.UI2.WinForms.Guna2Button();
            this.txt_DatePurchases = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_EmpPurchases = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_PricePurchases = new Guna.UI2.WinForms.Guna2TextBox();
            this.btn_DetailOrders = new Guna.UI2.WinForms.Guna2Button();
            this.txt_SupplierPurchases = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Purchases = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.Gpnl_Produk_Data.SuspendLayout();
            this.guna2CustomGradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SalesReport)).BeginInit();
            this.gpnl_CreateData.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel1.BorderRadius = 10;
            this.guna2CustomGradientPanel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2CustomGradientPanel1.Controls.Add(this.Gpnl_Produk_Data);
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(7, 100);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(1180, 678);
            this.guna2CustomGradientPanel1.TabIndex = 1;
            // 
            // Gpnl_Produk_Data
            // 
            this.Gpnl_Produk_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Gpnl_Produk_Data.BackColor = System.Drawing.Color.White;
            this.Gpnl_Produk_Data.BorderRadius = 6;
            this.Gpnl_Produk_Data.Controls.Add(this.btn_ResetDay);
            this.Gpnl_Produk_Data.Controls.Add(this.label5);
            this.Gpnl_Produk_Data.Controls.Add(this.guna2CustomGradientPanel3);
            this.Gpnl_Produk_Data.Controls.Add(this.btn_Print);
            this.Gpnl_Produk_Data.Controls.Add(this.btn_Apply);
            this.Gpnl_Produk_Data.Controls.Add(this.DTM_End);
            this.Gpnl_Produk_Data.Controls.Add(this.DTM_Start);
            this.Gpnl_Produk_Data.Controls.Add(this.dgv_SalesReport);
            this.Gpnl_Produk_Data.Controls.Add(this.gpnl_CreateData);
            this.Gpnl_Produk_Data.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.Location = new System.Drawing.Point(5, 18);
            this.Gpnl_Produk_Data.Name = "Gpnl_Produk_Data";
            this.Gpnl_Produk_Data.Size = new System.Drawing.Size(1172, 647);
            this.Gpnl_Produk_Data.TabIndex = 9;
            // 
            // btn_ResetDay
            // 
            this.btn_ResetDay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ResetDay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_ResetDay.BorderRadius = 6;
            this.btn_ResetDay.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_ResetDay.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_ResetDay.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_ResetDay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_ResetDay.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_ResetDay.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ResetDay.ForeColor = System.Drawing.Color.White;
            this.btn_ResetDay.Location = new System.Drawing.Point(460, 23);
            this.btn_ResetDay.Name = "btn_ResetDay";
            this.btn_ResetDay.Size = new System.Drawing.Size(82, 46);
            this.btn_ResetDay.TabIndex = 21;
            this.btn_ResetDay.Text = "Reset";
            this.btn_ResetDay.TextOffset = new System.Drawing.Point(1, -3);
            this.btn_ResetDay.Click += new System.EventHandler(this.btn_ResetDay_Click);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(199, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 32);
            this.label5.TabIndex = 1;
            this.label5.Text = "Until";
            // 
            // guna2CustomGradientPanel3
            // 
            this.guna2CustomGradientPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.guna2CustomGradientPanel3.BorderRadius = 6;
            this.guna2CustomGradientPanel3.BorderThickness = 1;
            this.guna2CustomGradientPanel3.Controls.Add(this.label4);
            this.guna2CustomGradientPanel3.ForeColor = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel3.Location = new System.Drawing.Point(716, 23);
            this.guna2CustomGradientPanel3.Name = "guna2CustomGradientPanel3";
            this.guna2CustomGradientPanel3.Size = new System.Drawing.Size(437, 46);
            this.guna2CustomGradientPanel3.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(71, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(294, 37);
            this.label4.TabIndex = 0;
            this.label4.Text = "Detail Information";
            // 
            // btn_Print
            // 
            this.btn_Print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Print.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Print.BorderRadius = 6;
            this.btn_Print.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Print.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Print.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Print.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Print.FillColor = System.Drawing.Color.White;
            this.btn_Print.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.Black;
            this.btn_Print.Image = global::WarungMadura.Properties.Resources.Print;
            this.btn_Print.ImageSize = new System.Drawing.Size(35, 35);
            this.btn_Print.Location = new System.Drawing.Point(644, 23);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(50, 46);
            this.btn_Print.TabIndex = 19;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // btn_Apply
            // 
            this.btn_Apply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Apply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Apply.BorderRadius = 6;
            this.btn_Apply.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Apply.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Apply.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Apply.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Apply.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Apply.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Apply.ForeColor = System.Drawing.Color.White;
            this.btn_Apply.Location = new System.Drawing.Point(543, 23);
            this.btn_Apply.Name = "btn_Apply";
            this.btn_Apply.Size = new System.Drawing.Size(98, 46);
            this.btn_Apply.TabIndex = 8;
            this.btn_Apply.Text = "Apply";
            this.btn_Apply.TextOffset = new System.Drawing.Point(4, -3);
            this.btn_Apply.Click += new System.EventHandler(this.btn_Apply_Click);
            // 
            // DTM_End
            // 
            this.DTM_End.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DTM_End.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.DTM_End.BorderRadius = 6;
            this.DTM_End.Checked = true;
            this.DTM_End.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.DTM_End.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.DTM_End.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DTM_End.Location = new System.Drawing.Point(279, 21);
            this.DTM_End.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DTM_End.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DTM_End.Name = "DTM_End";
            this.DTM_End.Size = new System.Drawing.Size(175, 46);
            this.DTM_End.TabIndex = 18;
            this.DTM_End.Value = new System.DateTime(2024, 7, 11, 0, 0, 0, 0);
            // 
            // DTM_Start
            // 
            this.DTM_Start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DTM_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.DTM_Start.BorderRadius = 6;
            this.DTM_Start.Checked = true;
            this.DTM_Start.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.DTM_Start.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTM_Start.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DTM_Start.Location = new System.Drawing.Point(17, 21);
            this.DTM_Start.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DTM_Start.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DTM_Start.Name = "DTM_Start";
            this.DTM_Start.Size = new System.Drawing.Size(176, 46);
            this.DTM_Start.TabIndex = 17;
            this.DTM_Start.Value = new System.DateTime(2024, 7, 11, 0, 0, 0, 0);
            // 
            // dgv_SalesReport
            // 
            this.dgv_SalesReport.AllowUserToAddRows = false;
            this.dgv_SalesReport.AllowUserToDeleteRows = false;
            this.dgv_SalesReport.AllowUserToResizeColumns = false;
            this.dgv_SalesReport.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dgv_SalesReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_SalesReport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(78)))), ((int)(((byte)(97)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_SalesReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_SalesReport.ColumnHeadersHeight = 40;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(237)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_SalesReport.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_SalesReport.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv_SalesReport.Location = new System.Drawing.Point(17, 75);
            this.dgv_SalesReport.Name = "dgv_SalesReport";
            this.dgv_SalesReport.ReadOnly = true;
            this.dgv_SalesReport.RowHeadersVisible = false;
            this.dgv_SalesReport.RowHeadersWidth = 40;
            this.dgv_SalesReport.RowTemplate.Height = 30;
            this.dgv_SalesReport.Size = new System.Drawing.Size(679, 541);
            this.dgv_SalesReport.TabIndex = 16;
            this.dgv_SalesReport.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgv_SalesReport.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgv_SalesReport.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgv_SalesReport.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgv_SalesReport.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgv_SalesReport.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgv_SalesReport.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_SalesReport.ThemeStyle.HeaderStyle.Height = 40;
            this.dgv_SalesReport.ThemeStyle.ReadOnly = true;
            this.dgv_SalesReport.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgv_SalesReport.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgv_SalesReport.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_SalesReport.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgv_SalesReport.ThemeStyle.RowsStyle.Height = 30;
            this.dgv_SalesReport.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgv_SalesReport.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgv_SalesReport.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_SalesReport_CellClick);
            // 
            // gpnl_CreateData
            // 
            this.gpnl_CreateData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpnl_CreateData.AutoScroll = true;
            this.gpnl_CreateData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gpnl_CreateData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.gpnl_CreateData.BorderRadius = 6;
            this.gpnl_CreateData.Controls.Add(this.btn_clear);
            this.gpnl_CreateData.Controls.Add(this.txt_DatePurchases);
            this.gpnl_CreateData.Controls.Add(this.label7);
            this.gpnl_CreateData.Controls.Add(this.txt_EmpPurchases);
            this.gpnl_CreateData.Controls.Add(this.label6);
            this.gpnl_CreateData.Controls.Add(this.txt_PricePurchases);
            this.gpnl_CreateData.Controls.Add(this.btn_DetailOrders);
            this.gpnl_CreateData.Controls.Add(this.txt_SupplierPurchases);
            this.gpnl_CreateData.Controls.Add(this.txt_Purchases);
            this.gpnl_CreateData.Controls.Add(this.label3);
            this.gpnl_CreateData.Controls.Add(this.label2);
            this.gpnl_CreateData.Controls.Add(this.label1);
            this.gpnl_CreateData.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.Location = new System.Drawing.Point(716, 75);
            this.gpnl_CreateData.Name = "gpnl_CreateData";
            this.gpnl_CreateData.Size = new System.Drawing.Size(437, 541);
            this.gpnl_CreateData.TabIndex = 0;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_clear.BorderRadius = 6;
            this.btn_clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_clear.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_clear.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.White;
            this.btn_clear.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_clear.ImageOffset = new System.Drawing.Point(10, 0);
            this.btn_clear.Location = new System.Drawing.Point(243, 774);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(168, 40);
            this.btn_clear.TabIndex = 36;
            this.btn_clear.Text = "Clear";
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click_1);
            // 
            // txt_DatePurchases
            // 
            this.txt_DatePurchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_DatePurchases.BorderRadius = 6;
            this.txt_DatePurchases.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_DatePurchases.DefaultText = "";
            this.txt_DatePurchases.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_DatePurchases.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_DatePurchases.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_DatePurchases.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_DatePurchases.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_DatePurchases.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DatePurchases.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_DatePurchases.Location = new System.Drawing.Point(16, 262);
            this.txt_DatePurchases.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_DatePurchases.Name = "txt_DatePurchases";
            this.txt_DatePurchases.PasswordChar = '\0';
            this.txt_DatePurchases.PlaceholderText = "";
            this.txt_DatePurchases.ReadOnly = true;
            this.txt_DatePurchases.SelectedText = "";
            this.txt_DatePurchases.Size = new System.Drawing.Size(390, 36);
            this.txt_DatePurchases.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 234);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 24);
            this.label7.TabIndex = 32;
            this.label7.Text = "Date";
            // 
            // txt_EmpPurchases
            // 
            this.txt_EmpPurchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_EmpPurchases.BorderRadius = 6;
            this.txt_EmpPurchases.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_EmpPurchases.DefaultText = "";
            this.txt_EmpPurchases.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_EmpPurchases.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_EmpPurchases.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_EmpPurchases.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_EmpPurchases.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_EmpPurchases.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmpPurchases.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_EmpPurchases.Location = new System.Drawing.Point(17, 189);
            this.txt_EmpPurchases.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_EmpPurchases.Name = "txt_EmpPurchases";
            this.txt_EmpPurchases.PasswordChar = '\0';
            this.txt_EmpPurchases.PlaceholderText = "";
            this.txt_EmpPurchases.ReadOnly = true;
            this.txt_EmpPurchases.SelectedText = "";
            this.txt_EmpPurchases.Size = new System.Drawing.Size(390, 36);
            this.txt_EmpPurchases.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 24);
            this.label6.TabIndex = 30;
            this.label6.Text = "Employee";
            // 
            // txt_PricePurchases
            // 
            this.txt_PricePurchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_PricePurchases.BorderRadius = 6;
            this.txt_PricePurchases.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_PricePurchases.DefaultText = "";
            this.txt_PricePurchases.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_PricePurchases.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_PricePurchases.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_PricePurchases.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_PricePurchases.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_PricePurchases.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PricePurchases.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_PricePurchases.Location = new System.Drawing.Point(13, 337);
            this.txt_PricePurchases.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_PricePurchases.Name = "txt_PricePurchases";
            this.txt_PricePurchases.PasswordChar = '\0';
            this.txt_PricePurchases.PlaceholderText = "";
            this.txt_PricePurchases.ReadOnly = true;
            this.txt_PricePurchases.SelectedText = "";
            this.txt_PricePurchases.Size = new System.Drawing.Size(390, 36);
            this.txt_PricePurchases.TabIndex = 27;
            // 
            // btn_DetailOrders
            // 
            this.btn_DetailOrders.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_DetailOrders.BorderRadius = 6;
            this.btn_DetailOrders.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_DetailOrders.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_DetailOrders.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_DetailOrders.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_DetailOrders.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_DetailOrders.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DetailOrders.ForeColor = System.Drawing.Color.White;
            this.btn_DetailOrders.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_DetailOrders.ImageOffset = new System.Drawing.Point(10, 0);
            this.btn_DetailOrders.Location = new System.Drawing.Point(10, 774);
            this.btn_DetailOrders.Name = "btn_DetailOrders";
            this.btn_DetailOrders.Size = new System.Drawing.Size(217, 40);
            this.btn_DetailOrders.TabIndex = 22;
            this.btn_DetailOrders.Text = "Detail Order";
            this.btn_DetailOrders.Click += new System.EventHandler(this.btn_DetailOrders_Click);
            // 
            // txt_SupplierPurchases
            // 
            this.txt_SupplierPurchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_SupplierPurchases.BorderRadius = 6;
            this.txt_SupplierPurchases.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_SupplierPurchases.DefaultText = "";
            this.txt_SupplierPurchases.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_SupplierPurchases.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_SupplierPurchases.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_SupplierPurchases.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_SupplierPurchases.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_SupplierPurchases.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SupplierPurchases.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_SupplierPurchases.Location = new System.Drawing.Point(17, 116);
            this.txt_SupplierPurchases.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_SupplierPurchases.Name = "txt_SupplierPurchases";
            this.txt_SupplierPurchases.PasswordChar = '\0';
            this.txt_SupplierPurchases.PlaceholderText = "";
            this.txt_SupplierPurchases.ReadOnly = true;
            this.txt_SupplierPurchases.SelectedText = "";
            this.txt_SupplierPurchases.Size = new System.Drawing.Size(390, 36);
            this.txt_SupplierPurchases.TabIndex = 4;
            // 
            // txt_Purchases
            // 
            this.txt_Purchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Purchases.BorderRadius = 6;
            this.txt_Purchases.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Purchases.DefaultText = "";
            this.txt_Purchases.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Purchases.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Purchases.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Purchases.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Purchases.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Purchases.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Purchases.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Purchases.Location = new System.Drawing.Point(18, 42);
            this.txt_Purchases.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Purchases.Name = "txt_Purchases";
            this.txt_Purchases.PasswordChar = '\0';
            this.txt_Purchases.PlaceholderText = "";
            this.txt_Purchases.ReadOnly = true;
            this.txt_Purchases.SelectedText = "";
            this.txt_Purchases.Size = new System.Drawing.Size(148, 36);
            this.txt_Purchases.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 310);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Total Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Supplier";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Purchase";
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.SystemColors.Control;
            this.guna2CustomGradientPanel2.BorderRadius = 6;
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(7, 30);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(1180, 359);
            this.guna2CustomGradientPanel2.TabIndex = 2;
            // 
            // PurchaseReport
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2CustomGradientPanel2);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PurchaseReport";
            this.Text = "Produk";
            this.EnabledChanged += new System.EventHandler(this.Produk_EnabledChanged);
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.Gpnl_Produk_Data.ResumeLayout(false);
            this.Gpnl_Produk_Data.PerformLayout();
            this.guna2CustomGradientPanel3.ResumeLayout(false);
            this.guna2CustomGradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SalesReport)).EndInit();
            this.gpnl_CreateData.ResumeLayout(false);
            this.gpnl_CreateData.PerformLayout();
            this.ResumeLayout(false);

        }
        /*        private void LoadObjectsOnForm() {
                    // Simulate a delay to mimic loading time
                    Thread.Sleep(2000); // Adjust the delay time as needed
                        // 
                        // txt_Search
                        // 
                        this.txt_Search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
                        this.txt_Search.BackColor = System.Drawing.Color.Transparent;
                        this.txt_Search.BorderRadius = 10;
                        this.txt_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
                        this.txt_Search.DefaultText = "";
                        this.txt_Search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
                        this.txt_Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
                        this.txt_Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                        this.txt_Search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                        this.txt_Search.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
                        this.txt_Search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                        this.txt_Search.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                        this.txt_Search.ForeColor = System.Drawing.Color.White;
                        this.txt_Search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                        this.txt_Search.Location = new System.Drawing.Point(22, 38);
                        this.txt_Search.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
                        this.txt_Search.NameDiscount = "txt_Search";
                        this.txt_Search.PasswordChar = '\0';
                        this.txt_Search.PlaceholderForeColor = System.Drawing.Color.White;
                        this.txt_Search.PlaceholderText = "Search...";
                        this.txt_Search.SelectedText = "";
                        this.txt_Search.Size = new System.Drawing.Size(649, 46);
                        this.txt_Search.TabIndex = 0;
                }*/

        #endregion
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel gpnl_CreateData;
        private Guna.UI2.WinForms.Guna2Button btn_DetailOrders;
        private Guna.UI2.WinForms.Guna2TextBox txt_SupplierPurchases;
        private Guna.UI2.WinForms.Guna2TextBox txt_Purchases;
        private Label label3;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btn_Apply;
        private Guna.UI2.WinForms.Guna2TextBox txt_PricePurchases;
        private Guna.UI2.WinForms.Guna2TextBox txt_EmpPurchases;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txt_DatePurchases;
        private Label label7;
        private Guna.UI2.WinForms.Guna2Button btn_clear;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel Gpnl_Produk_Data;
        private Guna.UI2.WinForms.Guna2DataGridView dgv_SalesReport;
        private Guna.UI2.WinForms.Guna2DateTimePicker DTM_Start;
        private Guna.UI2.WinForms.Guna2DateTimePicker DTM_End;
        private Guna.UI2.WinForms.Guna2Button btn_Print;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel3;
        private Label label4;
        private Label label5;
        private Guna.UI2.WinForms.Guna2Button btn_ResetDay;
    }
}
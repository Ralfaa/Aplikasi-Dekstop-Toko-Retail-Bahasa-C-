﻿using CustomMessageBox;
using CustomMessageBox.Private;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using static ToastNotifications.FormAnimator;
using System.Text.RegularExpressions;

namespace WarungMadura.Resources.Dashboard {
    public partial class Karyawan : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public Karyawan() {
            InitializeComponent();
        }


        private void gbtn_InsertPicture_Click(object sender, EventArgs e) {
            string imageloc = "";
            try {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png";
                if(dialog.ShowDialog() == DialogResult.OK) {
                    imageloc = dialog.FileName;
                    FileInfo fileInfo = new FileInfo(imageloc);
                    long fileSizeInBytes = fileInfo.Length;
                    long fileSizeInMB = fileSizeInBytes / (1024 * 1024);

                    // 1 MB limit
                    if (fileSizeInMB > 0) {
                        toastNotification = new Notification("Warning","Max picture size 1MB");
                    } else {
                        gp_Karyawan.ImageLocation = imageloc;
                        gp_Karyawan.SizeMode = PictureBoxSizeMode.Zoom;
                        toastNotification = new Notification("Info","Picture inserted succesfully");
                    }
                    toastNotification.Show();
                }
            }catch(Exception ex) {
                MessageBox.Show(ex.ToString());
            }
        }
        private byte[] ImageToByteArray(Image image) {
            try {
                using (MemoryStream ms = new MemoryStream()) {
                    // Save the image to the MemoryStream
                    image.Save(ms, image.RawFormat);
                    return ms.ToArray();
                }
            } catch (Exception ex) {
                MessageBox.Show($"An error occurred while converting the image: {ex.Message}");
                return null;
            }
        }

        private void autoId()
        {
            try
            {
                string query = "SELECT TOP 1 id_karyawan FROM Karyawan ORDER BY id_karyawan DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "EMP001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0)
                        {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_karyawan"]);
                            int newID = lastID + 1;

                            addID = "EMP" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_employeeID.Text = addID;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
            }
        }

        private void LihatComboboxJabatan()
        {
            try
            {
                using (SqlConnection myConnection = new SqlConnection(connectionString))
                {
                    myConnection.Open();

                    SqlCommand myCommand = new SqlCommand("SELECT NamaJabatan FROM KategoriJabatan where status = 1", myConnection);

                    using (SqlDataReader reader = myCommand.ExecuteReader())
                    {
                        cb_position.Items.Clear();
                        cb_SearchPosition.Items.Clear();

                        while (reader.Read())
                        {
                            cb_position.Items.Add(reader["NamaJabatan"].ToString());
                            cb_SearchPosition.Items.Add(reader["NamaJabatan"].ToString());
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LoadData() {
            txt_employeeID.ReadOnly = true;
            flp_Product.Controls.Clear();
            string query = "select * from FnSearchEmployee(null,null,null)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_karyawan"));
                                    int idJabatan = reader.GetInt32(reader.GetOrdinal("id_jabatan"));
                                    string namaJabatan = reader.GetString(reader.GetOrdinal("NamaJabatan"));
                                    string namaKaryawan = reader.GetString(reader.GetOrdinal("NamaKaryawan"));
                                    string Username = reader.GetString(reader.GetOrdinal("Username"));
                                    string Password = reader.GetString(reader.GetOrdinal("Password"));
                                    string Alamat = reader.GetString(reader.GetOrdinal("Alamat"));
                                    string Telp = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                    string Email = reader.GetString(reader.GetOrdinal("Email"));
                                    string Gender = reader.GetString(reader.GetOrdinal("JenisKelamin"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));


                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }
                                    UC_Karyawan buffer = new UC_Karyawan(id, namaKaryawan, Username, Password, Alamat, Telp, Email, Gender, idJabatan, namaJabatan, picture, status);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                     buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Product.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Employee Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this,$"An error occurred: {ex.Message}","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }
        private void UserControl_InfoButton(object sender, KaryawanEventArgs e) {
           
            Form formBackground = new Form();
            using (KaryawanInfo karyawanInfo = new KaryawanInfo(e.id_Karyawan, e.NamaKaryawan, e.Username, e.Password, e.Alamat, e.Telp, e.Email, e.Gender, e.id_jabatan, e.NamaJabatan, e.Picture)) {
                formBackground.Owner = this;
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                karyawanInfo.StartPosition = FormStartPosition.CenterScreen;
                karyawanInfo.FormBorderStyle = FormBorderStyle.None;
                karyawanInfo.Owner = formBackground;
                karyawanInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private bool isUpdateEmployee = false;
        private byte[] ImageEdit = null;
        private string DPass;
        private void UserControl_EditButton(object sender, KaryawanEventArgs e) { 
            txt_employeeID.Text ="EMP"+ e.id_Karyawan.ToString().PadLeft(3, '0');
            txt_Name.Text = e.NamaKaryawan;
            txt_username.Text = e.Username;
            txt_password.Text = e.Password;
            txt_telp.Text = e.Telp;
            txt_email.Text = e.Email;
            txt_address.Text = e.Alamat;
            cb_gender.Text = e.Gender;
            cb_position.Text = e.NamaJabatan;
            DPass = e.Password;
            ImageEdit = e.Picture;
            if (e.Picture != null && e.Picture.Length > 0) {
                using (var ms = new System.IO.MemoryStream(e.Picture)) {
                    gp_Karyawan.Image = Image.FromStream(ms);
                }
            } else {
                gp_Karyawan.Image = null;
            }
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdateEmployee = true;
        }
        private void UserControl_Restore(object sender, KaryawanEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateEmployeeById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Employee id : " + e.id_Karyawan + "\n With employee name : " + e.NamaKaryawan, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_karyawan", e.id_Karyawan);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }
        private void UserControl_Delete (object sender, KaryawanEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                DialogResult = RJMessageBox.Show("Are you sure to delete Employee id : " + e.id_Karyawan+"\n With Employee NameDiscount : "+e.NamaKaryawan, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    string query = "DeleteKaryawanById";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_karyawan", e.id_Karyawan);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Employee Deleted");
                            reset = true;
                        }
                    }
                }  else {
                    toastNotification = new Notification("Info", "Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdateEmployee) {
                doClear = UpdateEmployee();
            } else {
                doClear = InsertEmployee();
            }
            toastNotification.Show();
            if (doClear)
                clear(true);
        }
        public void clear(bool reset = false) {
            autoId();
            isUpdateEmployee = false;
            ImageEdit = null;
            txt_username.Clear();
            txt_password.Clear();
            txt_Name.Clear();
            txt_telp.Clear();
            txt_email.Clear();
            txt_address.Clear();
            cb_gender.SelectedItem  = null;
            cb_position.SelectedItem = null;

            gp_Karyawan.ImageLocation = null;
            gp_Karyawan.Image = null;
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if(reset)LoadData();
        }
        private bool IsULCasePassword(string password) {
            bool containsUpperCase = Regex.IsMatch(password, "[A-Z]");
            bool containsLowerCase = Regex.IsMatch(password, "[a-z]");

            return containsUpperCase && containsLowerCase;
        }        
        private bool IsNumberPassword(string password) {
            bool containsNumber = Regex.IsMatch(password, "[0-9]");

            return containsNumber;
        }
        private bool EmailValidation() {
            Regex regex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
            if (!regex.IsMatch(txt_email.Text)) {
                return false;
            } else {
                return true;
            }
        }      

        private bool InsertEmployee() {
            if(txt_Name.Text == "" 
                || txt_telp.Text == ""
                || txt_email.Text == ""
                || txt_address.Text == ""
                || txt_password.Text == ""
                || txt_username.Text == ""                                   
                || cb_position.Text == ""
                || cb_gender.Text == ""
                ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (!IsULCasePassword(txt_password.Text) ) {
                toastNotification = new Notification("Warning", "Pass need lower upper case");
                return false;
            }else if (!IsNumberPassword(txt_password.Text) ) {
                toastNotification = new Notification("Warning", "Pass need number");
                return false;
            }else if (txt_password.Text.Length < 6) {
                toastNotification = new Notification("Warning", "Pass length must more than 5");
                return false;
            }else if (txt_telp.Text.Length < 10) {
                toastNotification = new Notification("Warning", "Telp length must more than 10");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Warning", "Email not valid");
                return false;
            } else if (TrueUser() > 0) {
                toastNotification = new Notification("Warning", "Username Already Exists");
                return false;
            }else if (TrueTelp() > 0) {
                toastNotification = new Notification("Warning", "No Telephone Already Exists");
                return false;
            }else if (TrueEmail() > 0) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpInsertKaryawan";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        byte[] buffer = null;
                        if (gp_Karyawan.ImageLocation != null) {
                            buffer = ImageToByteArray(Image.FromFile(gp_Karyawan.ImageLocation));
                        }

                        int idJabatan = GetJabatanId(cb_position.Text);

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jabatan", idJabatan);
                        command.Parameters.AddWithValue("@NamaKaryawan", txt_Name.Text);
                        command.Parameters.AddWithValue("@Username", txt_username.Text);
                        command.Parameters.AddWithValue("@Password", txt_password.Text);
                        command.Parameters.AddWithValue("@Alamat", txt_address.Text);
                        command.Parameters.AddWithValue("@NoTelepon", txt_telp.Text);
                        command.Parameters.AddWithValue("@Email", txt_email.Text);
                        command.Parameters.AddWithValue("@JenisKelamin", cb_gender.Text);

                        command.Parameters.Add(new SqlParameter("@Picture", SqlDbType.VarBinary) { Value = (object)buffer ?? DBNull.Value });
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Insert Failed");
                        } else {
                            toastNotification = new Notification("Successfully", " Employee Inserted");
                        }
                    }
                    return true;
                }
            }
        }

        private int GetJabatanId(string namaJabatan)
        {
            int jabatanId = 0;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT dbo.GetJabatanIdByName(@namaJabatan)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@namaJabatan", namaJabatan);
                        connection.Open();
                        jabatanId = (int)command.ExecuteScalar();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return jabatanId;
        }
        private int TrueUser() {
            string query = "SELECT COUNT(*) FROM Karyawan WHERE Username = @Username AND id_karyawan <> @id_karyawan AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", txt_username.Text);
                command.Parameters.AddWithValue("@id_karyawan", int.Parse(txt_employeeID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueTelp() {
            string query = "SELECT COUNT(*) FROM Karyawan WHERE NoTelepon = @NoTelp AND id_karyawan <> @id_karyawan AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NoTelp", txt_telp.Text);
                command.Parameters.AddWithValue("@id_karyawan", int.Parse(txt_employeeID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueEmail() {
            string query = "SELECT COUNT(*) FROM Karyawan WHERE Email = @Email AND id_karyawan <> @id_karyawan AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", txt_email.Text);
                command.Parameters.AddWithValue("@id_karyawan", int.Parse(txt_employeeID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private bool UpdateEmployee() {
            if (txt_Name.Text == ""
            || txt_telp.Text == ""
            || txt_email.Text == ""
            || txt_address.Text == ""
            || txt_password.Text == ""
            || txt_username.Text == ""
            || cb_position.Text == ""
            || cb_gender.Text == ""
            ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (!IsULCasePassword(txt_password.Text)) {
                toastNotification = new Notification("Warning", "Pass need lower upper case");
                return false;
            } else if (!IsNumberPassword(txt_password.Text)) {
                toastNotification = new Notification("Warning", "Pass need number");
                return false;
            } else if (txt_password.Text.Length < 6) {
                toastNotification = new Notification("Warning", "Pass length must more than 5");
                return false;
            } else if (txt_telp.Text.Length < 10) {
                toastNotification = new Notification("Warning", "Pass length must more than 10");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Warning", "Email not valid");
                return false;
            } else if (TrueUser() > 0) {
                toastNotification = new Notification("Warning", "Username Already Exists");
                return false;
            } else if (TrueTelp() > 0) {
                toastNotification = new Notification("Warning", "No Telephone Already Exists");
                return false;
            } else if (TrueEmail() > 0) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else {
                string id_karyawan = txt_employeeID.Text.Substring(3);
                int id_karyawann = int.Parse(id_karyawan);

                int idJabatan = GetJabatanId(cb_position.Text);
                if(TrueUser()==0) {
                    using (SqlConnection connection = new SqlConnection(connectionString)) {
                        string query = "SpUpdateKaryawan";
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            byte[] buffer = null;
                            if (gp_Karyawan.ImageLocation != null) {
                                buffer = ImageToByteArray(Image.FromFile(gp_Karyawan.ImageLocation));
                            } else {
                                if (ImageEdit != null) {
                                    buffer = ImageEdit;
                                }
                            }


                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@id_karyawan", id_karyawann);
                            command.Parameters.AddWithValue("@id_jabatan", idJabatan);
                            command.Parameters.AddWithValue("@NamaKaryawan", txt_Name.Text);
                            command.Parameters.AddWithValue("@Username", txt_username.Text);
                            command.Parameters.AddWithValue("@Password", txt_password.Text == DPass ? null : txt_password.Text);
                            command.Parameters.AddWithValue("@Alamat", txt_address.Text);
                            command.Parameters.AddWithValue("@NoTelepon", txt_telp.Text);
                            command.Parameters.AddWithValue("@Email", txt_email.Text);
                            command.Parameters.AddWithValue("@JenisKelamin", cb_gender.Text);
                            command.Parameters.AddWithValue("@Picture", buffer);
                            command.Parameters.AddWithValue("@Status", 1);

                            connection.Open();
                            int result = command.ExecuteNonQuery();
                            connection.Close();
                            if (result == 0) {
                                toastNotification = new Notification("Info", "Update Failed");
                            } else {
                                toastNotification = new Notification("Successfully", "Employee Updated");
                            }
                            return true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Warning", "Username Already Exists");
                    return false;
                }
                
            }
        }

        private void pnl_Pictureset_Paint(object sender, PaintEventArgs e)
        {

        }
        private void txt_KeyPressTelp(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }

            // Memeriksa panjang no telp
            if (txt_telp.Text.Length >= 13 && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }        
        private void txt_KeyPressPass(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }        
        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private void txt_KeyPressAlamat(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar)&&!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) &&
                e.KeyChar != ',' && e.KeyChar != '.' && e.KeyChar != '/' && e.KeyChar != '\r' && e.KeyChar != '-') {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e) {
            timer_Filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_Filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 225) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 225;
                    timer_Filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_Filter.Stop();
                    p_filterExpand = false;
                }
            }
        }
        private void cari() {
            p_filterExpand = true;
            timer_Filter.Start();
            flp_Product.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "select * from FnSearchEmployee(@sort_by, @search_name, @search_job_name)";
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    command.Parameters.AddWithValue("@sort_by", cb_SortType.Text);
                    command.Parameters.AddWithValue("@search_name", txt_Search.Text);
                    command.Parameters.AddWithValue("@search_job_name", cb_SearchPosition.Text);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader()) {
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                int id = reader.GetInt32(reader.GetOrdinal("id_karyawan"));
                                int idJabatan = reader.GetInt32(reader.GetOrdinal("id_jabatan"));
                                string namaJabatan = reader.GetString(reader.GetOrdinal("NamaJabatan"));
                                string namaKaryawan = reader.GetString(reader.GetOrdinal("NamaKaryawan"));
                                string Username = reader.GetString(reader.GetOrdinal("Username"));
                                string Password = reader.GetString(reader.GetOrdinal("Password"));
                                string Alamat = reader.GetString(reader.GetOrdinal("Alamat"));
                                string Telp = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                string Email = reader.GetString(reader.GetOrdinal("Email"));
                                string Gender = reader.GetString(reader.GetOrdinal("JenisKelamin"));
                                int status = reader.GetInt32(reader.GetOrdinal("Status"));


                                byte[] picture = null;
                                if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                    picture = (byte[])reader["Picture"];
                                }
                                UC_Karyawan buffer = new UC_Karyawan(id, namaKaryawan, Username, Password, Alamat, Telp, Email, Gender, idJabatan, namaJabatan, picture, status);
                                buffer.InfoButton += UserControl_InfoButton;
                                buffer.DeleteButton += UserControl_Delete;
                                if (status.Equals(0)) {
                                    buffer.EditButton += UserControl_Restore;
                                } else {
                                    buffer.EditButton += UserControl_EditButton;
                                }
                                flp_Product.Controls.Add(buffer);
                            }
                        } else {
                            toastNotification = new Notification("Info", "No Employee Found");
                            toastNotification.Show();
                        }
                    }
                }
            }
        }
        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            cari();
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if(e.KeyChar == (char)Keys.Enter) {
                cari();
            }
        }

        private void btn_clearfilter_Click(object sender, EventArgs e) {
            cb_SearchPosition.SelectedItem = null;
            cb_SortType.SelectedItem = null;
            p_filterExpand = true;
            timer_Filter.Start();
        }

        private void btn_Clear_Click(object sender, EventArgs e) {
            clear();
        }

        private void Karyawan_EnabledChanged(object sender, EventArgs e) {
            LihatComboboxJabatan();
            LoadData();
            autoId();
        }
    }
}

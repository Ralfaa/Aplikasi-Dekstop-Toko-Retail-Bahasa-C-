﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class DiskonInfo : Form {
        public DiskonInfo() {
            InitializeComponent();
        }

        public DiskonInfo(int id, string Categories, string PName, string desc, string startDate, string endDate, int percentage, decimal rule) {
            InitializeComponent();
            txt_IdDiscount.Text = "DSC" + id.ToString().PadLeft(3, '0');
            txt_Name.Text = PName;
            txt_Categories.Text = Categories;
            txt_Desc.Text = desc;
            txt_startDate.Text = startDate;
            txt_rule.Text = "Rp. "+rule.ToString("N0");
            txt_endDate.Text = endDate;
            txt_percentage.Text = percentage.ToString();
        }
        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void bnt_Exit_Click(object sender, EventArgs e) {
            timer_Closing.Start();
        }
    }
}

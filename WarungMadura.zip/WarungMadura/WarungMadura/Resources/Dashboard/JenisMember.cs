﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class JenisMember : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public JenisMember() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {

        }

        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_jenis_member FROM JenisMember ORDER BY id_jenis_member DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "JM001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_jenis_member"]);
                            int newID = lastID + 1;

                            addID = "TL" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_JenisMemberID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }


        private void LoadData() {
            flp_Jabatan.Controls.Clear();
            string query = "select * from FnSearchJenisMember(null,null,null)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("Nama"));
                                    int minPoint = reader.GetInt32(reader.GetOrdinal("MinPoint"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_JenisMember buffer = new UC_JenisMember(id, KJName, status, minPoint);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Category Member Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void filter() {
            flp_Jabatan.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    string query = "SELECT * FROM FnSearchJenisMember(@sort_by, @search_name, @min_point)";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.Parameters.AddWithValue("@sort_by", cb_SortType.SelectedItem == null ? DBNull.Value : cb_SortType.SelectedItem);

                        if (cb_SortType.Text == "Min Point") {
                            command.Parameters.AddWithValue("@min_point", txt_Search.Text);
                            command.Parameters.AddWithValue("@search_name", DBNull.Value);
                        } else {
                            command.Parameters.AddWithValue("@search_name", txt_Search.Text);
                            command.Parameters.AddWithValue("@min_point", DBNull.Value);
                        }
                            
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("Nama"));
                                    int minPoint = reader.GetInt32(reader.GetOrdinal("MinPoint"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_JenisMember buffer = new UC_JenisMember(id, KJName, status, minPoint);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Category Member Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (p_filterExpand) {
                timer_filter.Start();
            }

        }
        private bool isUpdatePosition = false;
        private void UserControl_EditButton(object sender, JenisMemberEventArgs e) {
            // txt_PositionID.Text = e.id_Categories.ToString();
            txt_JenisMemberID.Text = "TL" + e.id_jenis_member.ToString().PadLeft(3, '0');

            txt_Name.Text = e.Nama;
            txt_MinPoint.Text = e.MinPoint.ToString();
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdatePosition = true;
        }

        private void UserControl_Restore(object sender, JenisMemberEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateMemberCategoriesById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Categoriy Member id : " + e.id_jenis_member + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jenis_member", e.id_jenis_member);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }

        private void UserControl_Delete(object sender, JenisMemberEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeleteJenisMemberById";
                DialogResult = RJMessageBox.Show("Are you sure to delete Category Member id : " + e.id_jenis_member + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jenis_member", e.id_jenis_member);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Category Member Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void UserControl_InfoButton(object sender, JenisMemberEventArgs e) {
            Form formBackground = new Form();
            using (JenisMemberInfo jabatanInfo = new JenisMemberInfo(e.id_jenis_member, e.Nama, e.MinPoint)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                jabatanInfo.StartPosition = FormStartPosition.CenterScreen;
                jabatanInfo.FormBorderStyle = FormBorderStyle.None;
                jabatanInfo.Owner = formBackground;
                jabatanInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdatePosition) {
                doClear = UpdateJenisMember();
            } else {
                doClear = InsertJenisMember();
            }
            toastNotification.Show();
            if (doClear)
                clear(true);
        }
        public void clear(bool reset = false) {
            autoId();
            isUpdatePosition = false;
            txt_Name.Clear();
            txt_MinPoint.Clear();
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if (reset)LoadData();
        }
        private int TrueName() {
            string query = "SELECT COUNT(*) FROM JenisMember WHERE Nama = @Nama AND id_jenis_member <> @id_jenis_member AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                command.Parameters.AddWithValue("@id_jenis_member", int.Parse(txt_JenisMemberID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }

        private bool InsertJenisMember() {
            if (txt_Name.Text == "" || txt_MinPoint.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Royalty Name Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpInsertJenisMember";
                    using (SqlCommand command = new SqlCommand(query, connection)) {

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@NamaJenisMember", txt_Name.Text);
                        command.Parameters.AddWithValue("@MinPoint", txt_MinPoint.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Insert Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Category Member Inserted");
                        }
                    }
                    return true;
                }
            }
        }
        private bool UpdateJenisMember() {
            if (txt_Name.Text == "" || txt_MinPoint.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Royalty Name Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpUpdateJenisMember";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        // Mengambil hanya angka dari txt_PositionID.Text
                        // string id_jabatan = Regex.Replace(txt_PositionID.Text, "[^0-9]", "");

                        string id_jenisMember = txt_JenisMemberID.Text.Substring(2, 3);
                        int id_jenisMemberr = int.Parse(id_jenisMember);

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jenis_member", id_jenisMemberr);
                        command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                        command.Parameters.AddWithValue("@MinPoint", txt_MinPoint.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Category Member Updated");
                        }
                        return true;
                    }
                }
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 130) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 130;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }

        }

        private void txt_Search_Enter(object sender, EventArgs e) {
            filter();
        }

        private void btn_clear_Click(object sender, EventArgs e) {
            cb_SortType.Text = null;
        }

        private void txt_Name_KeyPress(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }

        private void txt_MinPoint_KeyPress(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void btn_clear_Click_1(object sender, EventArgs e) {
            clear();
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            filter();
        }
        private void txt_KeyPressNomor(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                filter();
            }
        }
    }
}

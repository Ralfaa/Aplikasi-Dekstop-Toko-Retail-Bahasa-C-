﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class MemberInfo : Form {
        public MemberInfo() {
            InitializeComponent();
        }

        public MemberInfo(int id, String Categories, string PName, string address, string phone, int point, string email) {
            InitializeComponent();
            txt_IdMember.Text = "MBR" + id.ToString().PadLeft(3, '0');
            txt_Name.Text = PName;
            txt_Categories.Text = Categories;
            txt_Address.Text = address;
            txt_Phone.Text = phone;
            txt_Point.Text = point.ToString();
            txt_Email.Text = email;
        }
    
        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void bnt_Exit_Click(object sender, EventArgs e) {
            timer_Closing.Start();
        }
    }
}

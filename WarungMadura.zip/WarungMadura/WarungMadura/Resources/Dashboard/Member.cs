﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Member : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public Member() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            LoadData();
            txt_Point.Text = "0";
        }
        private void Produk_Load(object sender, EventArgs e) {

        }

        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_member FROM Member ORDER BY id_member DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "MBR001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_member"]);
                            int newID = lastID + 1;

                            addID = "MBR" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_MemberID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }

        private void LoadData() {
            flp_Jabatan.Controls.Clear();
            string query = "select * from FnSearchMember(null,null,null)order by id_member";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_member"));
                                    int idCategory = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("NamaMember"));
                                    string JMName = reader.GetString(reader.GetOrdinal("NamaJenisMember"));
                                    string Address = reader.GetString(reader.GetOrdinal("Alamat"));
                                    string Phone = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                    string Email = reader.GetString(reader.GetOrdinal("Email"));
                                    int Point = reader.GetInt32(reader.GetOrdinal("Point"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_Member buffer = new UC_Member(id, idCategory, KJName, JMName, Address, Phone, Email, status, Point);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Member Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        private bool isUpdatePosition = false;

        private void filter() {
            flp_Jabatan.Controls.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    string query;

                    if (cb_SearchBy.Text.Equals("Member")) {
                        query = $"select * from FnSearchMember('{cb_SortType.SelectedItem}',null,'{txt_Search.Text}')";
                    } else {
                        query = $"select * from FnSearchMember('{cb_SortType.SelectedItem}','{txt_Search.Text}',null)";
                    }
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_member"));
                                    int idCategory = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("NamaMember"));
                                    string KJCategory = reader.GetString(reader.GetOrdinal("NamaJenisMember"));
                                    string Address = reader.GetString(reader.GetOrdinal("Alamat"));
                                    string Phone = reader.GetString(reader.GetOrdinal("NoTelepon"));
                                    string Email = reader.GetString(reader.GetOrdinal("Email"));
                                    int Point = reader.GetInt32(reader.GetOrdinal("Point"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_Member buffer = new UC_Member(id, idCategory, KJName,KJCategory, Address, Phone, Email, status, Point);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Member Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (p_filterExpand) {
                timer_filter.Start();
            }
        }

        private void UserControl_EditButton(object sender, MemberEventArgs e) {
            // txt_PositionID.Text = e.id_Categories.ToString();
            txt_MemberID.Text = "MBR" + e.id_member.ToString().PadLeft(3, '0');
            txt_Name.Text = e.Nama;
            txt_Address.Text = e.Address;
            txt_Phone.Text = e.Phone;
            txt_Email.Text = e.Email;
            txt_Point.Text = e.Point.ToString();
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdatePosition = true;
        }

        private void UserControl_Restore(object sender, MemberEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateMemberById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Member id : " + e.id_member + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_member", e.id_member);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }

        private void UserControl_Delete(object sender, MemberEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeleteMemberById";
                DialogResult = RJMessageBox.Show("Are you sure to delete Member id : " + e.id_member + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_member", e.id_member);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Member Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void UserControl_InfoButton(object sender, MemberEventArgs e) {
            Form formBackground = new Form();
            using (MemberInfo memberInfo = new MemberInfo(e.id_member, e.Categories, e.Nama, e.Address, e.Phone, e.Point, e.Email)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();


                memberInfo.StartPosition = FormStartPosition.CenterScreen;
                memberInfo.FormBorderStyle = FormBorderStyle.None;
                memberInfo.Owner = formBackground;
                memberInfo.ShowDialog();

                formBackground.Dispose();
            }
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdatePosition) {
                doClear = UpdateMember();
            } else {
                doClear = InsertMember();
            }
            toastNotification.Show();
            if (doClear)
                clear(true);
        }
        public void clear(bool reset = false ) {
            isUpdatePosition = false;
            autoId();
            txt_Name.Clear();
            txt_Address.Clear();
            txt_Email.Clear();
            txt_Phone.Clear();
            txt_Point.Text = "0";
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if (reset)LoadData();
        }
        private bool EmailValidation() {
            Regex regex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
            if (!regex.IsMatch(txt_Email.Text)) {
                return false;
            } else {
                return true;
            }
        }
        private int TrueName() {
            string query = "SELECT COUNT(*) FROM Member WHERE Nama = @Nama AND id_member <> @id_member AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                command.Parameters.AddWithValue("@id_member", int.Parse(txt_MemberID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueTelp() {
            string query = "SELECT COUNT(*) FROM Member WHERE NoTelepon = @NoTelp AND id_member <> @id_member AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NoTelp", txt_Phone.Text);
                command.Parameters.AddWithValue("@id_member", int.Parse(txt_MemberID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private int TrueEmail() {
            string query = "SELECT COUNT(*) FROM Member WHERE Email = @Email AND id_member <> @id_member AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", txt_Email.Text);
                command.Parameters.AddWithValue("@id_member", int.Parse(txt_MemberID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private bool InsertMember() {
            if (txt_Name.Text == "" || txt_Point.Text == "" || txt_Address.Text == "" || txt_Email.Text == "" || txt_Phone.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (txt_Phone.Text.Length < 10) {
                toastNotification = new Notification("Warning", "Phone length must more than 10");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Warning", "Email not valid");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Name Already Exists");
                return false;
            } else if (TrueEmail() == 1) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else if (TrueTelp() == 1) {
                toastNotification = new Notification("Warning", "Phone Number Already Exists");
                return false;
            } else {
                try {
                    using (SqlConnection connection = new SqlConnection(connectionString)) {
                        string query = "SpInsertMember";
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@id_jenis_member", null);
                            command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                            command.Parameters.AddWithValue("@Alamat", txt_Address.Text);
                            command.Parameters.AddWithValue("@NoTelepon", txt_Phone.Text);
                            command.Parameters.AddWithValue("@Email", txt_Email.Text);
                            command.Parameters.AddWithValue("@Point", 0);
                            command.Parameters.AddWithValue("@Status", 1);

                            connection.Open();
                            int result = command.ExecuteNonQuery();
                            connection.Close();
                            if (result == 0) {
                                toastNotification = new Notification("Info", "Insert Failed");
                            } else {
                                toastNotification = new Notification("Successfully", "Member Inserted");
                            }
                        }
                        return true;
                    }
                } catch (Exception ex) {
                    toastNotification = new Notification("Error", "Error: " + ex.Message);
                    return false;
                }

            }
        }

        private bool UpdateMember() {
            if (txt_Name.Text == "" || txt_Point.Text == "" || txt_Address.Text == "" || txt_Email.Text == "" || txt_Phone.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (txt_Phone.Text.Length < 10) {
                toastNotification = new Notification("Warning", "Phone length must more than 10");
                return false;
            } else if (!EmailValidation()) {
                toastNotification = new Notification("Warning", "Email not valid");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Member Name Already Exists");
                return false;
            } else if (TrueEmail() == 1) {
                toastNotification = new Notification("Warning", "Email Already Exists");
                return false;
            } else if (TrueTelp() == 1) {
                toastNotification = new Notification("Warning", "Phone Number Already Exists");
                return false;
            } else {

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpUpdateMember";
                    using (SqlCommand command = new SqlCommand(query, connection)) {


                        string id_member = txt_MemberID.Text.Substring(3, 3);
                        int id_memberr = int.Parse(id_member);

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_member", id_memberr);
                        command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                        command.Parameters.AddWithValue("@Alamat", txt_Address.Text);
                        command.Parameters.AddWithValue("@NoTelepon", txt_Phone.Text);
                        command.Parameters.AddWithValue("@Email", txt_Email.Text);
                        command.Parameters.AddWithValue("@Point", txt_Point.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Member Updated");
                        }
                        return true;
                    }

                }

                
            }
        }

        private void txt_KeyPressTelp(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }

            // Memeriksa panjang no telp
            if (txt_Phone.Text.Length >= 13 && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }

        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private void txt_KeyPressAlamat(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) &&
                e.KeyChar != ',' && e.KeyChar != '.' && e.KeyChar != '/' && e.KeyChar != '\r' && e.KeyChar != '-') {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 205) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 205;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }

        }

        private void KeypressNumber(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void btn_clear_Click(object sender, EventArgs e) {
            cb_SortType.Text = null;
            cb_SearchBy.Text = null;
        }

        private void btn_clear_Click_1(object sender, EventArgs e) {
            clear();
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            filter();
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                filter();
            }
        }
    }
}

﻿using System.Threading;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    partial class Produk {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Produk));
            this.Gpnl_Produk_Data = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.txt_QTY = new Guna.UI2.WinForms.Guna2TextBox();
            this.btn_Decrease = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Increase = new Guna.UI2.WinForms.Guna2Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.flp_Product = new System.Windows.Forms.FlowLayoutPanel();
            this.gpnl_CreateData = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.btn_Clear = new Guna.UI2.WinForms.Guna2Button();
            this.cb_CProduk = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_ExcData = new Guna.UI2.WinForms.Guna2Button();
            this.cb_Supplier = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnl_Pictureset = new Guna.UI2.WinForms.Guna2Panel();
            this.gbtn_InsertPicture = new Guna.UI2.WinForms.Guna2Button();
            this.gp_Product = new Guna.UI2.WinForms.Guna2PictureBox();
            this.txt_Discount = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Stock = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Sell = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Buy = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Name = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_ProductID = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.p_Filter = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.cb_SPSupplier = new Guna.UI2.WinForms.Guna2ComboBox();
            this.btn_clearF = new Guna.UI2.WinForms.Guna2Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cb_SPCategory = new Guna.UI2.WinForms.Guna2ComboBox();
            this.cb_SortType = new Guna.UI2.WinForms.Guna2ComboBox();
            this.btn_Filter = new Guna.UI2.WinForms.Guna2Button();
            this.txt_Search = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.ImageMenuName = new Guna.UI2.WinForms.Guna2PictureBox();
            this.timer_filter = new System.Windows.Forms.Timer(this.components);
            this.Gpnl_Produk_Data.SuspendLayout();
            this.gpnl_CreateData.SuspendLayout();
            this.pnl_Pictureset.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gp_Product)).BeginInit();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.p_Filter.SuspendLayout();
            this.guna2CustomGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageMenuName)).BeginInit();
            this.SuspendLayout();
            // 
            // Gpnl_Produk_Data
            // 
            this.Gpnl_Produk_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Gpnl_Produk_Data.BackColor = System.Drawing.Color.White;
            this.Gpnl_Produk_Data.BorderRadius = 6;
            this.Gpnl_Produk_Data.Controls.Add(this.txt_QTY);
            this.Gpnl_Produk_Data.Controls.Add(this.btn_Decrease);
            this.Gpnl_Produk_Data.Controls.Add(this.btn_Increase);
            this.Gpnl_Produk_Data.Controls.Add(this.label16);
            this.Gpnl_Produk_Data.Controls.Add(this.label10);
            this.Gpnl_Produk_Data.Controls.Add(this.label15);
            this.Gpnl_Produk_Data.Controls.Add(this.label12);
            this.Gpnl_Produk_Data.Controls.Add(this.flp_Product);
            this.Gpnl_Produk_Data.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.Location = new System.Drawing.Point(22, 116);
            this.Gpnl_Produk_Data.Name = "Gpnl_Produk_Data";
            this.Gpnl_Produk_Data.Size = new System.Drawing.Size(649, 529);
            this.Gpnl_Produk_Data.TabIndex = 1;
            this.Gpnl_Produk_Data.Paint += new System.Windows.Forms.PaintEventHandler(this.Gpnl_Produk_Data_Paint);
            // 
            // txt_QTY
            // 
            this.txt_QTY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_QTY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.txt_QTY.BorderColor = System.Drawing.Color.Black;
            this.txt_QTY.BorderThickness = 0;
            this.txt_QTY.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_QTY.CustomizableEdges.BottomRight = false;
            this.txt_QTY.CustomizableEdges.TopRight = false;
            this.txt_QTY.DefaultText = "1";
            this.txt_QTY.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_QTY.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_QTY.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_QTY.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_QTY.FillColor = System.Drawing.Color.Gainsboro;
            this.txt_QTY.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_QTY.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_QTY.ForeColor = System.Drawing.Color.Black;
            this.txt_QTY.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_QTY.Location = new System.Drawing.Point(65, 482);
            this.txt_QTY.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_QTY.MaxLength = 10;
            this.txt_QTY.Name = "txt_QTY";
            this.txt_QTY.PasswordChar = '\0';
            this.txt_QTY.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txt_QTY.PlaceholderText = "";
            this.txt_QTY.SelectedText = "";
            this.txt_QTY.Size = new System.Drawing.Size(52, 36);
            this.txt_QTY.TabIndex = 9;
            this.txt_QTY.TextChanged += new System.EventHandler(this.txt_QTY_TextChanged);
            this.txt_QTY.CursorChanged += new System.EventHandler(this.txt_QTY_CursorChanged);
            this.txt_QTY.Enter += new System.EventHandler(this.txt_QTY_Enter);
            this.txt_QTY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressPrice);
            this.txt_QTY.Leave += new System.EventHandler(this.txt_QTY_Leave);
            this.txt_QTY.MouseLeave += new System.EventHandler(this.txt_QTY_MouseLeave);
            // 
            // btn_Decrease
            // 
            this.btn_Decrease.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Decrease.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Decrease.BorderRadius = 8;
            this.btn_Decrease.CustomizableEdges.BottomRight = false;
            this.btn_Decrease.CustomizableEdges.TopRight = false;
            this.btn_Decrease.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Decrease.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Decrease.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Decrease.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Decrease.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_Decrease.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Decrease.ForeColor = System.Drawing.Color.White;
            this.btn_Decrease.Image = global::WarungMadura.Properties.Resources.ArrowPage2;
            this.btn_Decrease.ImageOffset = new System.Drawing.Point(-1, 0);
            this.btn_Decrease.Location = new System.Drawing.Point(27, 482);
            this.btn_Decrease.Name = "btn_Decrease";
            this.btn_Decrease.Size = new System.Drawing.Size(40, 36);
            this.btn_Decrease.TabIndex = 11;
            this.btn_Decrease.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btn_Increase
            // 
            this.btn_Increase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Increase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Increase.BorderRadius = 8;
            this.btn_Increase.CustomBorderThickness = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.btn_Increase.CustomizableEdges.BottomLeft = false;
            this.btn_Increase.CustomizableEdges.TopLeft = false;
            this.btn_Increase.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Increase.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Increase.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Increase.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Increase.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_Increase.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Increase.ForeColor = System.Drawing.Color.White;
            this.btn_Increase.Image = ((System.Drawing.Image)(resources.GetObject("btn_Increase.Image")));
            this.btn_Increase.ImageOffset = new System.Drawing.Point(1, 0);
            this.btn_Increase.Location = new System.Drawing.Point(114, 482);
            this.btn_Increase.Name = "btn_Increase";
            this.btn_Increase.Size = new System.Drawing.Size(40, 36);
            this.btn_Increase.TabIndex = 10;
            this.btn_Increase.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(619, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 24);
            this.label16.TabIndex = 4;
            this.label16.Text = "Supplier";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(434, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 24);
            this.label10.TabIndex = 3;
            this.label10.Text = "Categories";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(165, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 24);
            this.label15.TabIndex = 2;
            this.label15.Text = "Product Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(23, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 24);
            this.label12.TabIndex = 1;
            this.label12.Text = "Product ID";
            // 
            // flp_Product
            // 
            this.flp_Product.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flp_Product.AutoScroll = true;
            this.flp_Product.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.flp_Product.ForeColor = System.Drawing.Color.White;
            this.flp_Product.Location = new System.Drawing.Point(13, 45);
            this.flp_Product.Name = "flp_Product";
            this.flp_Product.Size = new System.Drawing.Size(625, 431);
            this.flp_Product.TabIndex = 0;
            // 
            // gpnl_CreateData
            // 
            this.gpnl_CreateData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpnl_CreateData.AutoScroll = true;
            this.gpnl_CreateData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gpnl_CreateData.BackColor = System.Drawing.Color.White;
            this.gpnl_CreateData.BorderRadius = 6;
            this.gpnl_CreateData.Controls.Add(this.btn_Clear);
            this.gpnl_CreateData.Controls.Add(this.cb_CProduk);
            this.gpnl_CreateData.Controls.Add(this.label11);
            this.gpnl_CreateData.Controls.Add(this.btn_ExcData);
            this.gpnl_CreateData.Controls.Add(this.cb_Supplier);
            this.gpnl_CreateData.Controls.Add(this.label9);
            this.gpnl_CreateData.Controls.Add(this.label8);
            this.gpnl_CreateData.Controls.Add(this.pnl_Pictureset);
            this.gpnl_CreateData.Controls.Add(this.txt_Discount);
            this.gpnl_CreateData.Controls.Add(this.txt_Stock);
            this.gpnl_CreateData.Controls.Add(this.label7);
            this.gpnl_CreateData.Controls.Add(this.label6);
            this.gpnl_CreateData.Controls.Add(this.txt_Sell);
            this.gpnl_CreateData.Controls.Add(this.txt_Buy);
            this.gpnl_CreateData.Controls.Add(this.label5);
            this.gpnl_CreateData.Controls.Add(this.label4);
            this.gpnl_CreateData.Controls.Add(this.txt_Name);
            this.gpnl_CreateData.Controls.Add(this.txt_ProductID);
            this.gpnl_CreateData.Controls.Add(this.label3);
            this.gpnl_CreateData.Controls.Add(this.label2);
            this.gpnl_CreateData.Controls.Add(this.label1);
            this.gpnl_CreateData.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.gpnl_CreateData.Location = new System.Drawing.Point(705, 37);
            this.gpnl_CreateData.Name = "gpnl_CreateData";
            this.gpnl_CreateData.Size = new System.Drawing.Size(460, 607);
            this.gpnl_CreateData.TabIndex = 0;
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_Clear.BorderRadius = 6;
            this.btn_Clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Clear.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Clear.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Clear.ImageOffset = new System.Drawing.Point(10, 0);
            this.btn_Clear.Location = new System.Drawing.Point(250, 802);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(182, 40);
            this.btn_Clear.TabIndex = 25;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // cb_CProduk
            // 
            this.cb_CProduk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.cb_CProduk.BorderRadius = 6;
            this.cb_CProduk.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_CProduk.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_CProduk.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_CProduk.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_CProduk.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_CProduk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_CProduk.IntegralHeight = false;
            this.cb_CProduk.ItemHeight = 30;
            this.cb_CProduk.Location = new System.Drawing.Point(24, 196);
            this.cb_CProduk.Name = "cb_CProduk";
            this.cb_CProduk.Size = new System.Drawing.Size(408, 36);
            this.cb_CProduk.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(374, 862);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 23;
            // 
            // btn_ExcData
            // 
            this.btn_ExcData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_ExcData.BorderRadius = 6;
            this.btn_ExcData.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_ExcData.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_ExcData.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_ExcData.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_ExcData.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_ExcData.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcData.ForeColor = System.Drawing.Color.White;
            this.btn_ExcData.Image = ((System.Drawing.Image)(resources.GetObject("btn_ExcData.Image")));
            this.btn_ExcData.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_ExcData.ImageOffset = new System.Drawing.Point(10, 0);
            this.btn_ExcData.Location = new System.Drawing.Point(15, 802);
            this.btn_ExcData.Name = "btn_ExcData";
            this.btn_ExcData.Size = new System.Drawing.Size(229, 40);
            this.btn_ExcData.TabIndex = 22;
            this.btn_ExcData.Text = "Add";
            this.btn_ExcData.Click += new System.EventHandler(this.btn_ExcData_Click);
            // 
            // cb_Supplier
            // 
            this.cb_Supplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.cb_Supplier.BorderRadius = 6;
            this.cb_Supplier.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_Supplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Supplier.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Supplier.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Supplier.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Supplier.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_Supplier.IntegralHeight = false;
            this.cb_Supplier.ItemHeight = 30;
            this.cb_Supplier.Location = new System.Drawing.Point(24, 269);
            this.cb_Supplier.Name = "cb_Supplier";
            this.cb_Supplier.Size = new System.Drawing.Size(408, 36);
            this.cb_Supplier.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 24);
            this.label9.TabIndex = 18;
            this.label9.Text = "Supplier";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(305, 318);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "Picture";
            // 
            // pnl_Pictureset
            // 
            this.pnl_Pictureset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.pnl_Pictureset.BorderRadius = 6;
            this.pnl_Pictureset.Controls.Add(this.gbtn_InsertPicture);
            this.pnl_Pictureset.Controls.Add(this.gp_Product);
            this.pnl_Pictureset.Location = new System.Drawing.Point(249, 345);
            this.pnl_Pictureset.Name = "pnl_Pictureset";
            this.pnl_Pictureset.Size = new System.Drawing.Size(180, 280);
            this.pnl_Pictureset.TabIndex = 15;
            // 
            // gbtn_InsertPicture
            // 
            this.gbtn_InsertPicture.BorderRadius = 6;
            this.gbtn_InsertPicture.CustomizableEdges.TopLeft = false;
            this.gbtn_InsertPicture.CustomizableEdges.TopRight = false;
            this.gbtn_InsertPicture.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gbtn_InsertPicture.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gbtn_InsertPicture.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gbtn_InsertPicture.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gbtn_InsertPicture.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gbtn_InsertPicture.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gbtn_InsertPicture.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbtn_InsertPicture.ForeColor = System.Drawing.Color.White;
            this.gbtn_InsertPicture.Location = new System.Drawing.Point(0, 240);
            this.gbtn_InsertPicture.Name = "gbtn_InsertPicture";
            this.gbtn_InsertPicture.Size = new System.Drawing.Size(180, 40);
            this.gbtn_InsertPicture.TabIndex = 1;
            this.gbtn_InsertPicture.Text = "Set";
            this.gbtn_InsertPicture.Click += new System.EventHandler(this.gbtn_InsertPicture_Click);
            // 
            // gp_Product
            // 
            this.gp_Product.BackColor = System.Drawing.Color.White;
            this.gp_Product.BorderRadius = 6;
            this.gp_Product.ImageRotate = 0F;
            this.gp_Product.Location = new System.Drawing.Point(0, 0);
            this.gp_Product.Name = "gp_Product";
            this.gp_Product.Size = new System.Drawing.Size(180, 240);
            this.gp_Product.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gp_Product.TabIndex = 0;
            this.gp_Product.TabStop = false;
            // 
            // txt_Discount
            // 
            this.txt_Discount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Discount.BorderRadius = 6;
            this.txt_Discount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Discount.DefaultText = "";
            this.txt_Discount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Discount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Discount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Discount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Discount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Discount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Discount.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Discount.Location = new System.Drawing.Point(25, 589);
            this.txt_Discount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Discount.Name = "txt_Discount";
            this.txt_Discount.PasswordChar = '\0';
            this.txt_Discount.PlaceholderText = "";
            this.txt_Discount.SelectedText = "";
            this.txt_Discount.Size = new System.Drawing.Size(190, 36);
            this.txt_Discount.TabIndex = 14;
            this.txt_Discount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressDisc);
            // 
            // txt_Stock
            // 
            this.txt_Stock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Stock.BorderRadius = 6;
            this.txt_Stock.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Stock.DefaultText = "";
            this.txt_Stock.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Stock.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Stock.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Stock.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Stock.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Stock.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Stock.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Stock.Location = new System.Drawing.Point(25, 426);
            this.txt_Stock.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Stock.Name = "txt_Stock";
            this.txt_Stock.PasswordChar = '\0';
            this.txt_Stock.PlaceholderText = "";
            this.txt_Stock.ReadOnly = true;
            this.txt_Stock.SelectedText = "";
            this.txt_Stock.Size = new System.Drawing.Size(190, 36);
            this.txt_Stock.TabIndex = 13;
            this.txt_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressPrice);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 561);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 24);
            this.label7.TabIndex = 12;
            this.label7.Text = "Discount";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Stock";
            // 
            // txt_Sell
            // 
            this.txt_Sell.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Sell.BorderRadius = 6;
            this.txt_Sell.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Sell.DefaultText = "";
            this.txt_Sell.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Sell.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Sell.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Sell.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Sell.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Sell.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Sell.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Sell.Location = new System.Drawing.Point(25, 506);
            this.txt_Sell.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Sell.Name = "txt_Sell";
            this.txt_Sell.PasswordChar = '\0';
            this.txt_Sell.PlaceholderText = "";
            this.txt_Sell.SelectedText = "";
            this.txt_Sell.Size = new System.Drawing.Size(190, 36);
            this.txt_Sell.TabIndex = 9;
            this.txt_Sell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Sell.TextChanged += new System.EventHandler(this.txt_Currency_TextChanged);
            this.txt_Sell.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressPrice);
            // 
            // txt_Buy
            // 
            this.txt_Buy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Buy.BorderRadius = 6;
            this.txt_Buy.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Buy.DefaultText = "";
            this.txt_Buy.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Buy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Buy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Buy.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Buy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Buy.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Buy.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Buy.Location = new System.Drawing.Point(25, 345);
            this.txt_Buy.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Buy.Name = "txt_Buy";
            this.txt_Buy.PasswordChar = '\0';
            this.txt_Buy.PlaceholderText = "";
            this.txt_Buy.SelectedText = "";
            this.txt_Buy.Size = new System.Drawing.Size(190, 36);
            this.txt_Buy.TabIndex = 8;
            this.txt_Buy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Buy.TextChanged += new System.EventHandler(this.txt_Currency_TextChanged);
            this.txt_Buy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressPrice);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 478);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "Sell Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Buy Price";
            // 
            // txt_Name
            // 
            this.txt_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_Name.BorderRadius = 6;
            this.txt_Name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Name.DefaultText = "";
            this.txt_Name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Name.Location = new System.Drawing.Point(26, 120);
            this.txt_Name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Name.MaxLength = 255;
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.PasswordChar = '\0';
            this.txt_Name.PlaceholderText = "";
            this.txt_Name.SelectedText = "";
            this.txt_Name.Size = new System.Drawing.Size(406, 36);
            this.txt_Name.TabIndex = 4;
            this.txt_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Name_KeyPress);
            // 
            // txt_ProductID
            // 
            this.txt_ProductID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.txt_ProductID.BorderRadius = 6;
            this.txt_ProductID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ProductID.DefaultText = "";
            this.txt_ProductID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_ProductID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_ProductID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ProductID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ProductID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ProductID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProductID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ProductID.Location = new System.Drawing.Point(26, 49);
            this.txt_ProductID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_ProductID.Name = "txt_ProductID";
            this.txt_ProductID.PasswordChar = '\0';
            this.txt_ProductID.PlaceholderText = "";
            this.txt_ProductID.ReadOnly = true;
            this.txt_ProductID.SelectedText = "";
            this.txt_ProductID.Size = new System.Drawing.Size(148, 36);
            this.txt_ProductID.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Categories Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product ID";
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel1.BorderRadius = 10;
            this.guna2CustomGradientPanel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2CustomGradientPanel1.Controls.Add(this.p_Filter);
            this.guna2CustomGradientPanel1.Controls.Add(this.btn_Filter);
            this.guna2CustomGradientPanel1.Controls.Add(this.gpnl_CreateData);
            this.guna2CustomGradientPanel1.Controls.Add(this.Gpnl_Produk_Data);
            this.guna2CustomGradientPanel1.Controls.Add(this.txt_Search);
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(7, 100);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(1180, 678);
            this.guna2CustomGradientPanel1.TabIndex = 1;
            // 
            // p_Filter
            // 
            this.p_Filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.p_Filter.Controls.Add(this.label17);
            this.p_Filter.Controls.Add(this.cb_SPSupplier);
            this.p_Filter.Controls.Add(this.btn_clearF);
            this.p_Filter.Controls.Add(this.label14);
            this.p_Filter.Controls.Add(this.label13);
            this.p_Filter.Controls.Add(this.cb_SPCategory);
            this.p_Filter.Controls.Add(this.cb_SortType);
            this.p_Filter.Location = new System.Drawing.Point(448, 89);
            this.p_Filter.MaximumSize = new System.Drawing.Size(212, 290);
            this.p_Filter.MinimumSize = new System.Drawing.Size(212, 12);
            this.p_Filter.Name = "p_Filter";
            this.p_Filter.ShadowDecoration.Depth = 15;
            this.p_Filter.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(7);
            this.p_Filter.Size = new System.Drawing.Size(212, 12);
            this.p_Filter.TabIndex = 5;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(25, 158);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 20);
            this.label17.TabIndex = 28;
            this.label17.Text = "Supplier";
            // 
            // cb_SPSupplier
            // 
            this.cb_SPSupplier.BackColor = System.Drawing.Color.White;
            this.cb_SPSupplier.BorderColor = System.Drawing.Color.Empty;
            this.cb_SPSupplier.BorderRadius = 6;
            this.cb_SPSupplier.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_SPSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_SPSupplier.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.cb_SPSupplier.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SPSupplier.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SPSupplier.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_SPSupplier.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_SPSupplier.ItemHeight = 30;
            this.cb_SPSupplier.Location = new System.Drawing.Point(25, 187);
            this.cb_SPSupplier.Name = "cb_SPSupplier";
            this.cb_SPSupplier.Size = new System.Drawing.Size(158, 36);
            this.cb_SPSupplier.TabIndex = 27;
            // 
            // btn_clearF
            // 
            this.btn_clearF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.btn_clearF.BorderRadius = 6;
            this.btn_clearF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_clearF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_clearF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_clearF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_clearF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_clearF.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearF.ForeColor = System.Drawing.Color.White;
            this.btn_clearF.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_clearF.ImageOffset = new System.Drawing.Point(10, 0);
            this.btn_clearF.Location = new System.Drawing.Point(25, 236);
            this.btn_clearF.Name = "btn_clearF";
            this.btn_clearF.Size = new System.Drawing.Size(159, 40);
            this.btn_clearF.TabIndex = 26;
            this.btn_clearF.Text = "Clear";
            this.btn_clearF.Click += new System.EventHandler(this.btn_clearF_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(26, 85);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "Category";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(26, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Sorting By Type";
            // 
            // cb_SPCategory
            // 
            this.cb_SPCategory.BackColor = System.Drawing.Color.White;
            this.cb_SPCategory.BorderColor = System.Drawing.Color.Empty;
            this.cb_SPCategory.BorderRadius = 6;
            this.cb_SPCategory.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_SPCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_SPCategory.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.cb_SPCategory.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SPCategory.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SPCategory.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_SPCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_SPCategory.ItemHeight = 30;
            this.cb_SPCategory.Location = new System.Drawing.Point(26, 114);
            this.cb_SPCategory.Name = "cb_SPCategory";
            this.cb_SPCategory.Size = new System.Drawing.Size(158, 36);
            this.cb_SPCategory.TabIndex = 1;
            // 
            // cb_SortType
            // 
            this.cb_SortType.BackColor = System.Drawing.Color.White;
            this.cb_SortType.BorderColor = System.Drawing.Color.Empty;
            this.cb_SortType.BorderRadius = 6;
            this.cb_SortType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_SortType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_SortType.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.cb_SortType.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SortType.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_SortType.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_SortType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_SortType.ItemHeight = 30;
            this.cb_SortType.Items.AddRange(new object[] {
            "Product Name",
            "Category",
            "Supplier"});
            this.cb_SortType.Location = new System.Drawing.Point(26, 42);
            this.cb_SortType.Name = "cb_SortType";
            this.cb_SortType.Size = new System.Drawing.Size(158, 36);
            this.cb_SortType.TabIndex = 0;
            // 
            // btn_Filter
            // 
            this.btn_Filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Filter.BackColor = System.Drawing.Color.White;
            this.btn_Filter.BorderRadius = 6;
            this.btn_Filter.BorderThickness = 3;
            this.btn_Filter.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Filter.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Filter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Filter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Filter.FillColor = System.Drawing.Color.White;
            this.btn_Filter.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Filter.ForeColor = System.Drawing.Color.Black;
            this.btn_Filter.Image = ((System.Drawing.Image)(resources.GetObject("btn_Filter.Image")));
            this.btn_Filter.ImageOffset = new System.Drawing.Point(-4, 0);
            this.btn_Filter.Location = new System.Drawing.Point(530, 38);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(130, 46);
            this.btn_Filter.TabIndex = 4;
            this.btn_Filter.Text = "Filter";
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // txt_Search
            // 
            this.txt_Search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Search.BackColor = System.Drawing.Color.Transparent;
            this.txt_Search.BorderRadius = 10;
            this.txt_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Search.DefaultText = "";
            this.txt_Search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Search.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.txt_Search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Search.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Search.ForeColor = System.Drawing.Color.White;
            this.txt_Search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Search.IconRight = ((System.Drawing.Image)(resources.GetObject("txt_Search.IconRight")));
            this.txt_Search.IconRightOffset = new System.Drawing.Point(10, 0);
            this.txt_Search.IconRightSize = new System.Drawing.Size(30, 30);
            this.txt_Search.Location = new System.Drawing.Point(22, 38);
            this.txt_Search.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.PasswordChar = '\0';
            this.txt_Search.PlaceholderForeColor = System.Drawing.Color.White;
            this.txt_Search.PlaceholderText = "Search by name...";
            this.txt_Search.SelectedText = "";
            this.txt_Search.Size = new System.Drawing.Size(500, 46);
            this.txt_Search.TabIndex = 0;
            this.txt_Search.IconRightClick += new System.EventHandler(this.txt_Search_IconRightClick);
            this.txt_Search.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Search_KeyPress);
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.SystemColors.Control;
            this.guna2CustomGradientPanel2.BorderRadius = 6;
            this.guna2CustomGradientPanel2.Controls.Add(this.ImageMenuName);
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(7, 30);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(1180, 359);
            this.guna2CustomGradientPanel2.TabIndex = 2;
            // 
            // ImageMenuName
            // 
            this.ImageMenuName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.ImageMenuName.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.ImageMenuName.Image = global::WarungMadura.Properties.Resources.Produck;
            this.ImageMenuName.ImageRotate = 0F;
            this.ImageMenuName.Location = new System.Drawing.Point(22, 3);
            this.ImageMenuName.Name = "ImageMenuName";
            this.ImageMenuName.Size = new System.Drawing.Size(270, 60);
            this.ImageMenuName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImageMenuName.TabIndex = 3;
            this.ImageMenuName.TabStop = false;
            // 
            // timer_filter
            // 
            this.timer_filter.Interval = 1;
            this.timer_filter.Tick += new System.EventHandler(this.timer_filter_Tick);
            // 
            // Produk
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2CustomGradientPanel2);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Produk";
            this.Text = "Produk";
            this.Load += new System.EventHandler(this.Produk_Load);
            this.EnabledChanged += new System.EventHandler(this.Produk_EnabledChanged);
            this.Gpnl_Produk_Data.ResumeLayout(false);
            this.Gpnl_Produk_Data.PerformLayout();
            this.gpnl_CreateData.ResumeLayout(false);
            this.gpnl_CreateData.PerformLayout();
            this.pnl_Pictureset.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gp_Product)).EndInit();
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.p_Filter.ResumeLayout(false);
            this.p_Filter.PerformLayout();
            this.guna2CustomGradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ImageMenuName)).EndInit();
            this.ResumeLayout(false);

        }
/*        private void LoadObjectsOnForm() {
            // Simulate a delay to mimic loading time
            Thread.Sleep(2000); // Adjust the delay time as needed
                // 
                // txt_Search
                // 
                this.txt_Search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
                this.txt_Search.BackColor = System.Drawing.Color.Transparent;
                this.txt_Search.BorderRadius = 10;
                this.txt_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
                this.txt_Search.DefaultText = "";
                this.txt_Search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
                this.txt_Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
                this.txt_Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                this.txt_Search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                this.txt_Search.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
                this.txt_Search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                this.txt_Search.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                this.txt_Search.ForeColor = System.Drawing.Color.White;
                this.txt_Search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                this.txt_Search.Location = new System.Drawing.Point(22, 38);
                this.txt_Search.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
                this.txt_Search.NameDiscount = "txt_Search";
                this.txt_Search.PasswordChar = '\0';
                this.txt_Search.PlaceholderForeColor = System.Drawing.Color.White;
                this.txt_Search.PlaceholderText = "Search...";
                this.txt_Search.SelectedText = "";
                this.txt_Search.Size = new System.Drawing.Size(649, 46);
                this.txt_Search.TabIndex = 0;
        }*/

        #endregion
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel gpnl_CreateData;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel Gpnl_Produk_Data;
        private Guna.UI2.WinForms.Guna2TextBox txt_Search;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txt_Name;
        private Guna.UI2.WinForms.Guna2TextBox txt_ProductID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txt_Sell;
        private Guna.UI2.WinForms.Guna2TextBox txt_Buy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txt_Discount;
        private Guna.UI2.WinForms.Guna2TextBox txt_Stock;
        private Guna.UI2.WinForms.Guna2Panel pnl_Pictureset;
        private Guna.UI2.WinForms.Guna2Button gbtn_InsertPicture;
        private Guna.UI2.WinForms.Guna2PictureBox gp_Product;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.FlowLayoutPanel flp_Product;
        private Guna.UI2.WinForms.Guna2ComboBox cb_Supplier;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Button btn_ExcData;
        private Label label11;
        private Guna.UI2.WinForms.Guna2ComboBox cb_CProduk;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel p_Filter;
        private Label label14;
        private Label label13;
        private Guna.UI2.WinForms.Guna2ComboBox cb_SPCategory;
        private Guna.UI2.WinForms.Guna2ComboBox cb_SortType;
        private Guna.UI2.WinForms.Guna2Button btn_Filter;
        private System.Windows.Forms.Timer timer_filter;
        private Label label15;
        private Label label12;
        private Guna.UI2.WinForms.Guna2Button btn_Clear;
        private Guna.UI2.WinForms.Guna2Button btn_clearF;
        private Label label10;
        private Label label16;
        private Label label17;
        private Guna.UI2.WinForms.Guna2ComboBox cb_SPSupplier;
        private Guna.UI2.WinForms.Guna2PictureBox ImageMenuName;
        public Guna.UI2.WinForms.Guna2TextBox txt_QTY;
        private Guna.UI2.WinForms.Guna2Button btn_Decrease;
        private Guna.UI2.WinForms.Guna2Button btn_Increase;
    }
}
﻿using CustomMessageBox;
using Guna.UI2.WinForms;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Diskon : Form {
        private string testing { get; set; }
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public Diskon() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            CategoryMember();
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {
            txt_startDate.Value = DateTime.Now;
            txt_endDate.Value = DateTime.Now;
        }

        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_promo FROM PromoDiskon ORDER BY id_promo DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "DSC001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_promo"]);
                            int newID = lastID + 1;

                            addID = "DSC" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_DiskonID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }

        private void CategoryMember() {
            try {
                using (SqlConnection myConnection = new SqlConnection(connectionString)) {
                    myConnection.Open();

                    SqlCommand myCommand = new SqlCommand("SELECT Nama FROM FnSearchJenisMember(null,null,null)", myConnection);

                    using (SqlDataReader reader = myCommand.ExecuteReader()) {
                        cbCategoryMember.Items.Clear();

                        while (reader.Read()) {
                            cbCategoryMember.Items.Add(reader["Nama"].ToString());
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LoadData() {
            flp_Jabatan.Controls.Clear();
            string query = "SELECT * FROM FnSearchPromoDiskon(null,null,null)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_promo"));
                                    int idCategory = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("NamaPromo"));
                                    string NCategori = reader.GetString(reader.GetOrdinal("NamaMember"));
                                    string deskripsi = reader.GetString(reader.GetOrdinal("Deskripsi"));
                                    DateTime tglMulai = reader.GetDateTime(reader.GetOrdinal("TanggalMulai"));
                                    DateTime tglAkhir = reader.GetDateTime(reader.GetOrdinal("TanggalAkhir"));
                                    int persentase = reader.GetInt32(reader.GetOrdinal("Persentase_Diskon"));
                                    decimal syarat = reader.GetDecimal(reader.GetOrdinal("SyaratMinPembelian"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_Diskon buffer = new UC_Diskon(id, idCategory, NCategori, KJName, deskripsi, tglMulai.ToString("yyyy-MM-dd"), tglAkhir.ToString("yyyy-MM-dd"), persentase, status, syarat);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status == 0) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Member Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void filter() {
            flp_Jabatan.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT * FROM FnSearchPromoDiskon(@sort_by,@search_name,@member)", connection)) {
                        if (cb_SortType.SelectedItem != null) {
                            command.Parameters.AddWithValue("@sort_by", cb_SortType.SelectedItem);
                        } else {
                            command.Parameters.AddWithValue("@sort_by", DBNull.Value);
                        }
                        if(cb_searchBy.Text == "Member") {
                            command.Parameters.AddWithValue("@member" , txt_Search.Text);
                            command.Parameters.AddWithValue("@search_name", DBNull.Value);
                        } else {
                            command.Parameters.AddWithValue("@search_name", txt_Search.Text);
                            command.Parameters.AddWithValue("@member" , DBNull.Value);
                        }
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_promo"));
                                    int idCategory = reader.GetInt32(reader.GetOrdinal("id_jenis_member"));
                                    string KJName = reader.GetString(reader.GetOrdinal("NamaPromo"));
                                    string NCategori = reader.GetString(reader.GetOrdinal("NamaMember"));
                                    string deskripsi = reader.GetString(reader.GetOrdinal("Deskripsi"));
                                    DateTime tglMulai = reader.GetDateTime(reader.GetOrdinal("TanggalMulai"));
                                    DateTime tglAkhir = reader.GetDateTime(reader.GetOrdinal("TanggalAkhir"));
                                    int persentase = reader.GetInt32(reader.GetOrdinal("Persentase_Diskon"));
                                    decimal syarat = reader.GetDecimal(reader.GetOrdinal("SyaratMinPembelian"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    UC_Diskon buffer = new UC_Diskon(id, idCategory, NCategori, KJName, deskripsi, tglMulai.ToString("yyyy-MM-dd"), tglAkhir.ToString("yyyy-MM-dd"), persentase, status, syarat);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status == 0) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Discount Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (p_filterExpand) {
                timer_filter.Start();
            }
        }
        private bool isUpdatePosition = false;
        private void UserControl_EditButton(object sender, DiskonEventArgs e) {
            // txt_PositionID.Text = e.id_Categories.ToString();
            txt_DiskonID.Text = "DSC" + e.id_diskon.ToString().PadLeft(3, '0');
            cbCategoryMember.Text = e.Categories;
            txt_Name.Text = e.Nama;
            txt_desc.Text = e.desc;
            DateTime mulai = DateTime.Parse(e.startDate);
            txt_startDate.Value = mulai;
            DateTime akhir = DateTime.Parse(e.endDate);
            txt_endDate.Value = akhir;
            txt_percentage.Text = e.rule.ToString();
            txt_rule.Text = e.Percentage.ToString("F0");
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdatePosition = true;
        }

        private void UserControl_Restore(object sender, DiskonEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateDiscountById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Discount id : " + e.id_diskon + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_promo", e.id_diskon);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }

        private void UserControl_Delete(object sender, DiskonEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeletePromoDiskonById";
                DialogResult = RJMessageBox.Show("Are you sure to delete Discount id : " + e.id_diskon + "\n With name : " + e.Nama, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_promo", e.id_diskon);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Discount Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void UserControl_InfoButton(object sender, DiskonEventArgs e) {
            Form formBackground = new Form();
            using (DiskonInfo diskonInfo = new DiskonInfo(e.id_diskon, e.Categories, e.Nama, e.desc, e.startDate, e.endDate, e.rule, e.Percentage)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();
                diskonInfo.StartPosition = FormStartPosition.CenterScreen;
                diskonInfo.FormBorderStyle = FormBorderStyle.None;
                diskonInfo.Owner = formBackground;
                diskonInfo.ShowDialog();
                formBackground.Dispose();
            }
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdatePosition) {
                doClear = UpdateDiskon();
            } else {
                doClear = InsertDiscount();
            }
            toastNotification.Show();
            if (doClear)
                clear(true);
        }
        public void clear(bool reset = false) {
            autoId();
            isUpdatePosition = false;
            cbCategoryMember.SelectedItem = null;
            txt_startDate.Value = DateTime.Now;
            txt_endDate.Value = DateTime.Now;
            txt_Name.Clear();
            txt_desc.Clear();
            txt_percentage.Clear();
            txt_rule.Clear();
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if(reset)LoadData();
        }
        private int TrueName() {
            string query = "SELECT COUNT(*) FROM PromoDiskon WHERE NamaPromo = @Nama AND id_promo <> @id_promo AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                command.Parameters.AddWithValue("@id_promo", int.Parse(txt_DiskonID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private bool InsertDiscount() {
            DateTime startdate = DateTime.Parse(txt_startDate.Value.ToString());
            DateTime enddate = DateTime.Parse(txt_endDate.Value.ToString());
            if (txt_Name.Text == "" || txt_percentage.Text == "" || txt_desc.Text == "" || txt_endDate.Text == "" || txt_startDate.Text == "" || txt_rule.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (txt_endDate.Value < txt_startDate.Value) {
                toastNotification = new Notification("Warning", "Invalid Date");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Discount Name Already Exists");
                return false;
            } else {
                try {
                    using (SqlConnection connection = new SqlConnection(connectionString)) {
                        string query = "SpInsertPromoDiskon";
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            int idCategory = GetCategoryId(cbCategoryMember.SelectedItem.ToString());
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@id_jenis_member", idCategory);
                            command.Parameters.AddWithValue("@NamaPromo", txt_Name.Text);
                            command.Parameters.AddWithValue("@Deskripsi", txt_desc.Text);
                            command.Parameters.AddWithValue("@TanggalMulai", startdate);
                            command.Parameters.AddWithValue("@TanggalAkhir", enddate);
                            command.Parameters.AddWithValue("@SyaratMinPembelian", Decimal.Parse(txt_rule.Text.Replace("Rp", "").Replace(".", "")));
                            command.Parameters.AddWithValue("@Persentase_Diskon", int.Parse(txt_percentage.Text));
                            command.Parameters.AddWithValue("@Status", 1);

                            connection.Open();
                            int result = command.ExecuteNonQuery();
                            connection.Close();
                            if (result == 0) {
                                toastNotification = new Notification("Info", "Insert Failed");
                            } else {
                                toastNotification = new Notification("Successfully", "Discount Inserted");
                            }
                        }
                        return true;
                    }
                } catch (Exception ex) {
                    toastNotification = new Notification("Warning", ex.Message);
                    return false;
                }

            }
        }

        private bool UpdateDiskon() {
            if (txt_Name.Text == "" || txt_percentage.Text == "" || txt_desc.Text == "" || txt_endDate.Text == "" || txt_startDate.Text == "" || txt_rule.Text == "") {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (txt_endDate.Value < txt_startDate.Value) {
                toastNotification = new Notification("Warning", "Invalid Date");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Discount Name Already Exists");
                return false;
            } else {
                DateTime startdate = DateTime.Parse(txt_startDate.Text);
                DateTime enddate = DateTime.Parse(txt_endDate.Text);
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpUpdatePromoDiskon";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        // Mengambil hanya angka dari txt_PositionID.Text
                        // string id_jabatan = Regex.Replace(txt_PositionID.Text, "[^0-9]", "");

                        string id_diskon = txt_DiskonID.Text.Substring(3, 3);
                        int id_diskonn = int.Parse(id_diskon);

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_promo", id_diskonn);
                        command.Parameters.AddWithValue("@id_jenis_member", GetCategoryId(cbCategoryMember.SelectedItem.ToString()));
                        command.Parameters.AddWithValue("@NamaPromo", txt_Name.Text);
                        command.Parameters.AddWithValue("@Deskripsi", txt_desc.Text);
                        command.Parameters.AddWithValue("@TanggalMulai", startdate);
                        command.Parameters.AddWithValue("@TanggalAkhir", enddate);
                        command.Parameters.AddWithValue("@SyaratMinPembelian", Decimal.Parse(txt_rule.Text.Replace("Rp", "").Replace(".", "")));
                        command.Parameters.AddWithValue("@Persentase_Diskon", int.Parse(txt_percentage.Text));
                        command.Parameters.AddWithValue("@Status", 1);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Discount Updated");
                        }
                        return true;
                    }
                }
            }
        }
        private int GetCategoryId(string namaJabatan) {
            int jabatanId = 0;
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SELECT dbo.GetJenisMemberIdByName(@namaJenisMember)";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.Text;
                        command.Parameters.AddWithValue("@namaJenisMember", namaJabatan);
                        connection.Open();
                        jabatanId = (int)command.ExecuteScalar();
                        connection.Close();
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
            return jabatanId;
        }

        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 200) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 200;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }

        }
        private void txt_Currency_TextChanged(object sender, EventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;

            if (guna2Text.Text.Any(char.IsDigit)) {
                int caretPosition = guna2Text.SelectionStart;
                string buffer = guna2Text.Text.Replace("Rp", "").Trim();
                buffer = buffer.Replace(".", "");

                if (decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result)) {
                    string formattedBuffer = result.ToString("#,##", CultureInfo.InvariantCulture).Replace(",", ".");
                    guna2Text.Text = "Rp " + formattedBuffer;
                    guna2Text.SelectionStart = formattedBuffer.Length + 3;
                }
            } else {
                guna2Text.Clear();
            }
        }

        private void KeypressNumber(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void btn_clear_Click(object sender, EventArgs e) {
            cb_SortType.Text = null;
            cb_searchBy.Text = null;
        }

        private void btn_clear_Click_1(object sender, EventArgs e) {
            clear();
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            filter();
        }

        private void label16_Click(object sender, EventArgs e) {

        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e) {

        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                filter();
            }
        }
    }
}

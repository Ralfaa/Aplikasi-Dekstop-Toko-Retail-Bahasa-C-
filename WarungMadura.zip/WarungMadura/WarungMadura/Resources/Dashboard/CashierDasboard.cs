﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard
{
    public partial class CashierDasboard : Form
    {
        string connectionString = Properties.Resources.ConnectionString;
        private int IDEmployee = 0;
        public CashierDasboard(int iDEmployee) {
            InitializeComponent();
            IDEmployee = iDEmployee;
        }
        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            loadData();
        }
        private void loadData() {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = $"select id_transaksi,nama_promo,nama_pelanggan,'Rp. ' + CONCAT(FORMAT(TotalHarga, 'N0'), ''),TanggalTransaksi from FnGetTransactionHistoryByEmployeeId({IDEmployee},'{txt_Search.Text}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dgv_Produk.DataSource = dataTable;
                    dgv_Produk.Columns[0].HeaderText = "Transaction ID";
                    dgv_Produk.Columns[1].HeaderText = "Discount";
                    dgv_Produk.Columns[2].HeaderText = "Member";
                    dgv_Produk.Columns[3].HeaderText = "Total Price";
                    dgv_Produk.Columns[4].HeaderText = "Date";
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = $"select * from FnGetTransactionStatsByEmployeeId({IDEmployee},'{txt_Search.Text}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    txt_AmountSell.Text = dataTable.Rows[0][0].ToString()+" Transaction";
                    decimal.TryParse(dataTable.Rows[0][1].ToString(), out decimal totalSellPrice);
                    txt_TotalSellPrice.Text = "Rp. " + totalSellPrice.ToString("N0");

                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            loadData();
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                loadData();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class KaryawanInfo : Form {
        public KaryawanInfo() {
            InitializeComponent();
        }
        private void ProductInfo_Load(object sender, EventArgs e) {
        }

        public KaryawanInfo(int id, string namaKaryawan, string Username, string Password, string Alamat, string Telp, string Email, string Gender, int idJabatan, string namaJabatan, byte[] picture) {
            InitializeComponent();
            txt_employeeID.Text = "EMP" + id.ToString().PadLeft(3, '0');
            txt_Name.Text = namaKaryawan;
            txt_Username.Text = Username;
            txt_Password.Text = Password;
            txt_telp.Text = Telp;
            txt_email.Text = Email;
            txt_position.Text = namaJabatan;
            txt_gender.Text = Gender;
            txt_address.Text = Alamat;

            if (picture != null && picture.Length > 0) {
                using (var ms = new System.IO.MemoryStream(picture)) {
                    p_Product.Image = Image.FromStream(ms);
                }
            } else {
                p_Product.Image = null;
            }


        }
        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            timer_Closing.Start();
        }
    }
}

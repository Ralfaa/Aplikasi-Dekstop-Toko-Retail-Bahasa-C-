﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Jabatan : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;

        public Jabatan() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {

        }

        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_jabatan FROM KategoriJabatan ORDER BY id_jabatan DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "PS001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_jabatan"]);
                            int newID = lastID + 1;

                            addID = "PS" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_PositionID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }


        private void LoadData() {
            flp_Jabatan.Controls.Clear();
            string query = "select * from FnSearchPosition(NULL,NULL)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_jabatan"));
                                    string KJName = reader.GetString(reader.GetOrdinal("NamaJabatan"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));
                                    string HakAkses = reader.GetString(reader.GetOrdinal("Akses"));

                                    UC_Jabatan buffer = new UC_Jabatan(id, KJName, status, HakAkses);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Position Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void UserControl_InfoButton(object sender, PositionEventArgs e) {

            Form formBackground = new Form();
            using (JabatanInfo jabatanInfo = new JabatanInfo(e.id_Position, e.NamaPosition, e.HakAkses)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                jabatanInfo.StartPosition = FormStartPosition.CenterScreen;
                jabatanInfo.FormBorderStyle = FormBorderStyle.None;
                jabatanInfo.Owner = formBackground;
                jabatanInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private bool isUpdatePosition = false;
        private void UserControl_EditButton(object sender, PositionEventArgs e) {
            // txt_PositionID.Text = e.id_Categories.ToString();
            txt_PositionID.Text = "PS" + e.id_Position.ToString().PadLeft(3, '0');

            txt_Name.Text = e.NamaPosition;
            cb_hakAkses.Text = e.HakAkses.ToString();
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdatePosition = true;
        }

        private void UserControl_Restore(object sender, PositionEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivatePositionById";
                DialogResult = RJMessageBox.Show("Are you sure to Restore Position id : " + e.id_Position + "\n With name Position : " + e.NamaPosition, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jabatan", e.id_Position);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }
        private void UserControl_Delete(object sender, PositionEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeleteKategoriJabatanById";
                DialogResult = RJMessageBox.Show("Are you sure to delete Position id : " + e.id_Position + "\n With name Position : " + e.NamaPosition, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jabatan", e.id_Position);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Position Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdatePosition) {
                doClear = UpdatePosition();
            } else {
                doClear = InsertPosition();
            }
            toastNotification.Show();
            if (doClear)clear(true);
        }
        public void clear(bool reset = false) {
            autoId();
            isUpdatePosition = false;
            txt_Name.Clear();
            cb_hakAkses.SelectedItem = null;
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if(reset)LoadData();
        }
        private int TrueName() {
            string query = "SELECT COUNT(*) FROM KategoriJabatan WHERE NamaJabatan = @Nama AND id_jabatan <> @id_jabatan AND Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nama", txt_Name.Text);
                command.Parameters.AddWithValue("@id_jabatan", int.Parse(txt_PositionID.Text.Substring(3)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }
        private bool InsertPosition() {
            if (txt_Name.Text == ""
                || cb_hakAkses.Text == ""
                ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Position Name Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpInsertKategoriJabatan";
                    using (SqlCommand command = new SqlCommand(query, connection)) {

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@NamaJabatan", txt_Name.Text);
                        command.Parameters.AddWithValue("@Akses", cb_hakAkses.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Insert Failed");
                        } else {
                            toastNotification = new Notification("Successfully", " Position Inserted");
                        }
                    }
                    return true;
                }
            }
        }
        private bool UpdatePosition() {
            if (txt_Name.Text == ""
            || cb_hakAkses.Text == ""
            ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Position Name Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpUpdateKategoriJabatan";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        // Mengambil hanya angka dari txt_PositionID.Text
                        // string id_jabatan = Regex.Replace(txt_PositionID.Text, "[^0-9]", "");

                        string id_jabatan = txt_PositionID.Text.Substring(2, 3);
                        int id_jabatann = int.Parse(id_jabatan);

                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_jabatan", id_jabatann);
                        command.Parameters.AddWithValue("@NamaJabatan", txt_Name.Text);
                        command.Parameters.AddWithValue("@Akses", cb_hakAkses.Text);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Position Updated");
                        }
                        return true;
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 147) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 147;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }

        }

        private void btn_Clear_Click(object sender, EventArgs e) {
            clear();
        }

        private void guna2Button1_Click(object sender, EventArgs e) {
            cb_SortType.SelectedItem = null;
            p_filterExpand = true;
            timer_filter.Start();
        }

        private void cari() {
            p_filterExpand = true;
            timer_filter.Start();
            flp_Jabatan.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = $"select * from FnSearchPosition('{cb_SortType.Text}','{txt_Search.Text}')";
                using (SqlCommand command = new SqlCommand(query, connection)) {

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader()) {
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                int id = reader.GetInt32(reader.GetOrdinal("id_jabatan"));
                                string KJName = reader.GetString(reader.GetOrdinal("NamaJabatan"));
                                int status = reader.GetInt32(reader.GetOrdinal("Status"));
                                string HakAkses = reader.GetString(reader.GetOrdinal("Akses"));

                                UC_Jabatan buffer = new UC_Jabatan(id, KJName, status, HakAkses);
                                buffer.InfoButton += UserControl_InfoButton;
                                buffer.DeleteButton += UserControl_Delete;
                                if (status.Equals(0)) {
                                    buffer.EditButton += UserControl_Restore;
                                } else {
                                    buffer.EditButton += UserControl_EditButton;
                                }
                                flp_Jabatan.Controls.Add(buffer);
                            }
                        } else {
                            toastNotification = new Notification("Info", "No Position Found");
                            toastNotification.Show();
                        }
                    }
                }
            }
            if (p_filterExpand) {
                timer_filter.Start();
            }
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            cari();
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                cari();
            }
        }
        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
    }
}

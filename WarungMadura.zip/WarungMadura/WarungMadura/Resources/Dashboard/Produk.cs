﻿using CustomMessageBox;
using CustomMessageBox.Private;
using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using static ToastNotifications.FormAnimator;

namespace WarungMadura.Resources.Dashboard {
    public partial class Produk : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;
        private int currentPage;
        int totalItems,limit;
        private int itemsPerPage = 15;
        public Produk() {
            InitializeComponent();
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            Loadsupplier();
            LoadCategories();
            limitpage();
            LoadData();
        }
        private void limitpage() {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string countQuery = "SELECT COUNT(*) FROM FnSearchProduk(@sort_by, @search_name, @search_category_name, @search_supplier_name)";
                using (SqlCommand countCommand = new SqlCommand(countQuery, connection)) {
                    countCommand.Parameters.AddWithValue("@sort_by", cb_SortType.SelectedItem ?? DBNull.Value);
                    countCommand.Parameters.AddWithValue("@search_name", string.IsNullOrEmpty(txt_Search.Text) ? (object)DBNull.Value : txt_Search.Text);
                    countCommand.Parameters.AddWithValue("@search_category_name", string.IsNullOrEmpty(cb_SPCategory.Text) ? (object)DBNull.Value : cb_SPCategory.Text);
                    countCommand.Parameters.AddWithValue("@search_supplier_name", string.IsNullOrEmpty(cb_SPSupplier.Text) ? (object)DBNull.Value : cb_SPSupplier.Text);
                    connection.Open();
                    totalItems = (int)countCommand.ExecuteScalar();
                    limit = (totalItems / itemsPerPage) + 1;
                }
            }
        }
        private void LoadData() {
            flp_Product.Controls.Clear();
            string SortBy = null;

            if (cb_SortType.SelectedItem != null) {
                string selected = cb_SortType.SelectedItem.ToString();
                if (selected.Equals("Product Name", StringComparison.OrdinalIgnoreCase)) {
                    SortBy = "NamaProduk";
                } else if (selected.Equals("Category", StringComparison.OrdinalIgnoreCase)) {
                    SortBy = "NamaKategori";
                } else if (selected.Equals("Supplier", StringComparison.OrdinalIgnoreCase)) {
                    SortBy = "NamaSupplier";
                } else {
                    SortBy = "id_produk";
                }
            } else {
                SortBy = "id_produk";
            }
            string query = $@"
            SELECT * FROM FnSearchProduk(@sort_by, @search_name, @search_category_name, @search_supplier_name)
            ORDER BY {SortBy}
            OFFSET @Offset ROWS FETCH NEXT @Fetch ROWS ONLY";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {

                        command.Parameters.AddWithValue("@sort_by", cb_SortType.SelectedItem ?? DBNull.Value);
                        command.Parameters.AddWithValue("@search_name", string.IsNullOrEmpty(txt_Search.Text) ? (object)DBNull.Value : txt_Search.Text);
                        command.Parameters.AddWithValue("@search_category_name", string.IsNullOrEmpty(cb_SPCategory.Text) ? (object)DBNull.Value : cb_SPCategory.Text);
                        command.Parameters.AddWithValue("@search_supplier_name", string.IsNullOrEmpty(cb_SPSupplier.Text) ? (object)DBNull.Value : cb_SPSupplier.Text);
                        command.Parameters.AddWithValue("@Offset", currentPage * itemsPerPage);
                        command.Parameters.AddWithValue("@Fetch", itemsPerPage);

                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                    string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                    string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                    int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                    int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                    decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                    decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                    string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }

                                    UC_Produk buffer = new UC_Produk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                    buffer.InfoButton += UserControl_InfoButton;
                                    buffer.DeleteButton += UserControl_Delete;
                                    if (status.Equals(0)) {
                                        buffer.EditButton += UserControl_Restore;
                                    } else {
                                        buffer.EditButton += UserControl_EditButton;
                                    }

                                    flp_Product.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Product Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }

            UpdateButtonStates();
            if (p_filterExpand) {
                timer_filter.Start();
            }
        }

        private void btnNext_Click(object sender, EventArgs e) {
            ++currentPage;
            LoadData();
            changedqty = false;
        }

        private void btnPrevious_Click(object sender, EventArgs e) {
            if (currentPage > 0) {
                --currentPage;
                LoadData();
            }
            changedqty = false;
        }

        private void UpdateButtonStates() {
            txt_QTY.Text = (currentPage+1).ToString();
            btn_Decrease.Enabled = currentPage > 0;
            btn_Increase.Enabled = (currentPage + 1) * itemsPerPage < totalItems;
            GC.Collect();
            GC.WaitForPendingFinalizers();

        }
        private void Produk_Load(object sender, EventArgs e) {
            txt_Stock.Text = "0";
        }
        private void Loadsupplier() {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "SELECT id_supplier,NamaSupplier FROM FnSearchSupplier(null,null)";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    cb_Supplier.DisplayMember = "NamaSupplier";
                    cb_Supplier.ValueMember = "id_supplier";
                    cb_Supplier.DataSource = dataTable;

                    foreach (DataRow row in dataTable.Rows) {
                        cb_SPSupplier.Items.Add(Text = row["NamaSupplier"].ToString());
                    }
                    cb_Supplier.StartIndex = -1;
                    cb_SPSupplier.StartIndex = -1;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }        
        private void LoadCategories() {

            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "select id_kategori, NamaKategori from FnSearchProductCategory(null,null)";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    cb_CProduk.DisplayMember = "NamaKategori";
                    cb_CProduk.ValueMember = "id_kategori";
                    cb_CProduk.DataSource = dataTable;

                    foreach (DataRow row in dataTable.Rows) {
                        cb_SPCategory.Items.Add(Text = row["NamaKategori"].ToString());
                    }

                    cb_CProduk.SelectedIndex = -1;
                    cb_SPCategory.SelectedIndex = -1;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_produk FROM Produk ORDER BY id_produk DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "PDCT001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_produk"]);
                            int newID = lastID + 1;

                            addID = "PDCT" + newID.ToString().PadLeft(3, '0');
                        }

                        txt_ProductID.Text = addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }

        private void gbtn_InsertPicture_Click(object sender, EventArgs e) {
            string imageloc = "";
            try {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png";
                if(dialog.ShowDialog() == DialogResult.OK) {
                    imageloc = dialog.FileName;
                    FileInfo fileInfo = new FileInfo(imageloc);
                    long fileSizeInBytes = fileInfo.Length;
                    long fileSizeInMB = fileSizeInBytes / (1024 * 1024);

                    // 1 MB limit
                    if (fileSizeInMB > 0) {
                        toastNotification = new Notification("Warning", "Max picture size 1MB");
                    } else {
                        gp_Product.ImageLocation = imageloc;
                        gp_Product.SizeMode = PictureBoxSizeMode.Zoom;
                        toastNotification = new Notification("Info", "Picture inserted succesfully");
                    }
                    toastNotification.Show();
                }
            }catch(Exception ex) {
                MessageBox.Show(ex.ToString());
            }
        }
        private byte[] ImageToByteArray(Image image) {
            try {
                using (MemoryStream ms = new MemoryStream()) {
                    // Save the image to the MemoryStream
                    image.Save(ms, image.RawFormat);
                    return ms.ToArray();
                }
            } catch (Exception ex) {
                RJMessageBox.Show($"An error occurred while converting the image: {ex.Message}");
                return null;
            }
        }
        private void UserControl_InfoButton(object sender, ProductEventArgs e) {
            Form formBackground = new Form();
            using (ProductInfo productInfo = new ProductInfo(e.id_Product, e.NamaProduct, e.nama_CProduct, e.nama_Supplier, e.Stock, e.Unit, e.Discount, e.Sell, e.Buy, e.Picture)) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                productInfo.StartPosition = FormStartPosition.CenterScreen;
                productInfo.FormBorderStyle = FormBorderStyle.None;
                productInfo.Owner = formBackground;
                productInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
        private bool isUpdatePorduct = false;
        private byte[] ImageEdit = null;
        private void UserControl_EditButton(object sender, ProductEventArgs e) { 
            txt_ProductID.Text ="PDCT" + e.id_Product.ToString().PadLeft(3, '0');
            txt_Name.Text = e.NamaProduct;
            cb_CProduk.SelectedValue = e.Id_CProduct;
            cb_Supplier.SelectedValue = e.Id_Supplier;
            txt_Stock.Text = e.Stock.ToString();
            txt_Discount.Text = e.Discount.ToString();
            txt_Buy.Text = e.Buy.ToString("F0");
            txt_Sell.Text = e.Sell.ToString("F0");
            ImageEdit = e.Picture;
            if (e.Picture != null && e.Picture.Length > 0) {
                using (var ms = new System.IO.MemoryStream(e.Picture)) {
                    gp_Product.Image = Image.FromStream(ms);
                }
            } else {
                gp_Product.Image = null;
            }
            btn_ExcData.Text = "Update";
            btn_ExcData.Image = Properties.Resources.edit;
            isUpdatePorduct = true;
        }
        private void UserControl_Restore(object sender, ProductEventArgs e) {
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "ActivateProdukById";
                DialogResult = RJMessageBox.Show("Are you sure to delete product id : " + e.id_Product + "\n With name product : " + e.NamaProduct, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_produk", e.id_Product);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Restore Failed");
                        } else {
                            toastNotification = new Notification("Info", "Restored");
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Restore Canceled");
                }
            }
            toastNotification.Show();
            clear();
        }
        private void UserControl_Delete (object sender, ProductEventArgsD e) {
            bool reset = false;
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "DeleteProdukById";
                DialogResult = RJMessageBox.Show("Are you sure to delete product id : " + e.id_Product+"\n With name product : "+e.NamaProduct, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.Yes) {
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_produk", e.id_Product);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Delete Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Product Deleted");
                            reset = true;
                        }
                    }
                } else {
                    toastNotification = new Notification("Info", "Delete Canceled");
                }
            }
            toastNotification.Show();
            clear(reset);
        }

        private void btn_ExcData_Click(object sender, EventArgs e) {
            bool doClear = false;
            if (isUpdatePorduct) {
                doClear = UpdateProduct();
            } else {
                doClear = InsertProduct();
            }
            toastNotification.Show();
            if (doClear)
            clear(true);
        }
        public void clear(bool reset = false) {
            isUpdatePorduct = false;
            ImageEdit = null;
            txt_ProductID.Clear();
            txt_Name.Clear();
            txt_Stock.Clear();
            txt_Discount.Clear();
            txt_Buy.Clear();
            txt_Sell.Clear();
            gp_Product.ImageLocation = null;
            gp_Product.Image = null;
            btn_ExcData.Text = "Add";
            btn_ExcData.Image = Properties.Resources.add;
            if (reset) {
                currentPage = 0;
            limitpage();
            LoadData();
            }
            txt_Stock.Text = "0";
            cb_CProduk.SelectedValue = -1;
            cb_Supplier.SelectedValue = -1;            
            cb_CProduk.SelectedValue = -1;
            cb_Supplier.SelectedValue = -1;
            autoId();
        }

        private int TrueName() {
            string query = "SELECT COUNT(*) FROM Produk WHERE NamaProduk = @NamaProduk AND id_produk <> @id_produk AND Status > 0";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NamaProduk", txt_Name.Text);
                command.Parameters.AddWithValue("@id_produk", int.Parse(txt_ProductID.Text.Substring(4)));

                connection.Open();
                int count = (int)command.ExecuteScalar();

                return count;

            }
        }

        private bool InsertProduct() {
            if (txt_Name.Text == ""
                || txt_Buy.Text == ""
                || txt_Sell.Text == ""
                || txt_Stock.Text == ""
                || txt_Discount.Text == ""
                ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Product Name Already Exists");
                return false;
            } else {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    string query = "SpInsertProduk";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        byte[] buffer = null;
                        if (gp_Product.ImageLocation != null) {
                            buffer = ImageToByteArray(Image.FromFile(gp_Product.ImageLocation));
                        }
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_kategori", cb_CProduk.SelectedValue);
                        command.Parameters.AddWithValue("@id_supplier", cb_Supplier.SelectedValue);
                        command.Parameters.AddWithValue("@NamaProduk", txt_Name.Text);
                        command.Parameters.AddWithValue("@HargaBeli", Decimal.Parse(txt_Buy.Text.Replace("Rp", "").Replace(".", "")));
                        command.Parameters.AddWithValue("@HargaJual", Decimal.Parse(txt_Sell.Text.Replace("Rp", "").Replace(".", "")));
                        command.Parameters.AddWithValue("@Stock", txt_Stock.Text);
                        command.Parameters.AddWithValue("@PromoDiskon", txt_Discount.Text);
                        command.Parameters.Add(new SqlParameter("@Picture", SqlDbType.VarBinary) { Value = (object)buffer ?? DBNull.Value });
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Insert Failed");
                        } else {
                            toastNotification = new Notification("Successfully", " Product Inserted");
                        }
                    }
                    return true;
                }
            }
        }
        private bool UpdateProduct() {
            if (txt_Name.Text == ""
                || txt_Buy.Text == ""
                || txt_Sell.Text == ""
                || txt_Stock.Text == ""
                || txt_Discount.Text == ""
                ) {
                toastNotification = new Notification("Warning", "Uncompleted Data");
                return false;
            } else if (TrueName() == 1) {
                toastNotification = new Notification("Warning", "Product Name Already Exists");
                return false;
            } else { 
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                string query = "SpUpdateProduk";
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        byte[] buffer = null;
                        if (gp_Product.ImageLocation != null) {
                            buffer = ImageToByteArray(Image.FromFile(gp_Product.ImageLocation));
                        } else {
                            if (ImageEdit != null) {
                                buffer = ImageEdit;
                            }
                        }
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@id_produk", Convert.ToInt32(txt_ProductID.Text.Substring(4)));
                        command.Parameters.AddWithValue("@id_kategori", cb_CProduk.SelectedValue);
                        command.Parameters.AddWithValue("@id_supplier", cb_Supplier.SelectedValue);
                        command.Parameters.AddWithValue("@NamaProduk", txt_Name.Text);
                        command.Parameters.AddWithValue("@HargaBeli", Decimal.Parse(txt_Buy.Text.Replace("Rp","").Replace(".", "")));
                        command.Parameters.AddWithValue("@HargaJual", Decimal.Parse(txt_Sell.Text.Replace("Rp", "").Replace(".", "")));
                        command.Parameters.AddWithValue("@Stock", txt_Stock.Text);
                        command.Parameters.AddWithValue("@PromoDiskon", txt_Discount.Text);
                        command.Parameters.AddWithValue("@Picture", buffer);
                        command.Parameters.AddWithValue("@Status", 1);

                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Update Failed");
                        } else {
                            toastNotification = new Notification("Successfully", "Product Updated");
                        }
                        return true;
                    }
            
                }
            }
        }
        private void btn_Filter_Click(object sender, EventArgs e) {
            timer_filter.Start();
        }

        bool p_filterExpand = false;
        private void timer_filter_Tick(object sender, EventArgs e) {
            if (!p_filterExpand) {
                if (p_Filter.Height < 290) {
                    p_Filter.Height += 12;
                    p_Filter.ShadowDecoration.Enabled = true;
                } else {
                    p_Filter.Height = 290;
                    timer_filter.Stop();
                    p_filterExpand = true;
                }
            } else {
                if (p_Filter.Height > 12) {
                    p_Filter.Height -= 12;
                } else {
                    p_Filter.Height = 12;
                    p_Filter.ShadowDecoration.Enabled = false;
                    timer_filter.Stop();
                    p_filterExpand = false;
                }
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e) {
            clear();
        }

        private void btn_clearF_Click(object sender, EventArgs e) {
            cb_SortType.SelectedIndex = -1;
            cb_SPCategory.SelectedIndex = -1;
            cb_SPSupplier.SelectedIndex = -1;
        }

        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            currentPage = 0;
            LoadData();
        }

        private void txt_Name_KeyPress(object sender, KeyPressEventArgs e) {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }
        private void txt_KeyPressDisc(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
            if (txt_Discount.Text.Length >= 2 && e.KeyChar != '\b' && Convert.ToInt32(txt_Discount.Text) > 10) {
                e.Handled = true;
            }
        }
        private void txt_KeyPressPrice(object sender, KeyPressEventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }

        private void txt_Currency_TextChanged(object sender, EventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;

            if (guna2Text.Text.Any(char.IsDigit)) {
                int caretPosition = guna2Text.SelectionStart;
                string buffer = guna2Text.Text.Replace("Rp", "").Trim();
                buffer = buffer.Replace(".", "");

                if (decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result)) {
                    string formattedBuffer = result.ToString("#,##", CultureInfo.InvariantCulture).Replace(",", ".");
                    guna2Text.Text = "Rp "+formattedBuffer;
                    guna2Text.SelectionStart = formattedBuffer.Length+3;
                }
            } else {
                guna2Text.Clear();
            }
        }

        private void txt_Search_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter) {
                currentPage = 0;
                LoadData();
            }
        }

        private void Gpnl_Produk_Data_Paint(object sender, PaintEventArgs e) {

        }
        bool changedqty = false;
        private void txt_QTY_MouseLeave(object sender, EventArgs e) {
            if(changedqty)
            LoadData();
            changedqty = false;
            this.SelectNextControl((Control)sender, true, true, true, true);
        }

        private void txt_QTY_CursorChanged(object sender, EventArgs e) {

        }

        private void txt_QTY_Enter(object sender, EventArgs e) {
        }

        private void txt_QTY_Leave(object sender, EventArgs e) {
            
        }

        private void txt_QTY_TextChanged(object sender, EventArgs e) {

            if (txt_QTY.Text == string.Empty) {
                changedqty = true;
                currentPage = 0;
                txt_QTY.Text = "1";
                return;
            }
            if (Convert.ToInt64(txt_QTY.Text) > limit ) {
                changedqty = true;
                txt_QTY.Text = limit.ToString();
                currentPage = limit-1;
            } else {
                changedqty = true;
                currentPage = (int)Convert.ToInt64(txt_QTY.Text)-1;
            }
        }
    }
}

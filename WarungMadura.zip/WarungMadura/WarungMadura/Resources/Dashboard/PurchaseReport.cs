﻿using CustomMessageBox;
using ReportPembelianWarung;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class PurchaseReport : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;
        bool alldata = true;
        private int idUser;
        private DataTable dataOrders = new DataTable();
        public PurchaseReport(int id) {
            idUser = id;
            InitializeComponent();
            btn_DetailOrders.Enabled = false;
            btn_clear.Enabled = false;
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            DTM_Start.Value = DateTime.Now;
            DTM_End.Value = DateTime.Now;
            LoadData();
        }

        private void LoadData() {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "select 'POD' + RIGHT('00000' + CAST(id_transaksi AS VARCHAR), 5) AS 'ID Orders', " +
                        "nama_supplier,nama_karyawan,TanggalTransaksi,'Rp. ' + CONCAT(FORMAT(TotalHarga, 'N0'), '') AS TotalHarga from FnGetPurchaseReport(null,null)";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    dataOrders.Load(reader);
                    dgv_SalesReport.DataSource = dataOrders;
                    dgv_SalesReport.Columns[1].HeaderText = "Supplier";
                    dgv_SalesReport.Columns[2].HeaderText = "Employee";
                    dgv_SalesReport.Columns[3].HeaderText = "Date";
                    dgv_SalesReport.Columns[4].HeaderText = "Total Price";
                    alldata = true;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            DTM_Start.Value = DateTime.Now;
            DTM_Start.Value = DateTime.Now;
        }

        public void clear() {
            txt_Purchases.Clear();
            txt_SupplierPurchases.Clear();
            txt_EmpPurchases.Clear();
            txt_DatePurchases.Clear();
            txt_PricePurchases.Clear();
            btn_DetailOrders.Enabled = false;
            btn_clear.Enabled = false;
        }

        private void txt_KeyPressTelp(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }

            // Memeriksa panjang no telp
            if (txt_DatePurchases.Text.Length >= 13 && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }

        private void btn_clear_Click_1(object sender, EventArgs e) {
            clear();
        }

        private void dgv_SalesReport_CellClick(object sender, DataGridViewCellEventArgs e) {
            int Srow = dgv_SalesReport.SelectedCells[0].RowIndex;
            txt_Purchases.Text = dgv_SalesReport.Rows[Srow].Cells[0].Value.ToString();
            txt_SupplierPurchases.Text = dgv_SalesReport.Rows[Srow].Cells[1].Value.ToString();
            txt_EmpPurchases.Text = dgv_SalesReport.Rows[Srow].Cells[2].Value.ToString();
            txt_DatePurchases.Text = dgv_SalesReport.Rows[Srow].Cells[3].Value.ToString();
            DateTime dateValue = (DateTime)dgv_SalesReport.Rows[Srow].Cells[3].Value;
            txt_DatePurchases.Text = dateValue.ToString("yyyy-MM-dd");
            txt_PricePurchases.Text =  dgv_SalesReport.Rows[Srow].Cells[4].Value.ToString();
            btn_clear.Enabled = true;
            btn_DetailOrders.Enabled = true;
        }

        private void btn_Apply_Click(object sender, EventArgs e) {
            dataOrders.Clear();
            // Set the start date time to 00:00:00
            DateTime startDate = new DateTime(DTM_Start.Value.Year, DTM_Start.Value.Month, DTM_Start.Value.Day, 0, 0, 0);

            // Set the end date time to 23:59:00
            DateTime endDate = new DateTime(DTM_End.Value.Year, DTM_End.Value.Month, DTM_End.Value.Day, 23, 59, 0);

            if (endDate >= startDate) {
                try {
                    DateTime Start = (DateTime)startDate;
                    DateTime End = (DateTime)endDate;
                    using (SqlConnection connection = new SqlConnection(connectionString)) {
                        connection.Open();
                        string query = "select 'POD' + RIGHT('00000' + CAST(id_transaksi AS VARCHAR), 5) AS 'ID Orders', " +
                                       "nama_supplier,nama_karyawan,TanggalTransaksi,CONCAT(FORMAT(TotalHarga, 'F0'), '') AS TotalHarga from " +
                                       $"FnGetPurchaseReport('{Start.ToString("yyyy-MM-dd")}','{End.AddDays(1).ToString("yyyy-MM-dd")}')";
                        SqlCommand command = new SqlCommand(query, connection);
                        SqlDataReader reader = command.ExecuteReader();

                        dataOrders.Load(reader);
                        dgv_SalesReport.DataSource = dataOrders;
                        dgv_SalesReport.Columns[1].HeaderText = "Supplier";
                        dgv_SalesReport.Columns[2].HeaderText = "Employee";
                        dgv_SalesReport.Columns[3].HeaderText = "Date";
                        dgv_SalesReport.Columns[4].HeaderText = "Total Price";
                        alldata = false;
                    }
                } catch (Exception ex) {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            } else {
                LoadData();
                toastNotification = new Notification("Warning", "Invalid Date");
                toastNotification.Show();
            }
            if (dgv_SalesReport.Rows.Count > 0) {
                btn_Print.Enabled = true;
            } else {
                toastNotification = new Notification("Warning", "No Data Found");
                toastNotification.Show();
                btn_Print.Enabled = false;
            }
        }

        private void btn_ResetDay_Click(object sender, EventArgs e) {
            DTM_Start.Value = DateTime.Now;
            DTM_End.Value = DateTime.Now;
            dataOrders.Clear();
            LoadData();
            if (dgv_SalesReport.Rows.Count > 0) {
                btn_Print.Enabled = true;
            } else {
                btn_Print.Enabled = false;
            }
        }

        private void btn_Print_Click(object sender, EventArgs e) {
            if (alldata) {
                Form formBackground = new Form();
                using (ReportPurchase memberInfo = new ReportPurchase()) {
                    formBackground.StartPosition = FormStartPosition.CenterScreen;
                    formBackground.FormBorderStyle = FormBorderStyle.None;
                    formBackground.Opacity = 0.50d;
                    formBackground.Size = new Size(1920, 1080);
                    formBackground.Location = this.Location;
                    formBackground.ShowInTaskbar = false;
                    formBackground.Show();


                    memberInfo.StartPosition = FormStartPosition.CenterScreen;
                    //memberInfo.FormBorderStyle = FormBorderStyle.None;
                    memberInfo.Owner = formBackground;
                    memberInfo.ShowDialog();

                    formBackground.Dispose();
                }
            } else {
                // Set the start date time to 00:00:00
                DateTime startDate = new DateTime(DTM_Start.Value.Year, DTM_Start.Value.Month, DTM_Start.Value.Day, 0, 0, 0);

                // Set the end date time to 23:59:00
                DateTime endDate = new DateTime(DTM_End.Value.Year, DTM_End.Value.Month, DTM_End.Value.Day, 23, 59, 0);
                Form formBackground = new Form();
                using (ReportPurchase memberInfo = new ReportPurchase(startDate, endDate)) {
                    formBackground.StartPosition = FormStartPosition.CenterScreen;
                    formBackground.FormBorderStyle = FormBorderStyle.None;
                    formBackground.Opacity = 0.50d;
                    formBackground.Size = new Size(1920, 1080);
                    formBackground.Location = this.Location;
                    formBackground.ShowInTaskbar = false;
                    formBackground.Show();


                    memberInfo.StartPosition = FormStartPosition.CenterScreen;
                    memberInfo.FormBorderStyle = FormBorderStyle.None;
                    memberInfo.Owner = formBackground;
                    memberInfo.ShowDialog();

                    formBackground.Dispose();
                }
            }
        }

        private void btn_DetailOrders_Click(object sender, EventArgs e) {
            Form formBackground = new Form();
            using (HistoryPurchase memberInfo = new HistoryPurchase(Convert.ToInt32(txt_Purchases.Text.Substring(3)))) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();


                memberInfo.StartPosition = FormStartPosition.CenterScreen;
                memberInfo.FormBorderStyle = FormBorderStyle.None;
                memberInfo.Owner = formBackground;
                memberInfo.ShowDialog();

                formBackground.Dispose();
            }
        }
    }
}

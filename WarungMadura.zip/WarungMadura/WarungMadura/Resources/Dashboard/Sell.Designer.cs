﻿using System.Threading;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    partial class Sell {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.Gpnl_Produk_Data = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.flp_Jabatan = new System.Windows.Forms.FlowLayoutPanel();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.gpnl_CreateData = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.L_STotal = new System.Windows.Forms.Label();
            this.txt_Chages = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Cash = new Guna.UI2.WinForms.Guna2TextBox();
            this.L_Member = new System.Windows.Forms.Label();
            this.txt_TelpMember = new Guna.UI2.WinForms.Guna2TextBox();
            this.cb_Diskon = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.l_ID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_BUY = new Guna.UI2.WinForms.Guna2Button();
            this.L_Total = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.flp_BUY = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_Search = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.Gpnl_Produk_Data.SuspendLayout();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.gpnl_CreateData.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gpnl_Produk_Data
            // 
            this.Gpnl_Produk_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Gpnl_Produk_Data.BackColor = System.Drawing.Color.White;
            this.Gpnl_Produk_Data.BorderRadius = 6;
            this.Gpnl_Produk_Data.Controls.Add(this.flp_Jabatan);
            this.Gpnl_Produk_Data.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.Gpnl_Produk_Data.Location = new System.Drawing.Point(22, 92);
            this.Gpnl_Produk_Data.Name = "Gpnl_Produk_Data";
            this.Gpnl_Produk_Data.Size = new System.Drawing.Size(649, 553);
            this.Gpnl_Produk_Data.TabIndex = 1;
            // 
            // flp_Jabatan
            // 
            this.flp_Jabatan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flp_Jabatan.AutoScroll = true;
            this.flp_Jabatan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.flp_Jabatan.ForeColor = System.Drawing.Color.White;
            this.flp_Jabatan.Location = new System.Drawing.Point(13, 16);
            this.flp_Jabatan.Name = "flp_Jabatan";
            this.flp_Jabatan.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.flp_Jabatan.Size = new System.Drawing.Size(620, 523);
            this.flp_Jabatan.TabIndex = 0;
            this.flp_Jabatan.Paint += new System.Windows.Forms.PaintEventHandler(this.flp_Jabatan_Paint);
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel1.BorderRadius = 10;
            this.guna2CustomGradientPanel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2CustomGradientPanel1.Controls.Add(this.gpnl_CreateData);
            this.guna2CustomGradientPanel1.Controls.Add(this.Gpnl_Produk_Data);
            this.guna2CustomGradientPanel1.Controls.Add(this.txt_Search);
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel1.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(7, 100);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(1180, 678);
            this.guna2CustomGradientPanel1.TabIndex = 1;
            // 
            // gpnl_CreateData
            // 
            this.gpnl_CreateData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpnl_CreateData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gpnl_CreateData.BackColor = System.Drawing.Color.White;
            this.gpnl_CreateData.BorderRadius = 6;
            this.gpnl_CreateData.Controls.Add(this.L_STotal);
            this.gpnl_CreateData.Controls.Add(this.txt_Chages);
            this.gpnl_CreateData.Controls.Add(this.txt_Cash);
            this.gpnl_CreateData.Controls.Add(this.L_Member);
            this.gpnl_CreateData.Controls.Add(this.txt_TelpMember);
            this.gpnl_CreateData.Controls.Add(this.cb_Diskon);
            this.gpnl_CreateData.Controls.Add(this.label5);
            this.gpnl_CreateData.Controls.Add(this.label3);
            this.gpnl_CreateData.Controls.Add(this.label1);
            this.gpnl_CreateData.Controls.Add(this.l_ID);
            this.gpnl_CreateData.Controls.Add(this.label4);
            this.gpnl_CreateData.Controls.Add(this.btn_BUY);
            this.gpnl_CreateData.Controls.Add(this.L_Total);
            this.gpnl_CreateData.Controls.Add(this.label2);
            this.gpnl_CreateData.Controls.Add(this.flp_BUY);
            this.gpnl_CreateData.Controls.Add(this.label10);
            this.gpnl_CreateData.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gpnl_CreateData.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gpnl_CreateData.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gpnl_CreateData.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gpnl_CreateData.Location = new System.Drawing.Point(685, 37);
            this.gpnl_CreateData.Name = "gpnl_CreateData";
            this.gpnl_CreateData.Size = new System.Drawing.Size(482, 608);
            this.gpnl_CreateData.TabIndex = 0;
            // 
            // L_STotal
            // 
            this.L_STotal.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.L_STotal.AutoSize = true;
            this.L_STotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.L_STotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_STotal.ForeColor = System.Drawing.Color.White;
            this.L_STotal.Location = new System.Drawing.Point(264, 261);
            this.L_STotal.Name = "L_STotal";
            this.L_STotal.Size = new System.Drawing.Size(44, 25);
            this.L_STotal.TabIndex = 61;
            this.L_STotal.Text = "Rp.";
            this.L_STotal.TextChanged += new System.EventHandler(this.L_STotal_TextChanged);
            // 
            // txt_Chages
            // 
            this.txt_Chages.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txt_Chages.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.txt_Chages.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_Chages.BorderRadius = 6;
            this.txt_Chages.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Chages.DefaultText = "";
            this.txt_Chages.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Chages.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Chages.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Chages.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Chages.Enabled = false;
            this.txt_Chages.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_Chages.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Chages.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Chages.ForeColor = System.Drawing.Color.White;
            this.txt_Chages.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Chages.Location = new System.Drawing.Point(257, 503);
            this.txt_Chages.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_Chages.Name = "txt_Chages";
            this.txt_Chages.PasswordChar = '\0';
            this.txt_Chages.PlaceholderForeColor = System.Drawing.Color.White;
            this.txt_Chages.PlaceholderText = "Rp.";
            this.txt_Chages.ReadOnly = true;
            this.txt_Chages.SelectedText = "";
            this.txt_Chages.Size = new System.Drawing.Size(203, 35);
            this.txt_Chages.TabIndex = 60;
            this.txt_Chages.TextChanged += new System.EventHandler(this.txt_TextChanges);
            // 
            // txt_Cash
            // 
            this.txt_Cash.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txt_Cash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.txt_Cash.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_Cash.BorderRadius = 6;
            this.txt_Cash.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Cash.DefaultText = "";
            this.txt_Cash.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Cash.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Cash.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Cash.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Cash.Enabled = false;
            this.txt_Cash.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_Cash.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Cash.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cash.ForeColor = System.Drawing.Color.White;
            this.txt_Cash.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Cash.Location = new System.Drawing.Point(257, 457);
            this.txt_Cash.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_Cash.Name = "txt_Cash";
            this.txt_Cash.PasswordChar = '\0';
            this.txt_Cash.PlaceholderForeColor = System.Drawing.Color.White;
            this.txt_Cash.PlaceholderText = "Rp.";
            this.txt_Cash.SelectedText = "";
            this.txt_Cash.Size = new System.Drawing.Size(203, 35);
            this.txt_Cash.TabIndex = 59;
            this.txt_Cash.TextChanged += new System.EventHandler(this.txt_TextCash);
            this.txt_Cash.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPressPrice);
            this.txt_Cash.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txt_Cash_MouseDown);
            // 
            // L_Member
            // 
            this.L_Member.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.L_Member.AutoSize = true;
            this.L_Member.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.L_Member.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Member.ForeColor = System.Drawing.Color.White;
            this.L_Member.Location = new System.Drawing.Point(31, 87);
            this.L_Member.Name = "L_Member";
            this.L_Member.Size = new System.Drawing.Size(146, 25);
            this.L_Member.TabIndex = 58;
            this.L_Member.Text = "Member : N/A";
            // 
            // txt_TelpMember
            // 
            this.txt_TelpMember.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txt_TelpMember.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.txt_TelpMember.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_TelpMember.BorderRadius = 6;
            this.txt_TelpMember.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TelpMember.DefaultText = "";
            this.txt_TelpMember.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_TelpMember.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_TelpMember.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_TelpMember.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_TelpMember.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.txt_TelpMember.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_TelpMember.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TelpMember.ForeColor = System.Drawing.Color.White;
            this.txt_TelpMember.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_TelpMember.Location = new System.Drawing.Point(36, 291);
            this.txt_TelpMember.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_TelpMember.Name = "txt_TelpMember";
            this.txt_TelpMember.PasswordChar = '\0';
            this.txt_TelpMember.PlaceholderForeColor = System.Drawing.Color.White;
            this.txt_TelpMember.PlaceholderText = "Phone Number";
            this.txt_TelpMember.SelectedText = "";
            this.txt_TelpMember.Size = new System.Drawing.Size(424, 35);
            this.txt_TelpMember.TabIndex = 57;
            this.txt_TelpMember.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_TelpMember_KeyPress);
            // 
            // cb_Diskon
            // 
            this.cb_Diskon.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cb_Diskon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.cb_Diskon.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.cb_Diskon.BorderRadius = 6;
            this.cb_Diskon.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_Diskon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Diskon.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.cb_Diskon.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Diskon.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Diskon.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_Diskon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cb_Diskon.ItemHeight = 30;
            this.cb_Diskon.Location = new System.Drawing.Point(36, 331);
            this.cb_Diskon.Name = "cb_Diskon";
            this.cb_Diskon.Size = new System.Drawing.Size(424, 36);
            this.cb_Diskon.TabIndex = 56;
            this.cb_Diskon.SelectedIndexChanged += new System.EventHandler(this.cb_Diskon_SelectedIndexChanged);
            this.cb_Diskon.Click += new System.EventHandler(this.cb_Diskon_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(31, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 25);
            this.label5.TabIndex = 55;
            this.label5.Text = "Sub Total";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(31, 427);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 25);
            this.label3.TabIndex = 54;
            this.label3.Text = "Total";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(31, 467);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 25);
            this.label1.TabIndex = 53;
            this.label1.Text = "Cash";
            // 
            // l_ID
            // 
            this.l_ID.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.l_ID.AutoSize = true;
            this.l_ID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.l_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_ID.ForeColor = System.Drawing.Color.White;
            this.l_ID.Location = new System.Drawing.Point(306, 87);
            this.l_ID.Name = "l_ID";
            this.l_ID.Size = new System.Drawing.Size(162, 25);
            this.l_ID.TabIndex = 52;
            this.l_ID.Text = "No : SNT00001";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label4.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(29, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 39);
            this.label4.TabIndex = 51;
            this.label4.Text = "Sell Product";
            // 
            // btn_BUY
            // 
            this.btn_BUY.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btn_BUY.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_BUY.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_BUY.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_BUY.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_BUY.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(151)))), ((int)(((byte)(168)))));
            this.btn_BUY.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BUY.ForeColor = System.Drawing.Color.White;
            this.btn_BUY.Location = new System.Drawing.Point(57, 550);
            this.btn_BUY.Name = "btn_BUY";
            this.btn_BUY.Size = new System.Drawing.Size(369, 45);
            this.btn_BUY.TabIndex = 50;
            this.btn_BUY.Text = "Buy Now";
            this.btn_BUY.Click += new System.EventHandler(this.btn_BUY_Click);
            // 
            // L_Total
            // 
            this.L_Total.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.L_Total.AutoSize = true;
            this.L_Total.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.L_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Total.ForeColor = System.Drawing.Color.White;
            this.L_Total.Location = new System.Drawing.Point(264, 427);
            this.L_Total.Name = "L_Total";
            this.L_Total.Size = new System.Drawing.Size(44, 25);
            this.L_Total.TabIndex = 49;
            this.L_Total.Text = "Rp.";
            this.L_Total.TextChanged += new System.EventHandler(this.Label_Currency_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(31, 510);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 25);
            this.label2.TabIndex = 48;
            this.label2.Text = "Changes";
            // 
            // flp_BUY
            // 
            this.flp_BUY.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flp_BUY.AutoScroll = true;
            this.flp_BUY.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flp_BUY.Location = new System.Drawing.Point(3, 128);
            this.flp_BUY.Name = "flp_BUY";
            this.flp_BUY.Size = new System.Drawing.Size(476, 121);
            this.flp_BUY.TabIndex = 47;
            this.flp_BUY.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.flp_Add_Remove_Items);
            this.flp_BUY.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.flp_Add_Remove_Items);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(68, 873);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 46;
            // 
            // txt_Search
            // 
            this.txt_Search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Search.BackColor = System.Drawing.Color.Transparent;
            this.txt_Search.BorderRadius = 10;
            this.txt_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Search.DefaultText = "";
            this.txt_Search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Search.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.txt_Search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Search.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Search.ForeColor = System.Drawing.Color.White;
            this.txt_Search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Search.IconRight = global::WarungMadura.Properties.Resources.search;
            this.txt_Search.IconRightOffset = new System.Drawing.Point(10, 0);
            this.txt_Search.IconRightSize = new System.Drawing.Size(30, 30);
            this.txt_Search.Location = new System.Drawing.Point(22, 37);
            this.txt_Search.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.PasswordChar = '\0';
            this.txt_Search.PlaceholderForeColor = System.Drawing.Color.White;
            this.txt_Search.PlaceholderText = "Search...";
            this.txt_Search.SelectedText = "";
            this.txt_Search.Size = new System.Drawing.Size(649, 46);
            this.txt_Search.TabIndex = 0;
            this.txt_Search.IconRightClick += new System.EventHandler(this.txt_Search_IconRightClick);
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.SystemColors.Control;
            this.guna2CustomGradientPanel2.BorderRadius = 6;
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomLeft = false;
            this.guna2CustomGradientPanel2.CustomizableEdges.BottomRight = false;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(7, 30);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(1180, 359);
            this.guna2CustomGradientPanel2.TabIndex = 2;
            // 
            // Sell
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2CustomGradientPanel2);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sell";
            this.Text = "Produk";
            this.Load += new System.EventHandler(this.Produk_Load);
            this.EnabledChanged += new System.EventHandler(this.Produk_EnabledChanged);
            this.Gpnl_Produk_Data.ResumeLayout(false);
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.gpnl_CreateData.ResumeLayout(false);
            this.gpnl_CreateData.PerformLayout();
            this.ResumeLayout(false);

        }
        /*        private void LoadObjectsOnForm() {
                    // Simulate a delay to mimic loading time
                    Thread.Sleep(2000); // Adjust the delay time as needed
                        // 
                        // txt_Search
                        // 
                        this.txt_Search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
                        this.txt_Search.BackColor = System.Drawing.Color.Transparent;
                        this.txt_Search.BorderRadius = 10;
                        this.txt_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
                        this.txt_Search.DefaultText = "";
                        this.txt_Search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
                        this.txt_Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
                        this.txt_Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                        this.txt_Search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
                        this.txt_Search.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
                        this.txt_Search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                        this.txt_Search.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                        this.txt_Search.ForeColor = System.Drawing.Color.White;
                        this.txt_Search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
                        this.txt_Search.Location = new System.Drawing.Point(22, 38);
                        this.txt_Search.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
                        this.txt_Search.NameDiscount = "txt_Search";
                        this.txt_Search.PasswordChar = '\0';
                        this.txt_Search.PlaceholderForeColor = System.Drawing.Color.White;
                        this.txt_Search.PlaceholderText = "Search...";
                        this.txt_Search.SelectedText = "";
                        this.txt_Search.Size = new System.Drawing.Size(649, 46);
                        this.txt_Search.TabIndex = 0;
                }*/

        #endregion
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel Gpnl_Produk_Data;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private System.Windows.Forms.FlowLayoutPanel flp_Jabatan;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel gpnl_CreateData;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txt_Search;
        private FlowLayoutPanel flp_BUY;
        private Guna.UI2.WinForms.Guna2Button btn_BUY;
        private Label L_Total;
        private Label label2;
        private Label l_ID;
        private Label label4;
        private Label label3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txt_TelpMember;
        private Guna.UI2.WinForms.Guna2ComboBox cb_Diskon;
        private Label label5;
        private Label L_Member;
        private Guna.UI2.WinForms.Guna2TextBox txt_Chages;
        private Guna.UI2.WinForms.Guna2TextBox txt_Cash;
        private Label L_STotal;
    }
}
﻿namespace WarungMadura.Resources.Dashboard {
    partial class KategoriProdukInfo {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.Borderles = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_IdCategories = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_CategoriesName = new Guna.UI2.WinForms.Guna2TextBox();
            this.timer_Opening = new System.Windows.Forms.Timer(this.components);
            this.timer_Closing = new System.Windows.Forms.Timer(this.components);
            this.txt_Unit = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bnt_Exit = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Borderles
            // 
            this.Borderles.BorderRadius = 10;
            this.Borderles.ContainerControl = this;
            this.Borderles.DockIndicatorTransparencyValue = 0.6D;
            this.Borderles.DragForm = false;
            this.Borderles.TransparentWhileDrag = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Categories Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "ID Categories";
            // 
            // txt_IdCategories
            // 
            this.txt_IdCategories.BorderRadius = 6;
            this.txt_IdCategories.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_IdCategories.DefaultText = "";
            this.txt_IdCategories.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_IdCategories.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_IdCategories.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IdCategories.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IdCategories.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IdCategories.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IdCategories.ForeColor = System.Drawing.Color.Black;
            this.txt_IdCategories.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IdCategories.Location = new System.Drawing.Point(176, 55);
            this.txt_IdCategories.Margin = new System.Windows.Forms.Padding(4);
            this.txt_IdCategories.Name = "txt_IdCategories";
            this.txt_IdCategories.PasswordChar = '\0';
            this.txt_IdCategories.PlaceholderText = "";
            this.txt_IdCategories.ReadOnly = true;
            this.txt_IdCategories.SelectedText = "";
            this.txt_IdCategories.Size = new System.Drawing.Size(163, 36);
            this.txt_IdCategories.TabIndex = 11;
            // 
            // txt_CategoriesName
            // 
            this.txt_CategoriesName.BorderRadius = 6;
            this.txt_CategoriesName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_CategoriesName.DefaultText = "";
            this.txt_CategoriesName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_CategoriesName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_CategoriesName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_CategoriesName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_CategoriesName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_CategoriesName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CategoriesName.ForeColor = System.Drawing.Color.Black;
            this.txt_CategoriesName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_CategoriesName.Location = new System.Drawing.Point(176, 105);
            this.txt_CategoriesName.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CategoriesName.Name = "txt_CategoriesName";
            this.txt_CategoriesName.PasswordChar = '\0';
            this.txt_CategoriesName.PlaceholderText = "";
            this.txt_CategoriesName.ReadOnly = true;
            this.txt_CategoriesName.SelectedText = "";
            this.txt_CategoriesName.Size = new System.Drawing.Size(163, 36);
            this.txt_CategoriesName.TabIndex = 12;
            // 
            // timer_Opening
            // 
            this.timer_Opening.Enabled = true;
            this.timer_Opening.Interval = 1;
            this.timer_Opening.Tick += new System.EventHandler(this.timer_Opening_Tick);
            // 
            // timer_Closing
            // 
            this.timer_Closing.Interval = 1;
            this.timer_Closing.Tick += new System.EventHandler(this.timer_Closing_Tick);
            // 
            // txt_Unit
            // 
            this.txt_Unit.BorderRadius = 6;
            this.txt_Unit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Unit.DefaultText = "";
            this.txt_Unit.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Unit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Unit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Unit.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Unit.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Unit.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Unit.ForeColor = System.Drawing.Color.Black;
            this.txt_Unit.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Unit.Location = new System.Drawing.Point(176, 159);
            this.txt_Unit.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Unit.Name = "txt_Unit";
            this.txt_Unit.PasswordChar = '\0';
            this.txt_Unit.PlaceholderText = "";
            this.txt_Unit.ReadOnly = true;
            this.txt_Unit.SelectedText = "";
            this.txt_Unit.Size = new System.Drawing.Size(163, 36);
            this.txt_Unit.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 24);
            this.label3.TabIndex = 14;
            this.label3.Text = "Unit";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label12.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(30, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(275, 29);
            this.label12.TabIndex = 57;
            this.label12.Text = "Detailed Information";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label13.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(93, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 29);
            this.label13.TabIndex = 56;
            this.label13.Text = "Categories";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(-4, -1);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(340, 80);
            this.guna2HtmlLabel1.TabIndex = 54;
            this.guna2HtmlLabel1.Text = null;
            // 
            // bnt_Exit
            // 
            this.bnt_Exit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bnt_Exit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bnt_Exit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bnt_Exit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bnt_Exit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.bnt_Exit.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_Exit.ForeColor = System.Drawing.Color.White;
            this.bnt_Exit.Location = new System.Drawing.Point(-4, 258);
            this.bnt_Exit.Name = "bnt_Exit";
            this.bnt_Exit.Size = new System.Drawing.Size(340, 45);
            this.bnt_Exit.TabIndex = 53;
            this.bnt_Exit.Text = "CLOSE";
            this.bnt_Exit.Click += new System.EventHandler(this.bnt_Exit_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::WarungMadura.Properties.Resources.DetailInfo;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(7, 42);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(321, 245);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 55;
            this.guna2PictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.panel1.Controls.Add(this.txt_IdCategories);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txt_CategoriesName);
            this.panel1.Controls.Add(this.txt_Unit);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(334, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(357, 303);
            this.panel1.TabIndex = 58;
            // 
            // KategoriProdukInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.ClientSize = new System.Drawing.Size(691, 303);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.bnt_Exit);
            this.Controls.Add(this.guna2PictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KategoriProdukInfo";
            this.Opacity = 0D;
            this.Text = "ProductInfo";
            this.Load += new System.EventHandler(this.ProductInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm Borderles;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txt_CategoriesName;
        private Guna.UI2.WinForms.Guna2TextBox txt_IdCategories;
        private System.Windows.Forms.Timer timer_Opening;
        private System.Windows.Forms.Timer timer_Closing;
        private Guna.UI2.WinForms.Guna2TextBox txt_Unit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button bnt_Exit;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}
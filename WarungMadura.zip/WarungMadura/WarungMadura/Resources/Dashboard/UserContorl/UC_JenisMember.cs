﻿using CustomMessageBox;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_JenisMember : UserControl {
        string NamaPostion;
        int id_Postion, status, MinPoint;

        public event EventHandler<JenisMemberEventArgs> InfoButton;
        public event EventHandler<JenisMemberEventArgs> EditButton;
        public event EventHandler<JenisMemberEventArgsD> DeleteButton;

        public UC_JenisMember(int id, string KJName, int Status, int MinPoint)
        {
            InitializeComponent();
            id_Postion = id;
            NamaPostion = KJName;
            this.MinPoint = MinPoint;
            status = Status;

            L_PName.Text = KJName;

            L_ID.Text = "TL" + id.ToString().PadLeft(3, '0');
            L_min.Text = MinPoint.ToString();

            // Menonaktifkan tombol hapus jika Status == 0
            if (Status == 0)
            {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new JenisMemberEventArgs(id_Postion, NamaPostion, status, MinPoint));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new JenisMemberEventArgsD(id_Postion, NamaPostion));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new JenisMemberEventArgs(id_Postion, NamaPostion, status, MinPoint));
        }

        public UC_JenisMember() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class JenisMemberEventArgsD : EventArgs {
        public int id_jenis_member { get; }
        public string Nama{ get; }

        public JenisMemberEventArgsD(int id, string nama) {
            id_jenis_member = id;
            Nama= nama;
        }
    }
    public class JenisMemberEventArgs  : EventArgs {
        public int id_jenis_member { get; }
        public string Nama{ get; }
        public int Status { get; }
        public int MinPoint { get; }

        public JenisMemberEventArgs(int id,string loyalty, int status, int minpoint)
        {
            id_jenis_member = id;
            Nama= loyalty;
            Status = status;
            MinPoint = minpoint;
        }
    }
}

﻿namespace WarungMadura.Resources.Dashboard.UserContorl {
    partial class UC_TSProduk {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.L_Price = new System.Windows.Forms.Label();
            this.L_Name = new System.Windows.Forms.Label();
            this.p_Product = new System.Windows.Forms.PictureBox();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p_Product)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2Panel1.Controls.Add(this.L_Price);
            this.guna2Panel1.Controls.Add(this.L_Name);
            this.guna2Panel1.Location = new System.Drawing.Point(0, 232);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(231, 68);
            this.guna2Panel1.TabIndex = 0;
            // 
            // L_Price
            // 
            this.L_Price.AutoSize = true;
            this.L_Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Price.ForeColor = System.Drawing.Color.White;
            this.L_Price.Location = new System.Drawing.Point(10, 40);
            this.L_Price.Name = "L_Price";
            this.L_Price.Size = new System.Drawing.Size(99, 24);
            this.L_Price.TabIndex = 1;
            this.L_Price.Text = "Rp. 10,000";
            this.L_Price.TextChanged += new System.EventHandler(this.txt_Currency_Label);
            // 
            // L_Name
            // 
            this.L_Name.AutoSize = true;
            this.L_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Name.ForeColor = System.Drawing.Color.White;
            this.L_Name.Location = new System.Drawing.Point(4, 12);
            this.L_Name.Name = "L_Name";
            this.L_Name.Size = new System.Drawing.Size(131, 24);
            this.L_Name.TabIndex = 0;
            this.L_Name.Text = "Product NameDiscount";
            this.L_Name.Click += new System.EventHandler(this.label1_Click);
            // 
            // p_Product
            // 
            this.p_Product.Location = new System.Drawing.Point(0, 0);
            this.p_Product.Name = "p_Product";
            this.p_Product.Size = new System.Drawing.Size(231, 231);
            this.p_Product.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p_Product.TabIndex = 1;
            this.p_Product.TabStop = false;
            this.p_Product.Click += new System.EventHandler(this.p_Product_Click);
            // 
            // UC_TSProduk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.p_Product);
            this.Controls.Add(this.guna2Panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 3, 20, 20);
            this.Name = "UC_TSProduk";
            this.Size = new System.Drawing.Size(231, 300);
            this.Click += new System.EventHandler(this.UC_TSProduk_Click);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p_Product)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.PictureBox p_Product;
        private System.Windows.Forms.Label L_Price;
        private System.Windows.Forms.Label L_Name;
    }
}

﻿using CustomMessageBox;
using System;
using System.IO;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Karyawan : UserControl {
        string NamaKaryawan, Username, Password, Alamat, Telp, Email, Gender, NamaJabatan;
        int id_karyawan, id_jabatan, Status;
        byte[] Picture;

        public event EventHandler<KaryawanEventArgs> InfoButton;
        public event EventHandler<KaryawanEventArgs> EditButton;
        public event EventHandler<KaryawanEventArgsD> DeleteButton;

        public UC_Karyawan(int id, string namaKaryawan, string Username, string Password, string Alamat, string Telp, string Email, string Gender, int idJabatan, string namaJabatan, byte[] picture, int Status) {
            InitializeComponent();
            id_karyawan = id;
            L_ID.Text = "EMP" + id.ToString().PadLeft(5, '0');
            NamaKaryawan = namaKaryawan;
            L_EName.Text = namaKaryawan;
            NamaJabatan = namaJabatan;
            L_Position.Text = namaJabatan;

            id_jabatan = idJabatan;
          

            this.Status = Status;
            this.Username = Username;
            this.Password = Password;
            this.Alamat = Alamat;
            this.Telp = Telp;
            this.Email = Email;
            this.Gender = Gender;
            this.Picture = picture;

            if (Status.Equals(0)) {
                btn_Edit.ImageOffset = new System.Drawing.Point(1, btn_Edit.ImageOffset.Y);
                btn_Delete.Enabled = false;
                btn_Edit.Image = Properties.Resources.restore;
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new KaryawanEventArgs(id_karyawan, NamaKaryawan, Username, Password, Alamat, Telp, Email, Gender, id_jabatan, NamaJabatan, Picture, Status));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new KaryawanEventArgsD(id_karyawan, NamaKaryawan));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new KaryawanEventArgs(id_karyawan, NamaKaryawan, Username, Password, Alamat, Telp, Email, Gender, id_jabatan, NamaJabatan, Picture, Status));
        }

        public UC_Karyawan() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class KaryawanEventArgsD : EventArgs {
        public int id_Karyawan { get; }
        public string NamaKaryawan { get; }

        public KaryawanEventArgsD(int id, string namaKaryawan) {
            id_Karyawan = id;
            NamaKaryawan = namaKaryawan;
        }
    }
    public class KaryawanEventArgs : EventArgs {

        public int id_jabatan { get; }
        public int id_Karyawan { get; }
        public string NamaKaryawan { get; }
        public string Username { get; }
        public string Password { get; }
        public string Alamat { get; }
        public string Telp { get; }
        public string Gender { get; }
        public string Email { get; }
        public string NamaJabatan { get; }
        public int Status { get; }
        public byte[] Picture { get; }

        public KaryawanEventArgs(int id, string namaKaryawan, string Username, string Password, string Alamat, string Telp, string Email, string Gender, int idJabatan, string namaJabatan, byte[] picture, int status) {
            id_Karyawan = id;
            id_jabatan = idJabatan;
            NamaKaryawan = namaKaryawan;
            this.Username = Username;
            this.Password = Password;
            this.Alamat = Alamat;
            this.Telp = Telp;
            this.Gender = Gender;
            this.Email = Email;
            NamaJabatan = namaJabatan;
            Status = status;
            Picture = picture;
        }
    }
}

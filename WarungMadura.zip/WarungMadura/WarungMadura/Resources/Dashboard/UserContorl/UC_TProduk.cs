﻿using CustomMessageBox;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_TProduk : UserControl {
        string NamaProduct,Unit, name_CProduct, name_Supplier;
        int id_Product,id_CProduct,id_Supplier,stock,discount;
        decimal sell, buy;
        byte[] Picture;

        public event EventHandler<ProductEventArgs> InfoButton;
        public event EventHandler<ProductEventArgs> ADDButton;

        public UC_TProduk(int id, string PName, int idCProduct,string Name_CProduct, int idSupplier,string Name_Supplier, int stock, string unit, int discount, decimal sell, decimal buy, byte[] picture,int Status) {
            InitializeComponent();
            id_Product = id;
            NamaProduct = PName;
            if(NamaProduct.Length > 15) {
                L_PName.Text = PName.Substring(0,15)+"...";
            } else {
                L_PName.Text = PName;
            }
            id_CProduct = idCProduct;
            id_Supplier = idSupplier;
            name_CProduct = Name_CProduct;
            name_Supplier = Name_Supplier;
            this.stock = stock;
            this.Unit = unit;
            this.discount = discount;
            this.sell = sell;
            this.buy = buy;
            this.Picture = picture;
            L_ID.Text = "PDCT" + id.ToString().PadLeft(3, '0');
            l_Stock.Text = stock.ToString();
        }
        private void btn_Add_Click(object sender, EventArgs e) {
            ADDButton?.Invoke(this, new ProductEventArgs(id_Product, NamaProduct, Unit, id_CProduct, name_CProduct, id_Supplier, name_Supplier, stock, discount, sell, buy, Picture));
        }


        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new ProductEventArgs(id_Product,NamaProduct, Unit, id_CProduct, name_CProduct, id_Supplier, name_Supplier, stock, discount, sell, buy, Picture));
        }

        public UC_TProduk() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
}

﻿using CustomMessageBox;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Member : UserControl {
        string connectionString = Properties.Resources.ConnectionString;
        string NameMember, Address, Phone, Email,categoriName;
        int id_Member, status, Point;

        public event EventHandler<MemberEventArgs> InfoButton;
        public event EventHandler<MemberEventArgs> EditButton;
        public event EventHandler<MemberEventArgsD> DeleteButton;

        public UC_Member(int id_Member, int categori, string Name,string NJenisMember, string Address, string Phone, string Email, int status, int Point)
        {
            InitializeComponent();
            this.id_Member = id_Member;
            this.categoriName = NJenisMember;
            if(Name.Length > 15) {
                L_PName.Text = Name.Substring(0,15)+"...";
            } else {
                L_PName.Text = Name;
            }
            this.NameMember= Name;
            this.Address = Address;
            this.Phone = Phone;
            this.Email = Email;
            this.Point = Point;
            this.status = status;

            L_ID.Text = "MBR" + id_Member.ToString().PadLeft(3, '0');
            L_Category.Text = NJenisMember;

            // Menonaktifkan tombol hapus jika Status == 0
            if (status == 0)
            {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }

        private string getName(int id)
        {
            string name = "";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "SELECT dbo.GetJenisMemberNameById(@id_jenis_member)";

                        // Parameter untuk fungsi
                        command.Parameters.AddWithValue("@id_jenis_member", id);

                        // Membaca hasil
                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            name = result.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return name;
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new MemberEventArgs(id_Member, categoriName, NameMember, Address, Phone, Email, status, Point));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new MemberEventArgsD(id_Member, NameMember));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new MemberEventArgs(id_Member, categoriName, NameMember, Address, Phone, Email, status, Point));
        }

        public UC_Member() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class MemberEventArgsD : EventArgs {
        public int id_member { get; }
        public string Nama{ get; }

        public MemberEventArgsD(int id, string nama) {
            id_member = id;
            Nama= nama;
        }
    }
    public class MemberEventArgs  : EventArgs {
        public int id_member { get; }
        public String Categories { get; }
        public string Nama{ get; }
        public string Address { get; }
        public string Phone {  get; }
        public string Email {  get; }
        public int Status { get; }
        public int Point { get; }

        public MemberEventArgs(int id, String categori,string name, string address, string phone, string email, int status, int point)
        {
            id_member = id;
            Categories = categori;
            Nama= name;
            Address = address;
            Phone = phone;
            Email = email;
            Status = status;
            Point = point;
        }
    }
}

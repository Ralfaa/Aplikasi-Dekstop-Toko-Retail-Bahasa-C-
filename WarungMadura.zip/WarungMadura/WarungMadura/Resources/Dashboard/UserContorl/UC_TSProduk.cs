﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_TSProduk : UserControl {
        string NamaProduct, Unit, name_CProduct, name_Supplier;
        int id_Product, id_CProduct, id_Supplier, stock, discount;
        public event EventHandler<ProductEventArgs> ADDButton;

        private void UC_TSProduk_Click(object sender, EventArgs e) {
        }

        private void p_Product_Click(object sender, EventArgs e) {
            ADDButton?.Invoke(this, new ProductEventArgs(id_Product, NamaProduct, Unit, id_CProduct, name_CProduct, id_Supplier, name_Supplier, stock, discount, sell, buy, Picture));
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e) {

        }

        private void label1_Click(object sender, EventArgs e) {
        }

        decimal sell, buy;
        byte[] Picture;
        public UC_TSProduk(int id, string PName, int idCProduct, string Name_CProduct, int idSupplier, string Name_Supplier, int stock, string unit, int discount, decimal sell, decimal buy, byte[] picture, int Status) {
            InitializeComponent();
            id_Product = id;
            NamaProduct = PName;
            if(NamaProduct.Length > 15 ) {
                L_Name.Text = NamaProduct.Substring(0, 15) + "...";
            } else {
                L_Name.Text = PName;
            }
            L_Price.Text = sell.ToString("F0");
            id_CProduct = idCProduct;
            id_Supplier = idSupplier;
            name_CProduct = Name_CProduct;
            name_Supplier = Name_Supplier;
            this.stock = stock;
            this.Unit = unit;
            this.discount = discount;
            this.sell = sell;
            this.buy = buy;
            this.Picture = picture;
            if (picture != null && picture.Length > 0) {
                using (var ms = new System.IO.MemoryStream(picture)) {
                    p_Product.Image = Image.FromStream(ms);
                }
            } else {
                p_Product.Image = null;
            }

        }
        private void txt_Currency_Label(object sender, EventArgs e) {
            Label guna2Text = (Label)sender;
            string buffer = guna2Text.Text.Replace("Rp", "").Trim();
            buffer = buffer.Replace(".", "");
            decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result);
            string formattedBuffer = result.ToString("#,##0", CultureInfo.InvariantCulture).Replace(",", ".");
            guna2Text.Text = "Rp " + formattedBuffer;
        }
    }
}

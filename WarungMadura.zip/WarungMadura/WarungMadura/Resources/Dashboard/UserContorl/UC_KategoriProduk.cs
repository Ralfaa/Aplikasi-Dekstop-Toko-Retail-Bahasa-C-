﻿using CustomMessageBox;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_KategoriProduk : UserControl {
        string NamaCategoriesProduct, unit;
        int id_Categories, status;

        public event EventHandler<CProductEventArgs> InfoButton;
        public event EventHandler<CProductEventArgs> EditButton;
        public event EventHandler<CProductEventArgsD> DeleteButton;

        public UC_KategoriProduk(int id, string KJName, int Status, string Unit)
        {
            InitializeComponent();
            id_Categories = id;
            NamaCategoriesProduct = KJName;
            unit = Unit;
            status = Status;

            L_PName.Text = KJName;

            L_ID.Text = "UNT" + id.ToString().PadLeft(3, '0');

            // Menonaktifkan tombol hapus jika Status == 0
            if (Status == 0)
            {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new CProductEventArgs(id_Categories, NamaCategoriesProduct, status, unit));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new CProductEventArgsD(id_Categories, NamaCategoriesProduct));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new CProductEventArgs(id_Categories, NamaCategoriesProduct, status, unit));
        }

        public UC_KategoriProduk() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class CProductEventArgsD : EventArgs {
        public int id_Categories { get; }
        public string NamaCategoriesProduct { get; }

        public CProductEventArgsD(int id, string namaCategoriesProduct) {
            id_Categories = id;
            NamaCategoriesProduct = namaCategoriesProduct;
        }
    }
    public class CProductEventArgs : EventArgs {
        public int id_Categories { get; }
        public string NamaCategoriesProduct { get; }
        public int Status { get; }
        public string Unit { get; }

        public CProductEventArgs(int id,string namaCategoriesProduct, int status, string unit)
        {
            id_Categories = id;
            NamaCategoriesProduct = namaCategoriesProduct;
            Status = status;
            Unit = unit;
        }
    }
}

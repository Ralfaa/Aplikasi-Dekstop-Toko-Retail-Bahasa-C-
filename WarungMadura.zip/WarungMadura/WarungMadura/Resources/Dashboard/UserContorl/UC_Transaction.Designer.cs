﻿namespace WarungMadura.Resources.Dashboard.UserContorl {
    partial class UC_Transaction {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btn_Delete = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes2 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes3 = new Guna.UI2.WinForms.Guna2Shapes();
            this.L_PName = new System.Windows.Forms.Label();
            this.L_Price = new System.Windows.Forms.Label();
            this.txt_QTY = new Guna.UI2.WinForms.Guna2TextBox();
            this.btn_Increase = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Decrease = new Guna.UI2.WinForms.Guna2Button();
            this.l_StartPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Delete
            // 
            this.btn_Delete.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btn_Delete.HoverState.ImageSize = new System.Drawing.Size(40, 40);
            this.btn_Delete.Image = global::WarungMadura.Properties.Resources.delete;
            this.btn_Delete.ImageOffset = new System.Drawing.Point(5, 0);
            this.btn_Delete.ImageRotate = 0F;
            this.btn_Delete.ImageSize = new System.Drawing.Size(35, 35);
            this.btn_Delete.Location = new System.Drawing.Point(19, 9);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.PressedState.ImageSize = new System.Drawing.Size(40, 40);
            this.btn_Delete.Size = new System.Drawing.Size(50, 50);
            this.btn_Delete.TabIndex = 0;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // guna2Shapes1
            // 
            this.guna2Shapes1.BorderColor = System.Drawing.Color.Black;
            this.guna2Shapes1.FillColor = System.Drawing.Color.Black;
            this.guna2Shapes1.Location = new System.Drawing.Point(3, 63);
            this.guna2Shapes1.Name = "guna2Shapes1";
            this.guna2Shapes1.PolygonSkip = 1;
            this.guna2Shapes1.Rotate = 0F;
            this.guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Ellipse;
            this.guna2Shapes1.Size = new System.Drawing.Size(15, 15);
            this.guna2Shapes1.TabIndex = 1;
            this.guna2Shapes1.Text = "guna2Shapes1";
            this.guna2Shapes1.Zoom = 80;
            // 
            // guna2Shapes2
            // 
            this.guna2Shapes2.BorderColor = System.Drawing.Color.Black;
            this.guna2Shapes2.FillColor = System.Drawing.Color.Black;
            this.guna2Shapes2.Location = new System.Drawing.Point(-40, 63);
            this.guna2Shapes2.Name = "guna2Shapes2";
            this.guna2Shapes2.PolygonSkip = 1;
            this.guna2Shapes2.Rotate = 0F;
            this.guna2Shapes2.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes2.Size = new System.Drawing.Size(524, 15);
            this.guna2Shapes2.TabIndex = 2;
            this.guna2Shapes2.Text = "guna2Shapes2";
            this.guna2Shapes2.Zoom = 80;
            // 
            // guna2Shapes3
            // 
            this.guna2Shapes3.BorderColor = System.Drawing.Color.Black;
            this.guna2Shapes3.FillColor = System.Drawing.Color.Black;
            this.guna2Shapes3.Location = new System.Drawing.Point(424, 63);
            this.guna2Shapes3.Name = "guna2Shapes3";
            this.guna2Shapes3.PolygonSkip = 1;
            this.guna2Shapes3.Rotate = 0F;
            this.guna2Shapes3.Shape = Guna.UI2.WinForms.Enums.ShapeType.Ellipse;
            this.guna2Shapes3.Size = new System.Drawing.Size(15, 15);
            this.guna2Shapes3.TabIndex = 3;
            this.guna2Shapes3.Text = "guna2Shapes3";
            this.guna2Shapes3.Zoom = 80;
            // 
            // L_PName
            // 
            this.L_PName.AutoSize = true;
            this.L_PName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_PName.Location = new System.Drawing.Point(98, 8);
            this.L_PName.Name = "L_PName";
            this.L_PName.Size = new System.Drawing.Size(149, 24);
            this.L_PName.TabIndex = 4;
            this.L_PName.Text = "Product Is Name";
            // 
            // L_Price
            // 
            this.L_Price.AutoSize = true;
            this.L_Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Price.Location = new System.Drawing.Point(96, 36);
            this.L_Price.Name = "L_Price";
            this.L_Price.Size = new System.Drawing.Size(97, 20);
            this.L_Price.TabIndex = 5;
            this.L_Price.Text = "Rp. 10,000";
            this.L_Price.TextChanged += new System.EventHandler(this.txt_Currency_Label);
            // 
            // txt_QTY
            // 
            this.txt_QTY.BackColor = System.Drawing.Color.White;
            this.txt_QTY.BorderColor = System.Drawing.Color.Black;
            this.txt_QTY.BorderThickness = 0;
            this.txt_QTY.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_QTY.CustomizableEdges.BottomRight = false;
            this.txt_QTY.CustomizableEdges.TopRight = false;
            this.txt_QTY.DefaultText = "1";
            this.txt_QTY.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_QTY.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_QTY.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_QTY.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_QTY.FillColor = System.Drawing.Color.Gainsboro;
            this.txt_QTY.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_QTY.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_QTY.ForeColor = System.Drawing.Color.Black;
            this.txt_QTY.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_QTY.Location = new System.Drawing.Point(332, 20);
            this.txt_QTY.MaxLength = 10;
            this.txt_QTY.Name = "txt_QTY";
            this.txt_QTY.PasswordChar = '\0';
            this.txt_QTY.PlaceholderForeColor = System.Drawing.Color.Black;
            this.txt_QTY.PlaceholderText = "";
            this.txt_QTY.SelectedText = "";
            this.txt_QTY.Size = new System.Drawing.Size(52, 36);
            this.txt_QTY.TabIndex = 6;
            this.txt_QTY.TextChanged += new System.EventHandler(this.txt_QTY_TextChanged);
            this.txt_QTY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_QTY_KeyPress);
            // 
            // btn_Increase
            // 
            this.btn_Increase.BackColor = System.Drawing.Color.White;
            this.btn_Increase.BorderRadius = 8;
            this.btn_Increase.CustomBorderThickness = new System.Windows.Forms.Padding(2, 2, 2, 0);
            this.btn_Increase.CustomizableEdges.BottomLeft = false;
            this.btn_Increase.CustomizableEdges.TopLeft = false;
            this.btn_Increase.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Increase.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Increase.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Increase.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Increase.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Increase.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Increase.ForeColor = System.Drawing.Color.White;
            this.btn_Increase.Image = global::WarungMadura.Properties.Resources.add;
            this.btn_Increase.ImageSize = new System.Drawing.Size(10, 10);
            this.btn_Increase.Location = new System.Drawing.Point(381, 20);
            this.btn_Increase.Name = "btn_Increase";
            this.btn_Increase.Size = new System.Drawing.Size(40, 36);
            this.btn_Increase.TabIndex = 7;
            this.btn_Increase.Click += new System.EventHandler(this.btn_Increase_Click);
            // 
            // btn_Decrease
            // 
            this.btn_Decrease.BackColor = System.Drawing.Color.White;
            this.btn_Decrease.BorderRadius = 8;
            this.btn_Decrease.CustomizableEdges.BottomRight = false;
            this.btn_Decrease.CustomizableEdges.TopRight = false;
            this.btn_Decrease.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Decrease.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Decrease.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Decrease.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Decrease.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.btn_Decrease.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Decrease.ForeColor = System.Drawing.Color.White;
            this.btn_Decrease.Image = global::WarungMadura.Properties.Resources.min;
            this.btn_Decrease.ImageSize = new System.Drawing.Size(13, 13);
            this.btn_Decrease.Location = new System.Drawing.Point(294, 20);
            this.btn_Decrease.Name = "btn_Decrease";
            this.btn_Decrease.Size = new System.Drawing.Size(40, 36);
            this.btn_Decrease.TabIndex = 8;
            this.btn_Decrease.Click += new System.EventHandler(this.btn_Decrease_Click);
            // 
            // l_StartPrice
            // 
            this.l_StartPrice.AutoSize = true;
            this.l_StartPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Strikeout))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_StartPrice.Location = new System.Drawing.Point(206, 49);
            this.l_StartPrice.Name = "l_StartPrice";
            this.l_StartPrice.Size = new System.Drawing.Size(70, 13);
            this.l_StartPrice.TabIndex = 9;
            this.l_StartPrice.Text = "Rp. 10,000";
            this.l_StartPrice.TextChanged += new System.EventHandler(this.txt_Currency_Label);
            // 
            // UC_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.l_StartPrice);
            this.Controls.Add(this.txt_QTY);
            this.Controls.Add(this.btn_Decrease);
            this.Controls.Add(this.btn_Increase);
            this.Controls.Add(this.L_Price);
            this.Controls.Add(this.L_PName);
            this.Controls.Add(this.guna2Shapes3);
            this.Controls.Add(this.guna2Shapes1);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.guna2Shapes2);
            this.Name = "UC_Transaction";
            this.Size = new System.Drawing.Size(444, 85);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ImageButton btn_Delete;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes2;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes3;
        private System.Windows.Forms.Label L_PName;
        private System.Windows.Forms.Label L_Price;
        private Guna.UI2.WinForms.Guna2Button btn_Increase;
        private Guna.UI2.WinForms.Guna2Button btn_Decrease;
        private System.Windows.Forms.Label l_StartPrice;
        public Guna.UI2.WinForms.Guna2TextBox txt_QTY;
    }
}

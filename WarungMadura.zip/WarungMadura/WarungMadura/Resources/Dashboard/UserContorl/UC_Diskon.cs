﻿using CustomMessageBox;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Diskon : UserControl {
        string connectionString = Properties.Resources.ConnectionString;
        string NameDiscount, desc, startDate, endDate, categori;
        int id_diskon, percentage, status;
        decimal rule;

        public event EventHandler<DiskonEventArgs> InfoButton;
        public event EventHandler<DiskonEventArgs> EditButton;
        public event EventHandler<DiskonEventArgsD> DeleteButton;

        public UC_Diskon(int id, int categori,string Ncategori, string name, string desc, string startDate, string endDate, int percentage, int status, Decimal rule) {
            InitializeComponent();
            id_diskon = id;
            this.categori = Ncategori;
            NameDiscount = name;
            this.desc = desc;
            this.startDate = startDate;
            this.endDate = endDate;
            this.rule = rule;
            this.status = status;
            this.percentage = percentage;

            L_PName.Text = NameDiscount;

            L_ID.Text = "DSC" + id_diskon.ToString().PadLeft(3, '0');
            if (Ncategori.Length > 15) {
                L_Royalty.Text = Ncategori.Substring(0, 15) + "...";
            } else {
                L_Royalty.Text = this.categori;
            }
            if (NameDiscount.Length > 15) {
                L_PName.Text = NameDiscount.Substring(0, 15) + "...";
            } else {
                L_PName.Text = this.NameDiscount;
            }

            // Menonaktifkan tombol hapus jika Status == 0
            if (status == 0) {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }


        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new DiskonEventArgs(id_diskon, categori, NameDiscount, desc, startDate, endDate, percentage, status, rule));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new DiskonEventArgsD(id_diskon, NameDiscount));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new DiskonEventArgs(id_diskon, categori, NameDiscount, desc, startDate, endDate, percentage, status, rule));
        }

        public UC_Diskon() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class DiskonEventArgsD : EventArgs {
        public int id_diskon { get; }
        public string Nama { get; }

        public DiskonEventArgsD(int id, string nama) {
            id_diskon = id;
            Nama = nama;
        }
    }
    public class DiskonEventArgs : EventArgs {
        public int id_diskon { get; }
        public string Categories { get; }
        public string Nama { get; }
        public string desc { get; }
        public string startDate { get; }
        public string endDate { get; }
        public int rule { get; }
        public int Status { get; }
        public decimal Percentage { get; }

        public DiskonEventArgs(int id, string categori, string name, string desc, string startDate, string endDate, int rule, int status, decimal percentage) {
            id_diskon = id;
            Categories = categori;
            Nama = name;
            this.desc = desc;
            this.startDate = startDate;
            this.endDate = endDate;
            this.rule = rule;
            Percentage = percentage;
            Status = status;
        }
    }
}

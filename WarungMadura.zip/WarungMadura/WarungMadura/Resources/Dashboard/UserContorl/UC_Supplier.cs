﻿using CustomMessageBox;
using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Supplier : UserControl {
        string NamaSupplier, Alamat,NoTelp,Email;
        int id_Supplier, status;

        public event EventHandler<SupplierEventArgs> InfoButton;
        public event EventHandler<SupplierEventArgs> EditButton;
        public event EventHandler<SupplierEventArgsD> DeleteButton;

        public UC_Supplier(int id, string Nama, string alamat,string noTelp,string email, int Status)
        {
            InitializeComponent();
            id_Supplier = id;
            NamaSupplier = Nama;
            Alamat = alamat;
            status = Status;
            NoTelp = noTelp;
            Email = email;
            L_PName.Text = Nama;

            L_ID.Text = "SPR" + id.ToString().PadLeft(3, '0');

            // Menonaktifkan tombol hapus jika Status == 0
            if (Status == 0)
            {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new SupplierEventArgs(id_Supplier, NamaSupplier, status, Alamat, NoTelp, Email));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new SupplierEventArgsD(id_Supplier, NamaSupplier));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new SupplierEventArgs(id_Supplier, NamaSupplier, status, Alamat, NoTelp, Email));
        }

        public UC_Supplier() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class SupplierEventArgsD : EventArgs {
        public int id_Supplier { get; }
        public string NamaSupplier { get; }

        public SupplierEventArgsD(int id, string namaSupplier) {
            id_Supplier = id;
            NamaSupplier = namaSupplier;
        }
    }
    public class SupplierEventArgs : EventArgs {
        public int id_Supplier { get; }
        public string NamaSupplier { get; }
        public int Status { get; }
        public string Alamat { get; }
        public string NoTelp { get; }
        public string Email { get; }

        public SupplierEventArgs(int id,string namaSupplier, int status, string alamat,string noTelp, string email)
        {
            id_Supplier = id;
            NamaSupplier = namaSupplier;
            Status = status;
            Alamat = alamat;
            NoTelp = noTelp;
            Email = email;
        }
    }
}

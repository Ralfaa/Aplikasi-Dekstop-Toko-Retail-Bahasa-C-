﻿namespace WarungMadura.Resources.Dashboard.UserContorl
{
    partial class UC_Karyawan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_ID = new System.Windows.Forms.Label();
            this.L_EName = new System.Windows.Forms.Label();
            this.uc_Panel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.btn_Edit = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Delete = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Info = new Guna.UI2.WinForms.Guna2Button();
            this.L_Position = new System.Windows.Forms.Label();
            this.uc_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // L_ID
            // 
            this.L_ID.AutoSize = true;
            this.L_ID.BackColor = System.Drawing.Color.White;
            this.L_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_ID.ForeColor = System.Drawing.Color.Black;
            this.L_ID.Location = new System.Drawing.Point(28, 8);
            this.L_ID.Name = "L_ID";
            this.L_ID.Size = new System.Drawing.Size(123, 25);
            this.L_ID.TabIndex = 0;
            this.L_ID.Text = "Employee ID";
            // 
            // L_EName
            // 
            this.L_EName.AutoSize = true;
            this.L_EName.BackColor = System.Drawing.Color.White;
            this.L_EName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_EName.ForeColor = System.Drawing.Color.Black;
            this.L_EName.Location = new System.Drawing.Point(190, 8);
            this.L_EName.Name = "L_EName";
            this.L_EName.Size = new System.Drawing.Size(156, 25);
            this.L_EName.TabIndex = 1;
            this.L_EName.Text = "Employee NameDiscount";
            // 
            // uc_Panel
            // 
            this.uc_Panel.BorderRadius = 6;
            this.uc_Panel.Controls.Add(this.btn_Edit);
            this.uc_Panel.Controls.Add(this.btn_Delete);
            this.uc_Panel.Controls.Add(this.btn_Info);
            this.uc_Panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uc_Panel.Location = new System.Drawing.Point(0, 0);
            this.uc_Panel.Name = "uc_Panel";
            this.uc_Panel.Size = new System.Drawing.Size(1030, 41);
            this.uc_Panel.TabIndex = 3;
            // 
            // btn_Edit
            // 
            this.btn_Edit.BackColor = System.Drawing.Color.White;
            this.btn_Edit.BorderRadius = 6;
            this.btn_Edit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Edit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Edit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Edit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Edit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Edit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Edit.ForeColor = System.Drawing.Color.White;
            this.btn_Edit.Image = global::WarungMadura.Properties.Resources.edit;
            this.btn_Edit.ImageOffset = new System.Drawing.Point(2, 0);
            this.btn_Edit.Location = new System.Drawing.Point(954, 4);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(50, 33);
            this.btn_Edit.TabIndex = 8;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.BackColor = System.Drawing.Color.White;
            this.btn_Delete.BorderRadius = 6;
            this.btn_Delete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Delete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Delete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Delete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Delete.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Delete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Delete.ForeColor = System.Drawing.Color.White;
            this.btn_Delete.Image = global::WarungMadura.Properties.Resources.trash;
            this.btn_Delete.ImageOffset = new System.Drawing.Point(1, 0);
            this.btn_Delete.Location = new System.Drawing.Point(876, 4);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(50, 33);
            this.btn_Delete.TabIndex = 7;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Info
            // 
            this.btn_Info.BackColor = System.Drawing.Color.White;
            this.btn_Info.BorderRadius = 6;
            this.btn_Info.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Info.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Info.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Info.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Info.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Info.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Info.ForeColor = System.Drawing.Color.White;
            this.btn_Info.Image = global::WarungMadura.Properties.Resources.Infromation;
            this.btn_Info.ImageOffset = new System.Drawing.Point(1, 0);
            this.btn_Info.Location = new System.Drawing.Point(798, 4);
            this.btn_Info.Name = "btn_Info";
            this.btn_Info.Size = new System.Drawing.Size(50, 33);
            this.btn_Info.TabIndex = 6;
            this.btn_Info.Click += new System.EventHandler(this.btn_Info_Click);
            // 
            // L_Position
            // 
            this.L_Position.AutoSize = true;
            this.L_Position.BackColor = System.Drawing.Color.White;
            this.L_Position.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Position.ForeColor = System.Drawing.Color.Black;
            this.L_Position.Location = new System.Drawing.Point(437, 8);
            this.L_Position.Name = "L_Position";
            this.L_Position.Size = new System.Drawing.Size(81, 25);
            this.L_Position.TabIndex = 4;
            this.L_Position.Text = "Position";
            // 
            // UC_Karyawan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.L_Position);
            this.Controls.Add(this.L_EName);
            this.Controls.Add(this.L_ID);
            this.Controls.Add(this.uc_Panel);
            this.Name = "UC_Karyawan";
            this.Size = new System.Drawing.Size(1030, 41);
            this.Load += new System.EventHandler(this.UC_Produk_Load);
            this.uc_Panel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_ID;
        private System.Windows.Forms.Label L_EName;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel uc_Panel;
        private Guna.UI2.WinForms.Guna2Button btn_Info;
        private Guna.UI2.WinForms.Guna2Button btn_Edit;
        private Guna.UI2.WinForms.Guna2Button btn_Delete;
        private System.Windows.Forms.Label L_Position;
    }
}

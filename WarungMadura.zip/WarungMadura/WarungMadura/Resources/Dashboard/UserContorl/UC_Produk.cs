﻿    using CustomMessageBox;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Produk : UserControl {
        string NamaProduct,Unit, name_CProduct, name_Supplier;
        int id_Product,id_CProduct,id_Supplier,stock,discount;
        decimal sell, buy;
        byte[] Picture;

        public event EventHandler<ProductEventArgs> InfoButton;
        public event EventHandler<ProductEventArgs> EditButton;
        public event EventHandler<ProductEventArgsD> DeleteButton;

        public UC_Produk(int id, string PName, int idCProduct,string Name_CProduct, int idSupplier,string Name_Supplier, int stock, string unit, int discount, decimal sell, decimal buy, byte[] picture,int Status) {
            InitializeComponent();
            id_Product = id;
            NamaProduct = PName;
            if (PName.Length > 15) {
                L_PName.Text = PName.Substring(0, 15) + "...";
            } else {
                L_PName.Text = PName;
            }
            id_CProduct = idCProduct;
            id_Supplier = idSupplier;
            name_CProduct = Name_CProduct;
            name_Supplier = Name_Supplier;
            l_Categories.Text = Name_CProduct;
            l_Supplier.Text = Name_Supplier;
            this.stock = stock;
            this.Unit = unit;
            this.discount = discount;
            this.sell = sell;
            this.buy = buy;
            this.Picture = picture;
            if (Status.Equals(0)) {
                btn_Delete.Enabled = false;
                btn_Edit.Image = Properties.Resources.restore;
            }
            L_ID.Text = "PDCT" + id.ToString().PadLeft(3, '0');
        }
        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new ProductEventArgs(id_Product, NamaProduct, Unit, id_CProduct, name_CProduct, id_Supplier, name_Supplier, stock, discount, sell, buy, Picture));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new ProductEventArgsD(id_Product, NamaProduct));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new ProductEventArgs(id_Product,NamaProduct, Unit, id_CProduct, name_CProduct, id_Supplier, name_Supplier, stock, discount, sell, buy, Picture));
        }

        public UC_Produk() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class ProductEventArgsD : EventArgs {
        public int id_Product { get; }
        public string NamaProduct { get; }

        public ProductEventArgsD(int id, string namaProduct) {
            id_Product = id;
            NamaProduct = namaProduct;
        }
    }
    public class ProductEventArgs : EventArgs {
        public int id_Product { get; }
        public string NamaProduct { get; }
        public string Unit { get; }
        public int Id_CProduct { get; }
        public string nama_CProduct { get; }
        public int Id_Supplier { get; }
        public string nama_Supplier { get; }
        public int Stock { get; }
        public int Discount { get; }
        public decimal Sell { get; }
        public decimal Buy { get; }
        public byte[] Picture { get; }

        public ProductEventArgs(int id,string namaProduct, string satuan, int id_CProduct, string Nama_CProduct, int id_Supplier, string Nama_Supplier, int stock, int discount, decimal sell, decimal buy, byte[] picture) {
            id_Product = id;
            NamaProduct = namaProduct;
            Unit = satuan;
            nama_CProduct = Nama_CProduct;
            Id_CProduct = id_CProduct;
            Id_Supplier = id_Supplier;
            nama_Supplier = Nama_Supplier;
            Stock = stock;
            Discount = discount;
            Sell = sell;
            Buy = buy;
            Picture = picture;
        }
    }
}

﻿using CustomMessageBox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Transaction : UserControl {
        public int id,discount,stock,Transaction_Qty,limit;
        public decimal TotalPrice,StartPrice;
        public event EventHandler ClickRefresh;
        public UC_Transaction(int id,string ProductName,decimal StartPrice,int stock = 0,int discount = 0) {
            InitializeComponent();
            this.id = id;
            this.StartPrice = StartPrice;
            if(ProductName.Length > 15) {
                L_PName.Text = ProductName.Substring(0,15)+"...";
            } else {
                L_PName.Text = ProductName;
            }
            
            this.discount = discount;
            if (discount > 0) {
                l_StartPrice.Text = StartPrice.ToString("F0");
                decimal buffer = StartPrice - (StartPrice * discount / 100);
                L_Price.Text = buffer.ToString("F0");
                TotalPrice = buffer;
                limit = stock;
            } else {
                l_StartPrice.Visible = false;
                L_Price.Text = StartPrice.ToString("F0");
                TotalPrice = StartPrice;
                if(stock > 0) {
                    limit = stock;
                } else {
                    limit = 0;
                }
            }
            Transaction_Qty = 1;
            txt_QTY.Text = "1";
        }

        private void txt_QTY_TextChanged(object sender, EventArgs e) {
            if(txt_QTY.Text == string.Empty) {
                Transaction_Qty = 1;
                txt_QTY.Text = Transaction_Qty.ToString();
                return; 
            }
            if(Convert.ToInt64(txt_QTY.Text) > limit && limit > 0) {
                txt_QTY.Text = limit.ToString();
                Transaction_Qty = limit;
            } else {
                Transaction_Qty = (int)Convert.ToInt64(txt_QTY.Text);
            }
            TotalPrice = Decimal.Parse(L_Price.Text.Replace("Rp", "").Replace(".", "")) * Transaction_Qty;
        }

        private void btn_Decrease_Click(object sender, EventArgs e) {
            if(Transaction_Qty > 1) {
                Transaction_Qty -= 1;
                txt_QTY.Text = Transaction_Qty.ToString();
            } else {
                Transaction_Qty = 1;
                txt_QTY.Text = Transaction_Qty.ToString();
            }
            ClickRefresh.Invoke(this, e);
        }

        private void btn_Increase_Click(object sender, EventArgs e) {
                Transaction_Qty += 1;
                txt_QTY.Text = Transaction_Qty.ToString();

            ClickRefresh.Invoke(this, e);
        }

        private void test() {
            this.Dispose();
        }
        
        private void btn_Delete_Click(object sender, EventArgs e) {
            this.Dispose(true);
        }

        private void txt_QTY_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == '\r') {
                ClickRefresh.Invoke(this, e);
                return;
            }
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void guna2Shapes2_Click(object sender, EventArgs e) {

        }
        private void txt_Currency_Label(object sender, EventArgs e) {
            Label guna2Text = (Label)sender;
            string buffer = guna2Text.Text.Replace("Rp", "").Trim();
            buffer = buffer.Replace(".", "");
            decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result);
            string formattedBuffer = result.ToString("#,##0", CultureInfo.InvariantCulture).Replace(",", ".");
            guna2Text.Text = "Rp " + formattedBuffer;
        }
    }
}

﻿using CustomMessageBox;
using System;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard.UserContorl {
    public partial class UC_Jabatan : UserControl {
        string NamaPostion, hakAkses;
        int id_Postion, status;

        public event EventHandler<PositionEventArgs> InfoButton;
        public event EventHandler<PositionEventArgs> EditButton;
        public event EventHandler<PositionEventArgsD> DeleteButton;

        public UC_Jabatan(int id, string KJName, int Status, string HakAkses)
        {
            InitializeComponent();
            id_Postion = id;
            NamaPostion = KJName;
            hakAkses = HakAkses;
            status = Status;

            L_PName.Text = KJName;

            L_ID.Text = "PS" + id.ToString().PadLeft(3, '0');
            L_Permission.Text = HakAkses;

            // Menonaktifkan tombol hapus jika Status == 0
            if (Status == 0)
            {
                btn_Edit.Image = Properties.Resources.restore;
                btn_Delete.Enabled = false;
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e) {
            EditButton?.Invoke(this, new PositionEventArgs(id_Postion, NamaPostion, status, hakAkses));
        }

        private void btn_Delete_Click(object sender, EventArgs e) {
            DeleteButton?.Invoke(this, new PositionEventArgsD(id_Postion, NamaPostion));
        }

        private void btn_Info_Click(object sender, EventArgs e) {

            InfoButton?.Invoke(this, new PositionEventArgs(id_Postion, NamaPostion, status, hakAkses));
        }

        public UC_Jabatan() {
            InitializeComponent();
        }
        private void UC_Produk_Load(object sender, EventArgs e) {

        }
    }
    public class PositionEventArgsD : EventArgs {
        public int id_Position { get; }
        public string NamaPosition { get; }

        public PositionEventArgsD(int id, string namaPosition) {
            id_Position = id;
            NamaPosition = namaPosition;
        }
    }
    public class PositionEventArgs : EventArgs {
        public int id_Position { get; }
        public string NamaPosition { get; }
        public int Status { get; }
        public string HakAkses { get; }

        public PositionEventArgs(int id,string namaPosition, int status, string hakAkses)
        {
            id_Position = id;
            NamaPosition = namaPosition;
            Status = status;
            HakAkses = hakAkses;
        }
    }
}

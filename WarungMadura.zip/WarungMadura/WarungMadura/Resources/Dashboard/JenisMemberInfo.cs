﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class JenisMemberInfo : Form {
        public JenisMemberInfo() {
            InitializeComponent();
        }
        private void ProductInfo_Load(object sender, EventArgs e) {
        }

        public JenisMemberInfo(int id, string KJName, int MinPoint) {
            InitializeComponent();

            txt_IdJenisMember.Text = "TL" + id.ToString().PadLeft(3, '0');

            txt_LoyaltyName.Text = KJName;
            txt_MinPoint.Text = MinPoint.ToString();
        }


        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void bnt_Exit_Click(object sender, EventArgs e) {
            timer_Closing.Start();
        }
    }
}

﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarungMadura.Resources.Dashboard {
    public partial class ProductInfo : Form {
        public ProductInfo() {
            InitializeComponent();
        }
        private void ProductInfo_Load(object sender, EventArgs e) {
        }

        public ProductInfo(int id, string PName, string idCProduct, string idSupplier, int stock, string unit, int discount, decimal sell, decimal buy, byte[] picture) {
            InitializeComponent();
            txt_IdProduct.Text = "PDCT" + id.ToString().PadLeft(3, '0');
            txt_ProductName.Text = PName;
            txt_Categories.Text = idCProduct;
            txt_Supplier.Text = idSupplier;
            txt_Stock.Text = stock.ToString();
            txt_Unit.Text = unit;
            txt_Discount.Text = discount.ToString();
            txt_Sell.Text = sell.ToString("F0");
            txt_Buy.Text = buy.ToString("F0");

            if (picture != null && picture.Length > 0) {
                using (var ms = new System.IO.MemoryStream(picture)) {
                    p_Product.Image = Image.FromStream(ms);
                }
            } else {
                p_Product.Image = null;
            }
        }

        private void label7_Click(object sender, EventArgs e) {

        }

        private void guna2TextBox7_TextChanged(object sender, EventArgs e) {

        }

        private void timer_Opening_Tick(object sender, EventArgs e) {
            if(this.Opacity >= 1) {
                timer_Opening.Stop();
            } else {
                this.Opacity += 0.15;
            }
        }

        private void timer_Closing_Tick(object sender, EventArgs e) {
            if (this.Opacity == 0) {
                timer_Closing.Stop();
                this.Close();
            } else {
                this.Opacity -= 0.15;
            }
        }

        private void bnt_Exit_Click(object sender, EventArgs e) {
            timer_Closing.Start();
        }
        private void txt_Currency_TextChanged(object sender, EventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;

            if (guna2Text.Text.Any(char.IsDigit)) {
                int caretPosition = guna2Text.SelectionStart;
                string buffer = guna2Text.Text.Replace("Rp", "").Trim();
                buffer = buffer.Replace(".", "");

                if (decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result)) {
                    string formattedBuffer = result.ToString("#,##", CultureInfo.InvariantCulture).Replace(",", ".");
                    guna2Text.Text = "Rp " + formattedBuffer;
                    guna2Text.SelectionStart = formattedBuffer.Length + 3;
                }
            } else {
                guna2Text.Clear();
            }
        }
    }
}

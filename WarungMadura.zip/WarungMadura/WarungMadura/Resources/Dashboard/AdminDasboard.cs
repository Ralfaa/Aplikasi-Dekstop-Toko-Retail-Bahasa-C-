﻿using CustomMessageBox;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard
{
    public partial class AdminDasboard : Form
    {
        string connectionString = Properties.Resources.ConnectionString;

        public AdminDasboard()
        {
            InitializeComponent();
        }
        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            loadData();
        }
        private void loadData() {

            txtInStock.Text = GetCountFromFunction("CountStatus1Produk").ToString() + " Product";
            txtlowStock.Text = GetCountFromFunction("CountStatus2Produk").ToString() + " Product";
            txtCriticalStock.Text = GetCountFromFunction("CountStatus3Produk").ToString() + " Product";
            txtoutStock.Text = GetCountFromFunction("CountStatus4Produk").ToString() + " Product";
            txtProductList.Text = GetCountFromFunction("CountTotalProduk").ToString() + " Product";
            txtSellProduct.Text = GetCountFromFunction("TotalQtyPenjualan").ToString() + " Product";

            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "SELECT * FROM ProdukInfo"; 
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dgv_Produk.DataSource = dataTable;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void CustomizeColumn(string columnName) {
            if (dgv_Produk.Columns.Contains(columnName)) {
                DataGridViewColumn column = dgv_Produk.Columns[columnName];

                // Set header style
                column.HeaderCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);
                column.HeaderCell.Style.ForeColor = Color.White;
                column.HeaderCell.Style.BackColor = Color.DarkBlue;

                // Set cell style
                column.DefaultCellStyle.BackColor = Color.LightBlue;
                column.DefaultCellStyle.ForeColor = Color.DarkBlue;
                column.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Italic);
            }
        }
        private int GetCountFromFunction(string functionName) {
            int count = 0;

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                SqlCommand command = new SqlCommand(functionName, connection);
                command.CommandType = CommandType.StoredProcedure; // Assuming these are stored procedures

                try {
                    connection.Open();
                    SqlParameter returnParameter = command.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;

                    command.ExecuteNonQuery();
                    count = (int)returnParameter.Value;
                } catch (Exception ex) {
                    MessageBox.Show("Error retrieving count: " + ex.Message);
                }
            }

            return count;
        }
    }
}

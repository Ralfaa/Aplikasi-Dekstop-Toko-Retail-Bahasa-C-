﻿using CustomMessageBox;
using ReportPembelianWarung;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class SalesReport : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;
        bool alldata = true;
        private int idUser;
        private DataTable dataOrders = new DataTable();
        public SalesReport(int id) {
            idUser = id;
            InitializeComponent();
            btn_DetailOrders.Enabled = false;
            btn_clear.Enabled = false;
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            DTM_Start.Value = DateTime.Now;
            DTM_End.Value = DateTime.Now;
            LoadData();
        }

        private void LoadData() {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();
                    string query = "SELECT 'SNT' + RIGHT('00000' + CAST(id_transaksi AS VARCHAR), 5) AS 'ID Orders',"+
                                   " TanggalTransaksi, nama_pelanggan, nama_karyawan, nama_promo,'Rp. ' + CONCAT(FORMAT(TotalHarga, 'N0'), '') AS TotalHarga "+
                                   " from FnGetSaleReport(null, null)";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    dataOrders.Load(reader);
                    dgv_SalesReport.DataSource = dataOrders;
                    dgv_SalesReport.Columns[1].HeaderText = "Date";
                    dgv_SalesReport.Columns[3].HeaderText = "Cashier";
                    dgv_SalesReport.Columns[5].HeaderText = "Total Price";
                    dgv_SalesReport.Columns[2].Visible = false;
                    dgv_SalesReport.Columns[4].Visible = false;
                    alldata = true;
                }
            } catch (Exception ex) {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        public void clear() {
            txt_Orders.Clear();
            txt_DateOrders.Clear();
            txt_CashierOrders.Clear();
            txt_DiscountOrders.Clear();
            txt_MemberOrders.Clear();
            txt_PriceOrders.Clear();
            dgv_SalesReport.ClearSelection();
            btn_DetailOrders.Enabled = false;
            btn_clear.Enabled = false;
        }

        private void btn_clear_Click_1(object sender, EventArgs e) {
            clear();
        }

        private void dgv_SalesReport_CellClick(object sender, DataGridViewCellEventArgs e) {
            int Srow = dgv_SalesReport.SelectedCells[0].RowIndex;
            txt_Orders.Text = dgv_SalesReport.Rows[Srow].Cells[0].Value.ToString();
            DateTime dateValue = (DateTime)dgv_SalesReport.Rows[Srow].Cells[1].Value;
            txt_DateOrders.Text = dateValue.ToString("yyyy-MM-dd");
            txt_MemberOrders.Text = dgv_SalesReport.Rows[Srow].Cells[2].Value.ToString();
            txt_CashierOrders.Text = dgv_SalesReport.Rows[Srow].Cells[3].Value.ToString();
            txt_DiscountOrders.Text = dgv_SalesReport.Rows[Srow].Cells[4].Value.ToString();
            txt_PriceOrders.Text =  dgv_SalesReport.Rows[Srow].Cells[5].Value.ToString();
            btn_DetailOrders.Enabled = true;
            btn_clear.Enabled = true;
        }

        private void btn_Apply_Click(object sender, EventArgs e) {
            dataOrders.Clear();

            // Set the start date time to 00:00:00
            DateTime startDate = new DateTime(DTM_Start.Value.Year, DTM_Start.Value.Month, DTM_Start.Value.Day, 0, 0, 0);

            // Set the end date time to 23:59:00
            DateTime endDate = new DateTime(DTM_End.Value.Year, DTM_End.Value.Month, DTM_End.Value.Day, 23, 59, 0);

            if (endDate >= startDate) {
                try {
                    DateTime Start = (DateTime)startDate;
                    DateTime End = (DateTime)endDate;
                    using (SqlConnection connection = new SqlConnection(connectionString)) {
                        connection.Open();
                        string query = "SELECT 'SNT' + RIGHT('00000' + CAST(id_transaksi AS VARCHAR), 5) AS 'ID Orders'," +
                                       " TanggalTransaksi, nama_pelanggan, nama_karyawan, nama_promo, CONCAT(FORMAT(TotalHarga, 'F0'), '') AS TotalHarga " +
                                       $" from FnGetSaleReport('{Start.ToString("yyyy-MM-dd")}', '{End.AddDays(1).ToString("yyyy-MM-dd")}')";
                        SqlCommand command = new SqlCommand(query, connection);
                        SqlDataReader reader = command.ExecuteReader();

                        dataOrders.Load(reader);
                        dgv_SalesReport.DataSource = dataOrders;
                        dgv_SalesReport.Columns[1].HeaderText = "Date";
                        dgv_SalesReport.Columns[3].HeaderText = "Cashier";
                        dgv_SalesReport.Columns[5].HeaderText = "Total Price";
                        dgv_SalesReport.Columns[2].Visible = false;
                        dgv_SalesReport.Columns[4].Visible = false;
                        alldata = false;

                    }
                } catch (Exception ex) {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            } else {
                LoadData();
                toastNotification = new Notification("Warning", "Invalid Date");
                toastNotification.Show();
            }
            if (dgv_SalesReport.Rows.Count > 0) {
                btn_Print.Enabled = true;
            } else {
                toastNotification = new Notification("Warning", "No Data Found");
                toastNotification.Show();
                btn_Print.Enabled=false;
            }
        }

        private void btn_ResetDay_Click(object sender, EventArgs e) {
            DTM_Start.Value = DateTime.Now;
            DTM_End.Value = DateTime.Now;
            btn_Print.Enabled = true;
            dataOrders.Clear(); 
            LoadData();
        }

        private void btn_Print_Click(object sender, EventArgs e) {
            if (alldata) {
                Form formBackground = new Form();
                using (ReportSales SalesReport = new ReportSales()) {
                    formBackground.StartPosition = FormStartPosition.CenterScreen;
                    formBackground.FormBorderStyle = FormBorderStyle.None;
                    formBackground.Opacity = 0.50d;
                    formBackground.Size = new Size(1920, 1080);
                    formBackground.Location = this.Location;
                    formBackground.ShowInTaskbar = false;
                    formBackground.Show();


                    SalesReport.StartPosition = FormStartPosition.CenterScreen;
                    //SalesReport.FormBorderStyle = FormBorderStyle.None;
                    SalesReport.Owner = formBackground;
                    SalesReport.ShowDialog();

                    formBackground.Dispose();
                }
            } else {
                Form formBackground = new Form();

                // Set the start date time to 00:00:00
                DateTime startDate = new DateTime(DTM_Start.Value.Year, DTM_Start.Value.Month, DTM_Start.Value.Day, 0, 0, 0);

                // Set the end date time to 23:59:00
                DateTime endDate = new DateTime(DTM_End.Value.Year, DTM_End.Value.Month, DTM_End.Value.Day, 23, 59, 0);
/*                RJMessageBox.Show(startDate.ToString()+"  "+ endDate.ToString());*/
                using (ReportSales SalesReport = new ReportSales(startDate,endDate)) {
                    formBackground.StartPosition = FormStartPosition.CenterScreen;
                    formBackground.FormBorderStyle = FormBorderStyle.None;
                    formBackground.Opacity = 0.50d;
                    formBackground.Size = new Size(1920, 1080);
                    formBackground.Location = this.Location;
                    formBackground.ShowInTaskbar = false;
                    formBackground.Show();


                    SalesReport.StartPosition = FormStartPosition.CenterScreen;
                    //SalesReport.FormBorderStyle = FormBorderStyle.None;
                    SalesReport.Owner = formBackground;
                    SalesReport.ShowDialog();

                    formBackground.Dispose();
                }
            }
        }

        private void btn_DetailOrders_Click(object sender, EventArgs e) {
            Form formBackground = new Form();
            using (HistorySale memberInfo = new HistorySale(Convert.ToInt32(txt_Orders.Text.Substring(3)))) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();


                memberInfo.StartPosition = FormStartPosition.CenterScreen;
                memberInfo.FormBorderStyle = FormBorderStyle.None;
                memberInfo.Owner = formBackground;
                memberInfo.ShowDialog();

                formBackground.Dispose();
            }
            clear();
        }
    }
}

﻿using CustomMessageBox;
using Guna.UI2.WinForms;
using Microsoft.Reporting.WinForms;
using ReportPembelianWarung;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ToastNotifications;
using WarungMadura.Resources.Dashboard.UserContorl;

namespace WarungMadura.Resources.Dashboard {
    public partial class Sell : Form {
        private Notification toastNotification;
        string connectionString = Properties.Resources.ConnectionString;
        private string selectedCategory = null;
        private int IDEmployee = 0;
        public Sell(int id) {
            InitializeComponent();
            IDEmployee = id;
        }

        private void Produk_EnabledChanged(object sender, EventArgs e) {
            autoId();
            LoadData();
        }
        private void Produk_Load(object sender, EventArgs e) {
            btn_BUY.Enabled = false;
        }
        private void autoId() {
            try {
                string query = "SELECT TOP 1 id_transaksi_penjualan FROM TransaksiPenjualan ORDER BY id_transaksi_penjualan DESC";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        String addID = "SNT00001"; // Default ID jika tidak ada data dalam tabel

                        if (dt.Rows.Count > 0) {
                            int lastID = Convert.ToInt32(dt.Rows[0]["id_transaksi_penjualan"]);
                            int newID = lastID + 1;

                            addID = "SNT" + newID.ToString().PadLeft(5, '0');
                        }
                        l_ID.Text = l_ID.Text.Substring(0, 5) + addID;
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show("Error : " + ex.Message);
            }
        }



        public void LoadData() {
            selectedCategory = null;
            flp_Jabatan.Controls.Clear();
            string query = $"select * from FnSearchProduk(null,null,null,null)";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                    string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                    string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                    int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                    int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                    decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                    decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                    string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }

                                    UC_TSProduk buffer = new UC_TSProduk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                    buffer.ADDButton += UserControl_ADD;
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Product Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UserControl_ADD(object sender, ProductEventArgs e) {
            bool found = false;
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    if(userControl.id == e.id_Product) {
                        userControl.Transaction_Qty = userControl.Transaction_Qty + 1;
                        userControl.txt_QTY.Text = userControl.Transaction_Qty.ToString();
                        found = true;
                        refresh(null,null);
                    }
                }
            }
            if (!found) {
                UC_Transaction uC_Transaction = new UC_Transaction(e.id_Product, e.NamaProduct, e.Sell,e.Stock,e.Discount);
                uC_Transaction.ClickRefresh += refresh;
                flp_BUY.Controls.Add(uC_Transaction);
            }
        }

        private void txt_KeyPressNama(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar)) {
                if (e.KeyChar != '\b' && e.KeyChar != ' ') {
                    e.Handled = true;
                }
            }
        }

        private void KeypressNumber(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }
        }

        private void txt_Search_Enter(object sender, EventArgs e) { 
        }

        private void cb_Supplier_SelectedIndexChanged(object sender, EventArgs e) {
        }
        private decimal TotalPrice=0,SubtotalPrice=0;
        private void refresh(object sender, EventArgs e) {
            SubtotalPrice = 0;
            TotalPrice = 0;
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    SubtotalPrice += userControl.TotalPrice;
                }
            }
            txt_Cash.Enabled = SubtotalPrice > 0 ? true : false;
            TotalPrice = SubtotalPrice;
            btn_BUY.Enabled = false;
            L_STotal.Text = SubtotalPrice.ToString("F0");
            L_Total.Text = SubtotalPrice.ToString("F0");
            loadDiskon();
        }
        private void flp_Add_Remove_Items(object sender, ControlEventArgs e) {
            refresh(null, null);    
        }
        private void Label_Currency_TextChanged(object sender, EventArgs e) {
            Label guna2Text = (Label)sender;
            string buffer = guna2Text.Text.Replace("Rp", "").Trim();
            buffer = buffer.Replace(".", "");
            decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result);
            string formattedBuffer = result.ToString("#,##0", CultureInfo.InvariantCulture).Replace(",", ".");
            guna2Text.Text = "Rp " + formattedBuffer;        
        }
        private void txt_Currency_TextChanged(object sender, EventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;
            if (guna2Text.Text.Any(char.IsDigit)) {
                int caretPosition = guna2Text.SelectionStart;
                string buffer = guna2Text.Text.Replace("Rp", "").Trim();
                buffer = buffer.Replace(".", "");

                if (decimal.TryParse(buffer, NumberStyles.Currency, CultureInfo.InvariantCulture, out decimal result)) {
                    string formattedBuffer = result.ToString("#,##", CultureInfo.InvariantCulture).Replace(",", ".");
                    guna2Text.Text = "Rp " + formattedBuffer;
                    guna2Text.SelectionStart = formattedBuffer.Length + 3;
                }
            } else {
                guna2Text.Clear();
            }
        }
        private void Filter() {
            flp_Jabatan.Controls.Clear();
            string query = $"select * from FnSearchProduk(null,'{txt_Search.Text}','{selectedCategory}',null)";
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                    string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                    string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                    int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                    int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                    decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                    decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                    string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }

                                    UC_TSProduk buffer = new UC_TSProduk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                    buffer.ADDButton += UserControl_ADD;
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Product Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void txt_Search_IconRightClick(object sender, EventArgs e) {
            Filter();
        }
        private int generatePoint() {
            if (TotalPrice >= 50000 && TotalPrice <= 100000) {
                return 1;
            } else if (TotalPrice >= 100001 && TotalPrice <= 500000) {
                return 10;
            } else if (TotalPrice >= 500001 && TotalPrice <= 1000000) {
                return 50;
            } else if (TotalPrice > 1000000) {
                return 70;
            } else {
                return 0;
            }
        }
        private void btn_BUY_Click(object sender, EventArgs e) {
            DataTable detailenjualanTable = new DataTable();
            detailenjualanTable.Columns.Add("id_produk", typeof(int));
            detailenjualanTable.Columns.Add("Qty", typeof(int));
            detailenjualanTable.Columns.Add("Harga", typeof(SqlMoney));
            decimal cash = 0, changes = 0;
            foreach (Control control in flp_BUY.Controls) {
                if (control is UC_Transaction userControl) {
                    detailenjualanTable.Rows.Add(userControl.id, userControl.Transaction_Qty, userControl.TotalPrice);
                }
            }
            try {
                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    using (SqlCommand command = new SqlCommand("SpInsertTransaksiPenjualan", connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@id_karyawan", IDEmployee));
                        command.Parameters.Add(new SqlParameter("@id_promo", SelectDiscount == null ? (object)DBNull.Value : SelectDiscount.IdDiscount));
                        command.Parameters.Add(new SqlParameter("@id_pelanggan", IdMember == 0 ? (object)DBNull.Value : IdMember));
                        command.Parameters.Add(new SqlParameter("@TotalHarga", TotalPrice));
                        command.Parameters.Add(new SqlParameter("@DetailPenjualan", SqlDbType.Structured){
                            Value = detailenjualanTable, TypeName = "dbo.DetailPenjualanType"
                        });
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        if (result == 0) {
                            toastNotification = new Notification("Info", "Order Failed");
                        } else {
                            toastNotification = new Notification("Info", "Order Success");
                        }
                        cash = decimal.Parse(txt_Cash.Text.Substring(3));
                        changes = cash - TotalPrice;
                        toastNotification.Show();
                    }
                }
            } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Form formBackground = new Form();
            using (InvoicePenjualan report = new InvoicePenjualan(cash, changes, generatePoint())) {
                formBackground.StartPosition = FormStartPosition.CenterScreen;
                formBackground.FormBorderStyle = FormBorderStyle.None;
                formBackground.Opacity = 0.50d;
                formBackground.Size = new Size(1920, 1080);
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();


                report.StartPosition = FormStartPosition.CenterScreen;
                report.FormBorderStyle = FormBorderStyle.None;
                report.Owner = formBackground;
                report.ShowDialog();

                formBackground.Dispose();
            }
            
            clear();
        }
        private void clear() {
            L_STotal.Text = string.Empty;
            L_Total.Text = string.Empty;
            txt_Cash.Text = string.Empty;
            txt_Chages.Text = string.Empty;
            txt_TelpMember.Text = string.Empty;
            SelectDiscount = null;
            flp_BUY.Controls.Clear();
            cb_Diskon.Items.Clear();
            L_Member.Text = L_Member.Text.Substring(0, 9) + "N/A";
            txt_Chages.PlaceholderText = "Rp.";
            autoId();
            IdJenisMember = 0;
            SubtotalPrice = 0;
            TotalPrice = 0;

        }
        private void flp_Jabatan_Paint(object sender, PaintEventArgs e) {
        }

        private void gpnl_CreateData_Paint(object sender, PaintEventArgs e) {

        }
        private int IdJenisMember = 0;
        private int IdMember = 0;
        private void MemberLoad() {
            refresh(null,null);
            string query = $"SELECT * From GetMemberDetailsByNoTelepon('{txt_TelpMember.Text}')";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {

                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.Read()) {
                                IdMember = reader.GetInt32(1);
                                IdJenisMember = reader.GetInt32(0);
                                L_Member.Text = L_Member.Text.Substring(0, 9) + "MBR" + Convert.ToInt32((int)IdMember).ToString().PadLeft(3, '0');
                            } else {
                                SelectDiscount = null;
                                cb_Diskon.Items.Clear();
                                IdJenisMember = 0;
                                L_Member.Text = L_Member.Text.Substring(0, 9) + "N/A";
                                toastNotification = new Notification("Info", "No Member Found");
                                toastNotification.Show();
                            }
                        }


                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void txt_TelpMember_KeyPress(object sender, KeyPressEventArgs e) {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) {
                e.Handled = true;
            }

            // Memeriksa panjang no telp
            if (txt_TelpMember.Text.Length >= 13 && e.KeyChar != '\b') {
                e.Handled = true;
            }
            if(e.KeyChar == '\r') {
                if(txt_TelpMember.Text == string.Empty) {
                    SelectDiscount = null;
                    cb_Diskon.Items.Clear();
                    IdJenisMember = 0;
                    IdMember = 0;
                    L_Member.Text = L_Member.Text.Substring(0, 9) + "N/A";
                } else {
                    MemberLoad();
                    loadDiskon();
                }
            }
        }
        
        public void ChosData(string data = null) {
            selectedCategory = data;
            flp_Jabatan.Controls.Clear();
            string query = $"select * from FnSearchProduk(null,null,'{data}',null)";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                try {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection)) {
                        using (SqlDataReader reader = command.ExecuteReader()) {
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    int id = reader.GetInt32(reader.GetOrdinal("id_produk"));
                                    string PName = reader.GetString(reader.GetOrdinal("NamaProduk"));
                                    string Satuan = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    int idCProduct = reader.GetInt32(reader.GetOrdinal("id_kategori"));
                                    int idSupplier = reader.GetInt32(reader.GetOrdinal("id_supplier"));
                                    int stock = reader.GetInt32(reader.GetOrdinal("Stock"));
                                    int discount = reader.GetInt32(reader.GetOrdinal("PromoDiskon"));
                                    decimal buy = reader.GetDecimal(reader.GetOrdinal("HargaBeli"));
                                    decimal sell = reader.GetDecimal(reader.GetOrdinal("HargaJual"));
                                    string namaCProduct = reader.GetString(reader.GetOrdinal("NamaKategori"));
                                    string namaSupplier = reader.GetString(reader.GetOrdinal("NamaSupplier"));
                                    int status = reader.GetInt32(reader.GetOrdinal("Status"));

                                    byte[] picture = null;
                                    if (!reader.IsDBNull(reader.GetOrdinal("Picture"))) {
                                        picture = (byte[])reader["Picture"];
                                    }

                                    UC_TSProduk buffer = new UC_TSProduk(id, PName, idCProduct, namaCProduct, idSupplier, namaSupplier, stock, Satuan, discount, sell, buy, picture, status);
                                    buffer.ADDButton += UserControl_ADD;
                                    flp_Jabatan.Controls.Add(buffer);
                                }
                            } else {
                                toastNotification = new Notification("Info", "No Product Found");
                                toastNotification.Show();
                            }
                        }
                    }
                } catch (Exception ex) {
                    RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        DiscountItem SelectDiscount;
        private void loadDiskon() {
            SelectDiscount = null;
            cb_Diskon.Items.Clear();
            txt_Cash.Text = string.Empty;
            if (IdMember != 0 && IdJenisMember != 0 && flp_BUY.Controls.Count > 0) {
                string query = $"select * from GetPromoDiskonByMinPembelianAndMemberId({Decimal.Parse(L_STotal.Text.Replace("Rp", "").Replace(".", ""))},{IdJenisMember})";

                using (SqlConnection connection = new SqlConnection(connectionString)) {
                    try {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            using (SqlDataReader reader = command.ExecuteReader()) {
                                if (reader.HasRows) {
                                    while (reader.Read()) {
                                        int IdDiscount = (int)reader["id_promo"];
                                        string namaPromo = reader["NamaPromo"].ToString();
                                        int persentaseDiskon = (int)reader["Persentase_Diskon"];
                                        DiscountItem discountItem = new DiscountItem(IdDiscount,namaPromo, persentaseDiskon);
                                        cb_Diskon.Items.Add(discountItem);
                                    }
                                }
                            }
                        }
                    } catch (Exception ex) {
                        // Handle exceptions
                        RJMessageBox.Show(this, $"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void cb_Diskon_Click(object sender, EventArgs e) {
        }
        private void cb_Diskon_SelectedIndexChanged(object sender, EventArgs e) {
            SelectDiscount = (DiscountItem)cb_Diskon.SelectedItem;
            if(SelectDiscount != null)subtotal_Total();
        }
        private void subtotal_Total() {
            TotalPrice = SubtotalPrice - (SubtotalPrice * SelectDiscount.PersentaseDiskon / 100);
            L_Total.Text = TotalPrice.ToString("F0");
            txt_Cash.Clear();
            txt_Chages.Clear();
        }
        private void L_STotal_TextChanged(object sender, EventArgs e) {
            Label_Currency_TextChanged(sender, e);
            if (SelectDiscount != null) {
                subtotal_Total();
            } else {
                L_Total.Text = TotalPrice.ToString("F0") ;
            }
        }

        private void txt_TextCash(object sender, EventArgs e) {
            txt_Chages.Text = "";
            txt_Chages.PlaceholderText = "Rp.";
            txt_Currency_TextChanged(sender, e);
            decimal Total = Decimal.Parse(L_Total.Text.Replace("Rp", "").Replace(".", ""));
            decimal Cash = 0;
            if (txt_Cash.Text != string.Empty) {
                Cash = Decimal.Parse(txt_Cash.Text.Replace("Rp", "").Replace(".", ""));
                if(Cash == Total) {
                    txt_Chages.PlaceholderText = "No Changes";
                }
                txt_Chages.Text = (Cash - Total).ToString("F0");
            } 
        }
        private void txt_TextChanges(object sender, EventArgs e) {
            txt_Currency_TextChanged(sender, e);
            if(txt_Chages.Text.Contains("-")|| (txt_Chages.Text == string.Empty && txt_Chages.PlaceholderText != "No Changes")) {
                btn_BUY.Enabled = false;
            } else {
                btn_BUY.Enabled=true;
            }
        }

        private void txt_Cash_MouseDown(object sender, MouseEventArgs e) {
            if (e.Button == MouseButtons.Right) {
                // Disable the default context menu
                ((Guna2TextBox)sender).ContextMenu = new ContextMenu();
            }
        }

        private void txt_KeyPressPrice(object sender, KeyPressEventArgs e) {
            Guna2TextBox guna2Text = (Guna2TextBox)sender;

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '\b') {
                e.Handled = true;
            }
            if (Control.ModifierKeys == Keys.Control && e.KeyChar == (char)22) // (char)22 corresponds to Ctrl + V
{
                e.Handled = true;
            }
        }
    }
    public class DiscountItem {
        public int IdDiscount { get; set; }
        public string NamaPromo { get; set; }
        public int PersentaseDiskon { get; set; }

        public DiscountItem(int idDisccount, string namaPromo, int persentaseDiskon) {
            IdDiscount = idDisccount;
            NamaPromo = namaPromo;
            PersentaseDiskon = persentaseDiskon;
        }

        public override string ToString() {
            return NamaPromo;
        }
    }

}

﻿namespace WarungMadura.Resources.Dashboard {
    partial class ProductInfo {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.Borderles = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_IdProduct = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_ProductName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Supplier = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Categories = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Buy = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Sell = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Unit = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Stock = new Guna.UI2.WinForms.Guna2TextBox();
            this.p_Product = new Guna.UI2.WinForms.Guna2PictureBox();
            this.timer_Opening = new System.Windows.Forms.Timer(this.components);
            this.timer_Closing = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Discount = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bnt_Exit = new Guna.UI2.WinForms.Guna2Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.p_Product)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Borderles
            // 
            this.Borderles.BorderRadius = 10;
            this.Borderles.ContainerControl = this;
            this.Borderles.DockIndicatorTransparencyValue = 0.6D;
            this.Borderles.DragForm = false;
            this.Borderles.TransparentWhileDrag = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product Detail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Product Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Categories";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Supplier";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Buy Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 440);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Stock";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Unit";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 329);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Sell Price ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "ID Product";
            // 
            // txt_IdProduct
            // 
            this.txt_IdProduct.BorderRadius = 6;
            this.txt_IdProduct.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_IdProduct.DefaultText = "";
            this.txt_IdProduct.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_IdProduct.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_IdProduct.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IdProduct.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_IdProduct.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IdProduct.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IdProduct.ForeColor = System.Drawing.Color.Black;
            this.txt_IdProduct.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_IdProduct.Location = new System.Drawing.Point(168, 10);
            this.txt_IdProduct.Margin = new System.Windows.Forms.Padding(4);
            this.txt_IdProduct.Name = "txt_IdProduct";
            this.txt_IdProduct.PasswordChar = '\0';
            this.txt_IdProduct.PlaceholderText = "";
            this.txt_IdProduct.ReadOnly = true;
            this.txt_IdProduct.SelectedText = "";
            this.txt_IdProduct.Size = new System.Drawing.Size(265, 36);
            this.txt_IdProduct.TabIndex = 11;
            // 
            // txt_ProductName
            // 
            this.txt_ProductName.BorderRadius = 6;
            this.txt_ProductName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_ProductName.DefaultText = "";
            this.txt_ProductName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_ProductName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_ProductName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ProductName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_ProductName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ProductName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ProductName.ForeColor = System.Drawing.Color.Black;
            this.txt_ProductName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_ProductName.Location = new System.Drawing.Point(168, 60);
            this.txt_ProductName.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ProductName.Name = "txt_ProductName";
            this.txt_ProductName.PasswordChar = '\0';
            this.txt_ProductName.PlaceholderText = "";
            this.txt_ProductName.ReadOnly = true;
            this.txt_ProductName.SelectedText = "";
            this.txt_ProductName.Size = new System.Drawing.Size(265, 36);
            this.txt_ProductName.TabIndex = 12;
            // 
            // txt_Supplier
            // 
            this.txt_Supplier.BorderRadius = 6;
            this.txt_Supplier.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Supplier.DefaultText = "";
            this.txt_Supplier.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Supplier.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Supplier.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Supplier.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Supplier.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Supplier.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Supplier.ForeColor = System.Drawing.Color.Black;
            this.txt_Supplier.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Supplier.Location = new System.Drawing.Point(168, 110);
            this.txt_Supplier.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Supplier.Name = "txt_Supplier";
            this.txt_Supplier.PasswordChar = '\0';
            this.txt_Supplier.PlaceholderText = "";
            this.txt_Supplier.ReadOnly = true;
            this.txt_Supplier.SelectedText = "";
            this.txt_Supplier.Size = new System.Drawing.Size(265, 36);
            this.txt_Supplier.TabIndex = 13;
            // 
            // txt_Categories
            // 
            this.txt_Categories.BorderRadius = 6;
            this.txt_Categories.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Categories.DefaultText = "";
            this.txt_Categories.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Categories.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Categories.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Categories.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Categories.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Categories.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Categories.ForeColor = System.Drawing.Color.Black;
            this.txt_Categories.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Categories.Location = new System.Drawing.Point(168, 160);
            this.txt_Categories.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Categories.Name = "txt_Categories";
            this.txt_Categories.PasswordChar = '\0';
            this.txt_Categories.PlaceholderText = "";
            this.txt_Categories.ReadOnly = true;
            this.txt_Categories.SelectedText = "";
            this.txt_Categories.Size = new System.Drawing.Size(265, 36);
            this.txt_Categories.TabIndex = 14;
            // 
            // txt_Buy
            // 
            this.txt_Buy.BorderRadius = 6;
            this.txt_Buy.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Buy.DefaultText = "";
            this.txt_Buy.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Buy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Buy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Buy.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Buy.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Buy.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Buy.ForeColor = System.Drawing.Color.Black;
            this.txt_Buy.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Buy.Location = new System.Drawing.Point(168, 260);
            this.txt_Buy.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Buy.Name = "txt_Buy";
            this.txt_Buy.PasswordChar = '\0';
            this.txt_Buy.PlaceholderText = "";
            this.txt_Buy.ReadOnly = true;
            this.txt_Buy.SelectedText = "";
            this.txt_Buy.Size = new System.Drawing.Size(265, 36);
            this.txt_Buy.TabIndex = 16;
            this.txt_Buy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Buy.TextChanged += new System.EventHandler(this.txt_Currency_TextChanged);
            // 
            // txt_Sell
            // 
            this.txt_Sell.BorderRadius = 6;
            this.txt_Sell.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Sell.DefaultText = "";
            this.txt_Sell.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Sell.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Sell.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Sell.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Sell.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Sell.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Sell.ForeColor = System.Drawing.Color.Black;
            this.txt_Sell.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Sell.Location = new System.Drawing.Point(168, 318);
            this.txt_Sell.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Sell.Name = "txt_Sell";
            this.txt_Sell.PasswordChar = '\0';
            this.txt_Sell.PlaceholderText = "";
            this.txt_Sell.ReadOnly = true;
            this.txt_Sell.SelectedText = "";
            this.txt_Sell.Size = new System.Drawing.Size(265, 36);
            this.txt_Sell.TabIndex = 17;
            this.txt_Sell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Sell.TextChanged += new System.EventHandler(this.txt_Currency_TextChanged);
            // 
            // txt_Unit
            // 
            this.txt_Unit.BorderRadius = 6;
            this.txt_Unit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Unit.DefaultText = "";
            this.txt_Unit.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Unit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Unit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Unit.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Unit.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Unit.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Unit.ForeColor = System.Drawing.Color.Black;
            this.txt_Unit.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Unit.Location = new System.Drawing.Point(168, 209);
            this.txt_Unit.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Unit.Name = "txt_Unit";
            this.txt_Unit.PasswordChar = '\0';
            this.txt_Unit.PlaceholderText = "";
            this.txt_Unit.ReadOnly = true;
            this.txt_Unit.SelectedText = "";
            this.txt_Unit.Size = new System.Drawing.Size(265, 36);
            this.txt_Unit.TabIndex = 18;
            // 
            // txt_Stock
            // 
            this.txt_Stock.BorderRadius = 6;
            this.txt_Stock.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Stock.DefaultText = "";
            this.txt_Stock.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Stock.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Stock.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Stock.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Stock.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Stock.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Stock.ForeColor = System.Drawing.Color.Black;
            this.txt_Stock.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Stock.Location = new System.Drawing.Point(168, 434);
            this.txt_Stock.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Stock.Name = "txt_Stock";
            this.txt_Stock.PasswordChar = '\0';
            this.txt_Stock.PlaceholderText = "";
            this.txt_Stock.ReadOnly = true;
            this.txt_Stock.SelectedText = "";
            this.txt_Stock.Size = new System.Drawing.Size(265, 36);
            this.txt_Stock.TabIndex = 19;
            // 
            // p_Product
            // 
            this.p_Product.BackColor = System.Drawing.Color.White;
            this.p_Product.ImageRotate = 0F;
            this.p_Product.Location = new System.Drawing.Point(105, 83);
            this.p_Product.Name = "p_Product";
            this.p_Product.Size = new System.Drawing.Size(129, 172);
            this.p_Product.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p_Product.TabIndex = 20;
            this.p_Product.TabStop = false;
            // 
            // timer_Opening
            // 
            this.timer_Opening.Enabled = true;
            this.timer_Opening.Interval = 1;
            this.timer_Opening.Tick += new System.EventHandler(this.timer_Opening_Tick);
            // 
            // timer_Closing
            // 
            this.timer_Closing.Interval = 1;
            this.timer_Closing.Tick += new System.EventHandler(this.timer_Closing_Tick);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(181)))), ((int)(((byte)(203)))));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txt_Unit);
            this.panel1.Controls.Add(this.txt_Sell);
            this.panel1.Controls.Add(this.txt_Buy);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txt_Discount);
            this.panel1.Controls.Add(this.txt_Stock);
            this.panel1.Controls.Add(this.txt_Categories);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txt_Supplier);
            this.panel1.Controls.Add(this.txt_IdProduct);
            this.panel1.Controls.Add(this.txt_ProductName);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(333, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(467, 304);
            this.panel1.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(90, 476);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 21;
            // 
            // txt_Discount
            // 
            this.txt_Discount.BorderRadius = 6;
            this.txt_Discount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Discount.DefaultText = "";
            this.txt_Discount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Discount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Discount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Discount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Discount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Discount.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Discount.ForeColor = System.Drawing.Color.Black;
            this.txt_Discount.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Discount.Location = new System.Drawing.Point(168, 376);
            this.txt_Discount.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Discount.Name = "txt_Discount";
            this.txt_Discount.PasswordChar = '\0';
            this.txt_Discount.PlaceholderText = "";
            this.txt_Discount.ReadOnly = true;
            this.txt_Discount.SelectedText = "";
            this.txt_Discount.Size = new System.Drawing.Size(265, 36);
            this.txt_Discount.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 387);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 25);
            this.label10.TabIndex = 10;
            this.label10.Text = "Discount";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.guna2HtmlLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(0, 0);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(333, 80);
            this.guna2HtmlLabel1.TabIndex = 44;
            this.guna2HtmlLabel1.Text = null;
            // 
            // bnt_Exit
            // 
            this.bnt_Exit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bnt_Exit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bnt_Exit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bnt_Exit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bnt_Exit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bnt_Exit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.bnt_Exit.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_Exit.ForeColor = System.Drawing.Color.White;
            this.bnt_Exit.Location = new System.Drawing.Point(0, 259);
            this.bnt_Exit.Name = "bnt_Exit";
            this.bnt_Exit.Size = new System.Drawing.Size(333, 45);
            this.bnt_Exit.TabIndex = 43;
            this.bnt_Exit.Text = "CLOSE";
            this.bnt_Exit.Click += new System.EventHandler(this.bnt_Exit_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label12.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(29, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(275, 29);
            this.label12.TabIndex = 47;
            this.label12.Text = "Detailed Information";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.label13.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(110, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 29);
            this.label13.TabIndex = 46;
            this.label13.Text = "Product";
            // 
            // ProductInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(107)))), ((int)(((byte)(135)))));
            this.ClientSize = new System.Drawing.Size(800, 304);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.p_Product);
            this.Controls.Add(this.bnt_Exit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductInfo";
            this.Opacity = 0D;
            this.Text = "ProductInfo";
            this.Load += new System.EventHandler(this.ProductInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.p_Product)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm Borderles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txt_Sell;
        private Guna.UI2.WinForms.Guna2TextBox txt_Buy;
        private Guna.UI2.WinForms.Guna2TextBox txt_Categories;
        private Guna.UI2.WinForms.Guna2TextBox txt_Supplier;
        private Guna.UI2.WinForms.Guna2TextBox txt_ProductName;
        private Guna.UI2.WinForms.Guna2TextBox txt_IdProduct;
        private Guna.UI2.WinForms.Guna2TextBox txt_Stock;
        private Guna.UI2.WinForms.Guna2TextBox txt_Unit;
        private Guna.UI2.WinForms.Guna2PictureBox p_Product;
        private System.Windows.Forms.Timer timer_Opening;
        private System.Windows.Forms.Timer timer_Closing;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button bnt_Exit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2TextBox txt_Discount;
        private System.Windows.Forms.Label label10;
    }
}
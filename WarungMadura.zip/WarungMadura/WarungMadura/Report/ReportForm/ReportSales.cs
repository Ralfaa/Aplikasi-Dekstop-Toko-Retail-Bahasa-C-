﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportPembelianWarung {
    public partial class ReportSales : Form {
        public ReportSales() {
            InitializeComponent();
        }
        private DateTime start ;
        private DateTime end;
        private bool alldata = true;
        public ReportSales(DateTime Start,DateTime End) {
            InitializeComponent();
            start = Start;
            end = End;
            alldata = false;
        }
        private void Form3_Load(object sender, EventArgs e) {
            if (alldata) {
                SetReportParameters(new DateTime(2024, 7, 2), DateTime.Now);
            } else {
                SetReportParameters(start, end);
            }
        }

        public void SetReportParameters(DateTime StartDate, DateTime EndDate) {
            this.reportSaleTableAdapter1.Fill(reportDataSet1.ReportSale, StartDate, EndDate);

            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSetSaleReport", (DataTable)reportDataSet1.ReportSale));

            // Refresh the report viewer
            this.reportViewer1.RefreshReport();
        }


    }
}

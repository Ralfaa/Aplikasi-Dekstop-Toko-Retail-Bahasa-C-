﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportPembelianWarung
{
    public partial class InvoicePenjualan : Form
    {
        string connectionString = WarungMadura.Properties.Resources.ConnectionString;

        private decimal cash;
        private decimal changes;
        private int point;

        public decimal Cash{
            get{return cash;}
            set{cash = value;}
        }

        public decimal Changes{
            get { return changes; }
            set { changes = value; }
        }
        public int Point{
            get { return point; }
            set { point = value; }
        }

        public InvoicePenjualan()
        {
            InitializeComponent();
        }

        public InvoicePenjualan(decimal cash, decimal changes, int point){
            InitializeComponent();
            this.cash = cash;
            this.changes = changes;
            this.point = point;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //Form2
            // Set the parameters and refresh the report on form load
            SetReportParameters(Cash, Changes, point, idTransaksi());
        }

        public void SetReportParameters(decimal Cash, decimal Changes, int Point, int idTransaksi)
        {
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("StrukOrderSaleDataSet", (DataTable)reportDataSet1.StrukOrderSale));

            // Set the parameters to the report viewer
            this.reportViewer1.LocalReport.SetParameters(new ReportParameter("Changes", Changes.ToString("N0")));
            this.reportViewer1.LocalReport.SetParameters(new ReportParameter("Cash", Cash.ToString("N0")));
            this.reportViewer1.LocalReport.SetParameters(new ReportParameter("Point", Point.ToString()));

            // Load the data for the report
            this.strukOrderSaleTableAdapter1.Fill(this.reportDataSet1.StrukOrderSale, idTransaksi);

            // Refresh the report viewer
            this.reportViewer1.RefreshReport();
        }

        private int idTransaksi()
        {
            int lastID = 0;
            try
            {
                string query = "SELECT TOP 1 id_transaksi_penjualan FROM TransaksiPenjualan ORDER BY id_transaksi_penjualan DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            lastID = Convert.ToInt32(dt.Rows[0]["id_transaksi_penjualan"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
            }
            return lastID;
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}

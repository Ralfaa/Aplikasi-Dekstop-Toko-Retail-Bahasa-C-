﻿using CustomMessageBox;
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportPembelianWarung {
    public partial class HistoryPurchase : Form {
        public HistoryPurchase() {
            InitializeComponent();
        }
        private int ID = 0;
        public HistoryPurchase(int iD) {
            InitializeComponent();
            ID = iD;
        }

        private void Form6_Load(object sender, EventArgs e) {
            SetReportParameter(ID);
        }

        public void SetReportParameter(int idTransaksi) {
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSetPurchaseHistory", (DataTable)reportDataSet1.HistoryPurchase));

            this.historyPurchaseTableAdapter1.Fill(this.reportDataSet1.HistoryPurchase, idTransaksi);

            this.reportViewer1.RefreshReport();
        }
    }
}

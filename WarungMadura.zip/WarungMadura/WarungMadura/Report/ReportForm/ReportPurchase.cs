﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportPembelianWarung {
    public partial class ReportPurchase : Form {
        public ReportPurchase() {
            InitializeComponent();
        }
        private DateTime start;
        private DateTime end;
        private bool alldata = true;
        public ReportPurchase(DateTime Start, DateTime End) {
            InitializeComponent();
            start = Start;
            end = End;
            alldata = false;
        }
        private void Form4_Load(object sender, EventArgs e) {
            if (alldata) {
                SetReportParameters(new DateTime(2024, 7, 2), DateTime.Now);
            } else {
                SetReportParameters(start, end);
            }
        }

        public void SetReportParameters(DateTime StartDate, DateTime EndDate) {

            this.reportPurchaseTableAdapter1.Fill(reportDataSet1.ReportPurchase, StartDate, EndDate);

            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSetPurchaseReport", (DataTable)reportDataSet1.ReportPurchase));

            // Refresh the report viewer
            this.reportViewer1.RefreshReport();
        }
    }
}

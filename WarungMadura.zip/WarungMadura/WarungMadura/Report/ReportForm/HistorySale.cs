﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportPembelianWarung {
    public partial class HistorySale : Form {
        private int ID = 0;
        public HistorySale(int iD) {
            InitializeComponent();
            ID = iD;
        }
        public HistorySale() {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e) {
            SetReportParameter(ID);
        }

        public void SetReportParameter(int idTransaksi) {
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSetHistorySale", (DataTable)reportDataSet1.HistorySale));

            this.historySaleTableAdapter1.Fill(this.reportDataSet1.HistorySale, idTransaksi);

            this.reportViewer1.RefreshReport();
        }
    }
}

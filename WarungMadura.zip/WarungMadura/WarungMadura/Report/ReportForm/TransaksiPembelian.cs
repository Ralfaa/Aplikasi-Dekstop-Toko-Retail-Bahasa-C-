﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Guna.UI2.WinForms.Suite.Descriptions;

namespace ReportPembelianWarung{
    public partial class TransaksiPembelian : Form {
            string connectionString = WarungMadura.Properties.Resources.ConnectionString;
        public TransaksiPembelian() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            SetReportParameter(idTransaksi());
            this.reportViewer1.RefreshReport();
        }

        private int idTransaksi()
        {
            int lastID = 0;
            try
            {
                string query = "SELECT TOP 1 id_transaksi_pembelian FROM TransaksiPembelian ORDER BY id_transaksi_pembelian DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                             lastID = Convert.ToInt32(dt.Rows[0]["id_transaksi_pembelian"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
            }
            return lastID;
        }

        public void SetReportParameter(int idTransaksi) {
            reportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSetReportPurchase", (DataTable)reportDataSet1.StrukOrderPurchase));

            this.strukOrderPurchaseTableAdapter1.Fill(this.reportDataSet1.StrukOrderPurchase, idTransaksi);

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e) {

        }
    }
}

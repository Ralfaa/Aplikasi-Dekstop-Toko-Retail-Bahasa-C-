﻿namespace WarungMadura {
    partial class DashboardAdmin {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardAdmin));
            this.MenuDash = new System.Windows.Forms.Panel();
            this.flp_Menu = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_Dashboard = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Profile = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Order = new Guna.UI2.WinForms.Guna2Button();
            this.DataPanel = new System.Windows.Forms.Panel();
            this.btn_discount = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Royalty = new Guna.UI2.WinForms.Guna2Button();
            this.btn_member = new Guna.UI2.WinForms.Guna2Button();
            this.gbtn_Data = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Position = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Employee = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Supplier = new Guna.UI2.WinForms.Guna2Button();
            this.btn_PCategory = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Product = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.lb_Welcome = new System.Windows.Forms.Label();
            this.L_Name = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Logout = new Guna.UI2.WinForms.Guna2Button();
            this.time_EButton = new System.Windows.Forms.Timer(this.components);
            this.pnl_filForm = new System.Windows.Forms.Panel();
            this.MenuDash.SuspendLayout();
            this.flp_Menu.SuspendLayout();
            this.DataPanel.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuDash
            // 
            this.MenuDash.AutoSize = true;
            this.MenuDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.MenuDash.Controls.Add(this.flp_Menu);
            this.MenuDash.Controls.Add(this.guna2GradientPanel1);
            this.MenuDash.Controls.Add(this.pictureBox1);
            this.MenuDash.Controls.Add(this.btn_Logout);
            this.MenuDash.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuDash.Location = new System.Drawing.Point(0, 0);
            this.MenuDash.Name = "MenuDash";
            this.MenuDash.Size = new System.Drawing.Size(287, 620);
            this.MenuDash.TabIndex = 0;
            // 
            // flp_Menu
            // 
            this.flp_Menu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.flp_Menu.AutoScroll = true;
            this.flp_Menu.Controls.Add(this.btn_Dashboard);
            this.flp_Menu.Controls.Add(this.btn_Profile);
            this.flp_Menu.Controls.Add(this.btn_Order);
            this.flp_Menu.Controls.Add(this.DataPanel);
            this.flp_Menu.Location = new System.Drawing.Point(5, 166);
            this.flp_Menu.Name = "flp_Menu";
            this.flp_Menu.Size = new System.Drawing.Size(272, 394);
            this.flp_Menu.TabIndex = 4;
            // 
            // btn_Dashboard
            // 
            this.btn_Dashboard.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Dashboard.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Dashboard.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Dashboard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Dashboard.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Dashboard.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Dashboard.ForeColor = System.Drawing.Color.White;
            this.btn_Dashboard.Image = global::WarungMadura.Properties.Resources.dashboardw;
            this.btn_Dashboard.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Dashboard.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Dashboard.Location = new System.Drawing.Point(3, 3);
            this.btn_Dashboard.Name = "btn_Dashboard";
            this.btn_Dashboard.Size = new System.Drawing.Size(245, 45);
            this.btn_Dashboard.TabIndex = 1;
            this.btn_Dashboard.Text = "Dashboard";
            this.btn_Dashboard.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Dashboard.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Dashboard.Click += new System.EventHandler(this.btn_Dashboard_Click);
            // 
            // btn_Profile
            // 
            this.btn_Profile.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Profile.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Profile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Profile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Profile.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Profile.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Profile.ForeColor = System.Drawing.Color.White;
            this.btn_Profile.Image = global::WarungMadura.Properties.Resources.User;
            this.btn_Profile.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Profile.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Profile.Location = new System.Drawing.Point(3, 54);
            this.btn_Profile.Name = "btn_Profile";
            this.btn_Profile.ShadowDecoration.BorderRadius = 0;
            this.btn_Profile.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(204)))), ((int)(((byte)(197)))));
            this.btn_Profile.ShadowDecoration.Depth = 100;
            this.btn_Profile.ShadowDecoration.Shadow = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.btn_Profile.Size = new System.Drawing.Size(245, 45);
            this.btn_Profile.TabIndex = 2;
            this.btn_Profile.Text = "Profile";
            this.btn_Profile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Profile.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Profile.Click += new System.EventHandler(this.btn_Profile_Click);
            // 
            // btn_Order
            // 
            this.btn_Order.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Order.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Order.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Order.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Order.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Order.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Order.ForeColor = System.Drawing.Color.White;
            this.btn_Order.Image = global::WarungMadura.Properties.Resources.clipboard;
            this.btn_Order.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Order.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Order.Location = new System.Drawing.Point(3, 105);
            this.btn_Order.Name = "btn_Order";
            this.btn_Order.Size = new System.Drawing.Size(245, 45);
            this.btn_Order.TabIndex = 3;
            this.btn_Order.Text = "Order";
            this.btn_Order.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Order.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Order.Click += new System.EventHandler(this.btn_Order_Click);
            // 
            // DataPanel
            // 
            this.DataPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(3)))));
            this.DataPanel.Controls.Add(this.btn_discount);
            this.DataPanel.Controls.Add(this.btn_Royalty);
            this.DataPanel.Controls.Add(this.btn_member);
            this.DataPanel.Controls.Add(this.gbtn_Data);
            this.DataPanel.Controls.Add(this.btn_Position);
            this.DataPanel.Controls.Add(this.btn_Employee);
            this.DataPanel.Controls.Add(this.btn_Supplier);
            this.DataPanel.Controls.Add(this.btn_PCategory);
            this.DataPanel.Controls.Add(this.btn_Product);
            this.DataPanel.Location = new System.Drawing.Point(3, 156);
            this.DataPanel.Name = "DataPanel";
            this.DataPanel.Size = new System.Drawing.Size(262, 45);
            this.DataPanel.TabIndex = 5;
            this.DataPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.DataPanel_Paint);
            // 
            // btn_discount
            // 
            this.btn_discount.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_discount.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_discount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_discount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_discount.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_discount.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_discount.ForeColor = System.Drawing.Color.White;
            this.btn_discount.Image = global::WarungMadura.Properties.Resources.discount;
            this.btn_discount.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_discount.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_discount.Location = new System.Drawing.Point(24, 390);
            this.btn_discount.Name = "btn_discount";
            this.btn_discount.Size = new System.Drawing.Size(222, 40);
            this.btn_discount.TabIndex = 12;
            this.btn_discount.Text = "Discount Event";
            this.btn_discount.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_discount.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_discount.Click += new System.EventHandler(this.btn_discount_Click);
            // 
            // btn_Royalty
            // 
            this.btn_Royalty.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Royalty.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Royalty.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Royalty.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Royalty.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Royalty.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Royalty.ForeColor = System.Drawing.Color.White;
            this.btn_Royalty.Image = global::WarungMadura.Properties.Resources.royalty;
            this.btn_Royalty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Royalty.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Royalty.Location = new System.Drawing.Point(23, 342);
            this.btn_Royalty.Name = "btn_Royalty";
            this.btn_Royalty.Size = new System.Drawing.Size(222, 40);
            this.btn_Royalty.TabIndex = 11;
            this.btn_Royalty.Text = "Type Royalty";
            this.btn_Royalty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Royalty.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Royalty.Click += new System.EventHandler(this.btn_Royalty_Click);
            // 
            // btn_member
            // 
            this.btn_member.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_member.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_member.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_member.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_member.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_member.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_member.ForeColor = System.Drawing.Color.White;
            this.btn_member.Image = global::WarungMadura.Properties.Resources.employees;
            this.btn_member.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_member.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_member.Location = new System.Drawing.Point(23, 294);
            this.btn_member.Name = "btn_member";
            this.btn_member.Size = new System.Drawing.Size(222, 40);
            this.btn_member.TabIndex = 10;
            this.btn_member.Text = "Membership";
            this.btn_member.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_member.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_member.Click += new System.EventHandler(this.btn_member_Click);
            // 
            // gbtn_Data
            // 
            this.gbtn_Data.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gbtn_Data.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gbtn_Data.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gbtn_Data.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gbtn_Data.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.gbtn_Data.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbtn_Data.ForeColor = System.Drawing.Color.White;
            this.gbtn_Data.Image = global::WarungMadura.Properties.Resources.data;
            this.gbtn_Data.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gbtn_Data.ImageSize = new System.Drawing.Size(30, 30);
            this.gbtn_Data.Location = new System.Drawing.Point(0, 0);
            this.gbtn_Data.Name = "gbtn_Data";
            this.gbtn_Data.Size = new System.Drawing.Size(245, 45);
            this.gbtn_Data.TabIndex = 4;
            this.gbtn_Data.Text = "Data";
            this.gbtn_Data.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gbtn_Data.Click += new System.EventHandler(this.gbtn_Data_Click);
            // 
            // btn_Position
            // 
            this.btn_Position.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Position.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Position.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Position.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Position.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Position.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Position.ForeColor = System.Drawing.Color.White;
            this.btn_Position.Image = global::WarungMadura.Properties.Resources.ECategory;
            this.btn_Position.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Position.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Position.Location = new System.Drawing.Point(23, 246);
            this.btn_Position.Name = "btn_Position";
            this.btn_Position.Size = new System.Drawing.Size(222, 40);
            this.btn_Position.TabIndex = 9;
            this.btn_Position.Text = "Position";
            this.btn_Position.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Position.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Position.Click += new System.EventHandler(this.btn_Position_Click);
            // 
            // btn_Employee
            // 
            this.btn_Employee.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Employee.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Employee.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Employee.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Employee.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Employee.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Employee.ForeColor = System.Drawing.Color.White;
            this.btn_Employee.Image = global::WarungMadura.Properties.Resources.employees;
            this.btn_Employee.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Employee.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Employee.Location = new System.Drawing.Point(23, 198);
            this.btn_Employee.Name = "btn_Employee";
            this.btn_Employee.Size = new System.Drawing.Size(222, 40);
            this.btn_Employee.TabIndex = 8;
            this.btn_Employee.Text = "Employee";
            this.btn_Employee.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Employee.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Employee.Click += new System.EventHandler(this.btn_Employee_Click);
            // 
            // btn_Supplier
            // 
            this.btn_Supplier.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Supplier.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Supplier.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Supplier.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Supplier.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Supplier.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Supplier.ForeColor = System.Drawing.Color.White;
            this.btn_Supplier.Image = global::WarungMadura.Properties.Resources.supplier;
            this.btn_Supplier.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Supplier.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Supplier.Location = new System.Drawing.Point(23, 150);
            this.btn_Supplier.Name = "btn_Supplier";
            this.btn_Supplier.Size = new System.Drawing.Size(222, 40);
            this.btn_Supplier.TabIndex = 7;
            this.btn_Supplier.Text = "Supplier";
            this.btn_Supplier.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Supplier.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Supplier.Click += new System.EventHandler(this.btn_Supplier_Click);
            // 
            // btn_PCategory
            // 
            this.btn_PCategory.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_PCategory.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_PCategory.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_PCategory.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_PCategory.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_PCategory.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PCategory.ForeColor = System.Drawing.Color.White;
            this.btn_PCategory.Image = global::WarungMadura.Properties.Resources.PCartegory;
            this.btn_PCategory.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_PCategory.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_PCategory.Location = new System.Drawing.Point(23, 102);
            this.btn_PCategory.Name = "btn_PCategory";
            this.btn_PCategory.Size = new System.Drawing.Size(222, 40);
            this.btn_PCategory.TabIndex = 6;
            this.btn_PCategory.Text = "Product Category";
            this.btn_PCategory.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_PCategory.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_PCategory.Click += new System.EventHandler(this.btn_PCategory_Click);
            // 
            // btn_Product
            // 
            this.btn_Product.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Product.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Product.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Product.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Product.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Product.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Product.ForeColor = System.Drawing.Color.White;
            this.btn_Product.Image = global::WarungMadura.Properties.Resources.box;
            this.btn_Product.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Product.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Product.Location = new System.Drawing.Point(23, 54);
            this.btn_Product.Name = "btn_Product";
            this.btn_Product.Size = new System.Drawing.Size(222, 40);
            this.btn_Product.TabIndex = 5;
            this.btn_Product.Text = "Product";
            this.btn_Product.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Product.CheckedChanged += new System.EventHandler(this.btn_CheckedChanged_Padding);
            this.btn_Product.Click += new System.EventHandler(this.btn_Product_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BorderColor = System.Drawing.Color.White;
            this.guna2GradientPanel1.BorderRadius = 3;
            this.guna2GradientPanel1.BorderThickness = 2;
            this.guna2GradientPanel1.Controls.Add(this.lb_Welcome);
            this.guna2GradientPanel1.Controls.Add(this.L_Name);
            this.guna2GradientPanel1.Location = new System.Drawing.Point(7, 102);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(272, 46);
            this.guna2GradientPanel1.TabIndex = 3;
            // 
            // lb_Welcome
            // 
            this.lb_Welcome.AutoSize = true;
            this.lb_Welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Welcome.ForeColor = System.Drawing.Color.White;
            this.lb_Welcome.Location = new System.Drawing.Point(16, 9);
            this.lb_Welcome.Name = "lb_Welcome";
            this.lb_Welcome.Size = new System.Drawing.Size(121, 29);
            this.lb_Welcome.TabIndex = 1;
            this.lb_Welcome.Text = "Welcome,";
            // 
            // L_Name
            // 
            this.L_Name.AutoSize = true;
            this.L_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Name.ForeColor = System.Drawing.Color.White;
            this.L_Name.Location = new System.Drawing.Point(136, 9);
            this.L_Name.Name = "L_Name";
            this.L_Name.Size = new System.Drawing.Size(120, 29);
            this.L_Name.TabIndex = 2;
            this.L_Name.Text = "Admin123";
            this.L_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(272, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Logout
            // 
            this.btn_Logout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Logout.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Logout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Logout.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Logout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Logout.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(59)))), ((int)(((byte)(80)))));
            this.btn_Logout.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btn_Logout.ForeColor = System.Drawing.Color.White;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Logout.Location = new System.Drawing.Point(12, 568);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(245, 45);
            this.btn_Logout.TabIndex = 6;
            this.btn_Logout.Text = "Logout";
            this.btn_Logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // time_EButton
            // 
            this.time_EButton.Tick += new System.EventHandler(this.time_EButton_Tick);
            // 
            // pnl_filForm
            // 
            this.pnl_filForm.AutoSize = true;
            this.pnl_filForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_filForm.BackColor = System.Drawing.Color.Transparent;
            this.pnl_filForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_filForm.Location = new System.Drawing.Point(287, 0);
            this.pnl_filForm.Name = "pnl_filForm";
            this.pnl_filForm.Size = new System.Drawing.Size(1163, 620);
            this.pnl_filForm.TabIndex = 1;
            // 
            // DashboardAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1450, 620);
            this.Controls.Add(this.pnl_filForm);
            this.Controls.Add(this.MenuDash);
            this.Enabled = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(1450, 620);
            this.Name = "DashboardAdmin";
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DashboardAdmin_FormClosed);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.EnabledChanged += new System.EventHandler(this.DashboardAdmin_EnabledChanged);
            this.MenuDash.ResumeLayout(false);
            this.flp_Menu.ResumeLayout(false);
            this.DataPanel.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel MenuDash;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label L_Name;
        private System.Windows.Forms.Label lb_Welcome;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private System.Windows.Forms.FlowLayoutPanel flp_Menu;
        private Guna.UI2.WinForms.Guna2Button btn_Dashboard;
        private Guna.UI2.WinForms.Guna2Button btn_Profile;
        private Guna.UI2.WinForms.Guna2Button gbtn_Data;
        private System.Windows.Forms.Panel DataPanel;
        private Guna.UI2.WinForms.Guna2Button btn_PCategory;
        private Guna.UI2.WinForms.Guna2Button btn_Product;
        private Guna.UI2.WinForms.Guna2Button btn_discount;
        private Guna.UI2.WinForms.Guna2Button btn_Royalty;
        private Guna.UI2.WinForms.Guna2Button btn_member;
        private Guna.UI2.WinForms.Guna2Button btn_Position;
        private Guna.UI2.WinForms.Guna2Button btn_Employee;
        private Guna.UI2.WinForms.Guna2Button btn_Supplier;
        private System.Windows.Forms.Timer time_EButton;
        private System.Windows.Forms.Panel pnl_filForm;
        private Guna.UI2.WinForms.Guna2Button btn_Logout;
        private Guna.UI2.WinForms.Guna2Button btn_Order;
    }
}
﻿using CustomMessageBox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToastNotifications;

namespace WarungMadura {
    public partial class Login : Form {
        bool ShowPass = false;
        Notification notification;
        private int IDEmployee = 0;
        public Login() {
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e) {

        }

        private void btnClose_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void btn_Login_Click(object sender, EventArgs e) {
            if (txt_Pass.Text == "" || txt_User.Text == "") {
                notification = new Notification("Warning","All Column Must be Filled");
            } else {
                User Karyawan = CheckAccount(txt_User.Text, txt_Pass.Text);
                if(Karyawan != null) {
                    String jabatan = GetRole(Karyawan.Jabatan);
                    if (jabatan != string.Empty) {
                        IntoDashboard(jabatan,Karyawan.Id,Karyawan.Name);
                    } else {
                        notification = new Notification("Warning", "Permission denied");
                    }
                } else {
                    notification = new Notification("Warning", "Username or Password Wrong");
                }
            }
                    notification.Show();
            txt_User.Text = string.Empty;
            txt_Pass.Text = string.Empty;
        }

        private void Pass_Eye_P_Click_1(object sender, EventArgs e) {
            if (!ShowPass) {
                Pass_Eye_P.Image = Properties.Resources.OpenEyes;
                txt_Pass.PasswordChar = '\0';
                ShowPass = true;
            } else {
                Pass_Eye_P.Image = Properties.Resources.CloseEyes;
                txt_Pass.PasswordChar = '*';
                ShowPass = false;
            }
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e) {

        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void txt_Pass_KeyPress(object sender, KeyPressEventArgs e) {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '\b') {
                e.Handled = true;
            }
        }
        public User CheckAccount(string userName, string password) {
            try {
                using (SqlConnection conn = new SqlConnection(Properties.Resources.ConnectionString)) {
                    string query = "SELECT * FROM FnLogin(@UserName, @Password) AS id_karyawan";
                    using (SqlCommand cmd = new SqlCommand(query, conn)) {
                        cmd.Parameters.AddWithValue("@UserName", userName);
                        cmd.Parameters.AddWithValue("@Password", password);

                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader()) {
                            if (!reader.HasRows) {
                                return null;
                            }
                            if (reader.Read()) {
                                int id = reader.GetInt32(reader.GetOrdinal("id_karyawan"));
                                string Name = reader.GetString(reader.GetOrdinal("NamaKaryawan"));
                                int jabatan = reader.GetInt32(reader.GetOrdinal("id_jabatan"));
                                return new User(id, Name, jabatan);
                            }
                        }
                    }
                }
            } catch (SqlException e) {
                MessageBox.Show("Error: " + e.Message);
            }
            return null;
        }
        public string GetRole(int id) {
            try {
                using (SqlConnection conn = new SqlConnection(Properties.Resources.ConnectionString)) {
                    string query = "SELECT dbo.FnGetAccess(@Id) AS AksesResult";
                    using (SqlCommand cmd = new SqlCommand(query, conn)) {
                        cmd.Parameters.AddWithValue("@Id", id);

                        conn.Open();
                        object result = cmd.ExecuteScalar();
                        return result == string.Empty ? null : result.ToString();
                    }
                }
            } catch (SqlException e) {
                MessageBox.Show("Error: " + e.Message);
            }
            return null;
        }
        public void IntoDashboard(string ROLE, int id,string Name) {
            notification = new Notification("Info", "Login Successfully");
            switch (ROLE) {
                case "Admin":
                    DashboardAdmin admin = new DashboardAdmin(this,id,Name);
                    notification.Show();
                    admin.Show();
                    this.Hide();
                    Thread.Sleep(5);
                    admin.Enabled = true;
                    break;
                case "Cashier":
                    DashboardCashier cashier = new DashboardCashier(this, id, Name);
                    notification.Show();
                    cashier.Show();
                    this.Hide();
                    Thread.Sleep(5);
                    cashier.Enabled = true;
                    break;                
                case "Manager":
                    DashboardManager manager = new DashboardManager(this, id, Name);
                    notification.Show();
                    manager.Show();
                    this.Hide();
                    Thread.Sleep(5);
                    manager.Enabled = true;
                    break;
                default:
                    notification = new Notification("Info", "Permision Invalid");
                    break;
            }
        }
    }
    public class User {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Jabatan { get; set; }

        public User(int id, string name, int jabatan) {
            Id = id;
            Name = name;
            Jabatan = jabatan;
        }
    }
}

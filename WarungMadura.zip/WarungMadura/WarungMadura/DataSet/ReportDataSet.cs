﻿namespace ReportPembelianWarung {


    public partial class ReportDataSet {
        partial class StrukOrderPurchaseDataTable {
        }

        partial class StrukOrderSaleDataTable {
        }

        partial class ReportPurchaseDataTable {
        }
    }
}
